from __future__ import annotations

import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    from PySide6.QtWidgets import QApplication
    from tools.file_flow_gui import MainWindow, ensure_qt_available
    HAS_QT = True
except Exception:  # pragma: no cover - environment dependent
    QApplication = None  # type: ignore[assignment]
    MainWindow = None  # type: ignore[assignment]
    HAS_QT = False


@unittest.skipUnless(HAS_QT, "PySide6 is not available")
class FileFlowGuiSmokeTests(unittest.TestCase):
    def make_config(self) -> tuple[tempfile.TemporaryDirectory, Path]:
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        master = root / "master"
        a = root / "A"
        b = root / "B"
        for folder in (master, a, b):
            folder.mkdir()
            (folder / "file.txt").write_text("ok\n", encoding="utf-8")
        config = root / "file_flow_paths.txt"
        config.write_text(
            "\n".join([
                f"MASTER_FOLDER={master}",
                "FILES=file.txt",
                f"A={a}",
                f"B={b}",
            ]) + "\n",
            encoding="utf-8",
        )
        return tmp, config

    def test_main_window_can_start_and_render(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        ensure_qt_available()
        app = QApplication.instance() or QApplication([])
        tmp, config = self.make_config()
        with tmp:
            window = MainWindow(config)
            window.show()
            deadline = time.time() + 5
            while window.thread is not None and time.time() < deadline:
                app.processEvents()
                time.sleep(0.02)
            app.processEvents()
            self.assertIsNone(window.thread)
            self.assertEqual(window.windowTitle(), "FileFlow")
            self.assertTrue(window.btn_promote.text())
            self.assertIn("檢查", window.btn_verify.text())
            pixmap = window.grab()
            self.assertFalse(pixmap.isNull())
            window.close()
            app.processEvents()


if __name__ == "__main__":
    unittest.main()
