# FileFlow Functional Upgrade + Product UI V2

## Scope

This package updates the FileFlow feature layer and the PySide6 GUI. It intentionally keeps the existing wrapper entry points and the PyInstaller build script workflow compatible.

## Product UI V2 changes

- Replaced the engineering-style grouped layout with a product-style dashboard.
- Added a quieter app shell with sidebar, top bar, status hero, sync matrix, common action strip, and collapsed result details.
- Reduced visible primary actions to the most common operations.
- Moved low-frequency operations into the `更多操作` menu.
- Renamed ambiguous buttons into clearer user-facing labels:
  - `Verify` -> `檢查是否同步`
  - `Compare / Diff` -> `查看差異`
  - `Promote` -> `推進為 Master`
  - `Reset All` -> `用 Master 覆蓋`
  - `Commit` -> `提交 Master 變更`
- Kept dangerous operations behind explicit confirmation text.
- Kept detailed log output collapsed inside the result panel instead of making it the main visual focus.
- Added a GUI smoke test that starts the real PySide6 window in offscreen mode and grabs a rendered pixmap.

## Core functionality retained

- skip unchanged copies
- atomic copy via temporary file and `os.replace`
- promote dry-run and real execution
- reset-all dry-run and real execution
- undo-last preview and real execution
- backup retention cleanup
- operation JSON/log files
- config-check
- JSON CLI output
- TOML config support with legacy txt compatibility
- binary diff summary

## Validation performed

- `python3 -m compileall -q .`
- `QT_QPA_PLATFORM=offscreen python3 -m unittest discover -s tests -v`
- GUI render smoke test through real `MainWindow` object and `window.grab()`
- `python3 build_file_flow_exe.py --dry-run`
- PyInstaller build attempted in the current Linux environment. Windows `.exe` output must still be validated on Windows because cross-compiling Windows executables from Linux is not supported by PyInstaller.
