from __future__ import annotations

import html
import sys
from pathlib import Path
from typing import Any, Callable

try:
    from PySide6.QtCore import QObject, QThread, Qt, QUrl, Signal, Slot
    from PySide6.QtGui import QAction, QColor, QDesktopServices, QFont
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QHeaderView,
        QInputDialog,
        QLabel,
        QLineEdit,
        QMainWindow,
        QMenu,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QSizePolicy,
        QTableWidget,
        QTableWidgetItem,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
    )
    PYSIDE6_IMPORT_ERROR: ModuleNotFoundError | None = None
except ModuleNotFoundError as exc:  # pragma: no cover - depends on runtime image
    QObject = object  # type: ignore[assignment]
    QThread = object  # type: ignore[assignment]
    Qt = object  # type: ignore[assignment]
    QUrl = object  # type: ignore[assignment]

    def Signal(*_args, **_kwargs):  # type: ignore[override]
        return None

    def Slot(*_args, **_kwargs):  # type: ignore[override]
        def decorator(function):
            return function
        return decorator

    QAction = object  # type: ignore[assignment]
    QApplication = object  # type: ignore[assignment]
    QComboBox = object  # type: ignore[assignment]
    QDialog = object  # type: ignore[assignment]
    QDialogButtonBox = object  # type: ignore[assignment]
    QFrame = object  # type: ignore[assignment]
    QGridLayout = object  # type: ignore[assignment]
    QHBoxLayout = object  # type: ignore[assignment]
    QHeaderView = object  # type: ignore[assignment]
    QInputDialog = object  # type: ignore[assignment]
    QLabel = object  # type: ignore[assignment]
    QLineEdit = object  # type: ignore[assignment]
    QMainWindow = object  # type: ignore[assignment]
    QMenu = object  # type: ignore[assignment]
    QMessageBox = object  # type: ignore[assignment]
    QProgressBar = object  # type: ignore[assignment]
    QPushButton = object  # type: ignore[assignment]
    QSizePolicy = object  # type: ignore[assignment]
    QTableWidget = object  # type: ignore[assignment]
    QTableWidgetItem = object  # type: ignore[assignment]
    QTextBrowser = object  # type: ignore[assignment]
    QVBoxLayout = object  # type: ignore[assignment]
    QWidget = object  # type: ignore[assignment]
    QColor = object  # type: ignore[assignment]
    QDesktopServices = object  # type: ignore[assignment]
    PYSIDE6_IMPORT_ERROR = exc

from . import file_flow

APP_TITLE = "FileFlow"

STATUS_COLORS = {
    file_flow.STATUS_OK: "#22C55E",
    file_flow.STATUS_SAME: "#22C55E",
    file_flow.STATUS_COPIED: "#2563EB",
    file_flow.STATUS_SKIPPED: "#94A3B8",
    file_flow.STATUS_DIFFERENT: "#F59E0B",
    file_flow.STATUS_MISSING: "#EF4444",
    file_flow.STATUS_PERMISSION_DENIED: "#EF4444",
    file_flow.STATUS_UNREADABLE: "#EF4444",
    file_flow.STATUS_ERROR: "#EF4444",
    file_flow.STATUS_UNKNOWN: "#94A3B8",
}

STATUS_LABELS = {
    file_flow.STATUS_OK: "正常",
    file_flow.STATUS_SAME: "相同",
    file_flow.STATUS_COPIED: "已複製",
    file_flow.STATUS_SKIPPED: "已跳過",
    file_flow.STATUS_DIFFERENT: "不同",
    file_flow.STATUS_MISSING: "缺少",
    file_flow.STATUS_PERMISSION_DENIED: "權限不足",
    file_flow.STATUS_UNREADABLE: "無法讀取",
    file_flow.STATUS_ERROR: "錯誤",
    file_flow.STATUS_UNKNOWN: "未知",
}

APP_STYLESHEET = """
QMainWindow {
    background: #F7F8FA;
    color: #111827;
    font-family: "Noto Sans CJK TC", "Segoe UI", "Inter", sans-serif;
    font-size: 13px;
}
QFrame#Sidebar {
    background: #FFFFFF;
    border-right: 1px solid #E5E7EB;
}
QFrame#TopBar {
    background: #FFFFFF;
    border-bottom: 1px solid #E5E7EB;
}
QFrame#Card {
    background: #FFFFFF;
    border: 1px solid #E5E7EB;
    border-radius: 16px;
}
QFrame#HeroCard {
    background: #FFFFFF;
    border: 1px solid #E5E7EB;
    border-radius: 18px;
}
QFrame#StatusIconOk {
    background: #22C55E;
    border-radius: 28px;
}
QFrame#StatusIconWarn {
    background: #F59E0B;
    border-radius: 28px;
}
QFrame#StatusIconError {
    background: #EF4444;
    border-radius: 28px;
}
QLabel#AppName {
    font-size: 20px;
    font-weight: 700;
    color: #111827;
}
QLabel#HeroTitle {
    font-size: 24px;
    font-weight: 700;
    color: #111827;
}
QLabel#SectionTitle {
    font-size: 16px;
    font-weight: 650;
    color: #111827;
}
QLabel#MetricValue {
    font-size: 24px;
    font-weight: 700;
    color: #111827;
}
QLabel#Muted, QLabel#Meta, QLabel#Hint {
    color: #6B7280;
}
QLabel#StatusPillOk {
    background: #EAF8EF;
    color: #166534;
    border-radius: 12px;
    padding: 6px 12px;
    font-weight: 600;
}
QLabel#StatusPillWarn {
    background: #FFF7E6;
    color: #92400E;
    border-radius: 12px;
    padding: 6px 12px;
    font-weight: 600;
}
QLabel#StatusPillError {
    background: #FEECEC;
    color: #991B1B;
    border-radius: 12px;
    padding: 6px 12px;
    font-weight: 600;
}
QPushButton {
    border-radius: 11px;
    padding: 9px 14px;
    font-weight: 600;
    min-height: 20px;
}
QPushButton#PrimaryButton {
    background: #2563EB;
    color: white;
    border: 1px solid #2563EB;
}
QPushButton#PrimaryButton:hover {
    background: #1D4ED8;
}
QPushButton#SecondaryButton {
    background: #FFFFFF;
    color: #111827;
    border: 1px solid #E5E7EB;
}
QPushButton#SecondaryButton:hover {
    background: #F3F4F6;
}
QPushButton#SoftButton {
    background: #F2F4F7;
    color: #111827;
    border: 1px solid #F2F4F7;
}
QPushButton#SoftButton:hover {
    background: #E5E7EB;
}
QPushButton#DangerButton {
    background: #EF4444;
    color: white;
    border: 1px solid #EF4444;
}
QPushButton:disabled {
    background: #F3F4F6;
    color: #9CA3AF;
    border: 1px solid #E5E7EB;
}
QPushButton#NavButton {
    background: transparent;
    color: #374151;
    border: 0;
    text-align: left;
    padding: 10px 14px;
    font-weight: 600;
}
QPushButton#NavButton:hover {
    background: #F3F4F6;
}
QPushButton#NavButtonActive {
    background: #EFF6FF;
    color: #2563EB;
    border: 0;
    text-align: left;
    padding: 10px 14px;
    font-weight: 700;
}
QComboBox, QLineEdit {
    background: #FFFFFF;
    border: 1px solid #E5E7EB;
    border-radius: 10px;
    padding: 8px 12px;
    color: #111827;
}
QTableWidget {
    background: #FFFFFF;
    border: 0;
    gridline-color: #F3F4F6;
    selection-background-color: #EFF6FF;
    selection-color: #111827;
}
QHeaderView::section {
    background: #F9FAFB;
    color: #6B7280;
    border: 0;
    border-bottom: 1px solid #E5E7EB;
    padding: 8px;
    font-weight: 600;
}
QTableWidget::item {
    padding: 8px;
    border-bottom: 1px solid #F3F4F6;
}
QTextBrowser {
    background: #F9FAFB;
    color: #111827;
    border: 1px solid #E5E7EB;
    border-radius: 14px;
    padding: 12px;
}
QProgressBar {
    border: 0;
    border-radius: 6px;
    background: #E5E7EB;
    height: 8px;
}
QProgressBar::chunk {
    border-radius: 6px;
    background: #2563EB;
}
QMenu {
    background: #FFFFFF;
    color: #111827;
    border: 1px solid #E5E7EB;
    border-radius: 10px;
    padding: 6px;
}
QMenu::item {
    padding: 8px 18px;
    border-radius: 8px;
}
QMenu::item:selected {
    background: #F3F4F6;
}
"""


def ensure_qt_available() -> None:
    """Raise a clear error when the optional GUI dependency is missing."""
    if PYSIDE6_IMPORT_ERROR is not None:
        raise RuntimeError(
            "無法啟動 GUI：缺少 PySide6。請先執行 `python -m pip install PySide6`，或改用 CLI：`python file_flow.py status`。"
        ) from PYSIDE6_IMPORT_ERROR


class Worker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(object)

    def __init__(self, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        super().__init__()
        self.action = action
        self.with_progress = with_progress

    @Slot()
    def run(self) -> None:
        try:
            if self.with_progress:
                self.finished.emit(self.action(self.progress.emit))
            else:
                self.finished.emit(self.action())
        except Exception as exc:  # noqa: BLE001 - GUI must show clear runtime errors
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, config_path: Path | None = None) -> None:
        ensure_qt_available()
        super().__init__()
        self.config_path = file_flow.resolve_config_path(config_path)
        self.config: file_flow.FlowConfig | None = None
        self.last_result: file_flow.CommandResult | None = None
        self.last_log_path: Path | None = None
        self.last_backup_path: Path | None = None
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self._more_menu: QMenu | None = None
        app = QApplication.instance()
        if app is not None:
            app.setFont(QFont("Noto Sans CJK TC", 10))
        self.setWindowTitle(APP_TITLE)
        self.resize(1280, 860)
        self.setMinimumSize(1040, 760)
        self.setStyleSheet(APP_STYLESHEET)
        self._build_ui()
        self.run_background("重新檢查狀態", lambda: file_flow.get_status_result(self.config_path))

    def _build_ui(self) -> None:
        shell = QWidget()
        shell_layout = QHBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(180)
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(16, 20, 16, 20)
        side_layout.setSpacing(12)
        app_name = QLabel("● FileFlow")
        app_name.setObjectName("AppName")
        side_layout.addWidget(app_name)
        side_layout.addSpacing(14)
        self.nav_overview = self.nav_button("總覽", active=True)
        side_layout.addWidget(self.nav_overview)
        side_layout.addWidget(self.nav_button("檔案狀態"))
        side_layout.addWidget(self.nav_button("變更記錄"))
        side_layout.addWidget(self.nav_button("備份與還原"))
        side_layout.addWidget(self.nav_button("設定"))
        side_layout.addStretch(1)
        help_card = self.card()
        help_layout = QVBoxLayout(help_card)
        help_layout.setContentsMargins(14, 14, 14, 14)
        title = QLabel("快速說明")
        title.setObjectName("SectionTitle")
        help_layout.addWidget(title)
        for text in ["推進：用某個位置更新 Master", "覆蓋：用 Master 更新全部位置", "檢查：只檢查，不修改檔案"]:
            label = QLabel(text)
            label.setObjectName("Hint")
            label.setWordWrap(True)
            help_layout.addWidget(label)
        side_layout.addWidget(help_card)
        shell_layout.addWidget(sidebar)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        content_layout.addWidget(self.build_topbar())

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(24, 20, 24, 18)
        body_layout.setSpacing(14)
        body_layout.addWidget(self.build_hero())
        body_layout.addWidget(self.build_matrix_card(), 1)
        body_layout.addWidget(self.build_action_area())
        content_layout.addWidget(body, 1)
        shell_layout.addWidget(content, 1)
        self.setCentralWidget(shell)

    def nav_button(self, text: str, *, active: bool = False) -> QPushButton:
        button = QPushButton(text)
        button.setObjectName("NavButtonActive" if active else "NavButton")
        button.setCursor(Qt.PointingHandCursor)
        return button

    def card(self, *, hero: bool = False) -> QFrame:
        frame = QFrame()
        frame.setObjectName("HeroCard" if hero else "Card")
        return frame

    def build_topbar(self) -> QFrame:
        topbar = QFrame()
        topbar.setObjectName("TopBar")
        layout = QHBoxLayout(topbar)
        layout.setContentsMargins(24, 14, 24, 14)
        layout.setSpacing(12)
        project_label = QLabel("專案設定檔")
        project_label.setObjectName("Meta")
        layout.addWidget(project_label)
        self.profile_combo = QComboBox()
        self.profile_combo.addItem("Default", str(self.config_path))
        self.profile_combo.currentIndexChanged.connect(self.on_profile_selected)
        self.profile_combo.setMinimumWidth(180)
        layout.addWidget(self.profile_combo)
        layout.addStretch(1)
        self.status_pill = QLabel("尚未檢查")
        self.status_pill.setObjectName("StatusPillWarn")
        layout.addWidget(self.status_pill)
        self.btn_more = QPushButton("更多操作 ▾")
        self.btn_more.setObjectName("SecondaryButton")
        self.btn_more.clicked.connect(self.show_more_menu)
        layout.addWidget(self.btn_more)
        self.btn_settings = QPushButton("設定")
        self.btn_settings.setObjectName("SoftButton")
        self.btn_settings.clicked.connect(self.edit_config)
        layout.addWidget(self.btn_settings)
        return topbar

    def build_hero(self) -> QFrame:
        hero = self.card(hero=True)
        layout = QHBoxLayout(hero)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(24)

        self.status_icon = QFrame()
        self.status_icon.setObjectName("StatusIconWarn")
        self.status_icon.setFixedSize(56, 56)
        icon_layout = QVBoxLayout(self.status_icon)
        icon_layout.setContentsMargins(0, 0, 0, 0)
        check = QLabel("✓")
        check.setAlignment(Qt.AlignCenter)
        check.setStyleSheet("color: white; font-size: 28px; font-weight: 800;")
        icon_layout.addWidget(check)
        layout.addWidget(self.status_icon)

        title_col = QVBoxLayout()
        title_col.setSpacing(4)
        self.hero_title = QLabel("正在檢查狀態")
        self.hero_title.setObjectName("HeroTitle")
        self.hero_subtitle = QLabel("載入專案設定與檔案同步狀態。")
        self.hero_subtitle.setObjectName("Muted")
        self.last_scan_label = QLabel("最後檢查：尚未完成")
        self.last_scan_label.setObjectName("Meta")
        title_col.addWidget(self.hero_title)
        title_col.addWidget(self.hero_subtitle)
        title_col.addWidget(self.last_scan_label)
        layout.addLayout(title_col, 2)

        metrics = QHBoxLayout()
        metrics.setSpacing(18)
        self.metric_files = self.metric_block("追蹤檔案", "0", "個檔案")
        self.metric_locations = self.metric_block("工作位置", "0", "個位置")
        self.metric_out_of_sync = self.metric_block("不同步", "0", "個檔案")
        self.metric_missing = self.metric_block("缺失", "0", "個檔案")
        for block in [self.metric_files, self.metric_locations, self.metric_out_of_sync, self.metric_missing]:
            metrics.addLayout(block)
        layout.addLayout(metrics, 2)

        suggestion_col = QVBoxLayout()
        suggestion_col.setSpacing(8)
        suggestion_title = QLabel("建議下一步")
        suggestion_title.setObjectName("Meta")
        self.next_action_label = QLabel("先重新檢查狀態。")
        self.next_action_label.setWordWrap(True)
        self.btn_recommended = QPushButton("重新檢查狀態")
        self.btn_recommended.setObjectName("PrimaryButton")
        self.btn_recommended.clicked.connect(lambda: self.run_background("重新檢查狀態", lambda: file_flow.get_status_result(self.config_path)))
        suggestion_col.addWidget(suggestion_title)
        suggestion_col.addWidget(self.next_action_label)
        suggestion_col.addWidget(self.btn_recommended)
        layout.addLayout(suggestion_col, 1)
        return hero

    def metric_block(self, label_text: str, value_text: str, unit_text: str) -> QVBoxLayout:
        block = QVBoxLayout()
        block.setSpacing(2)
        label = QLabel(label_text)
        label.setObjectName("Meta")
        value = QLabel(value_text)
        value.setObjectName("MetricValue")
        unit = QLabel(unit_text)
        unit.setObjectName("Meta")
        block.addWidget(label, alignment=Qt.AlignCenter)
        block.addWidget(value, alignment=Qt.AlignCenter)
        block.addWidget(unit, alignment=Qt.AlignCenter)
        if label_text == "追蹤檔案":
            self.files_value = value
        elif label_text == "工作位置":
            self.locations_value = value
        elif label_text == "不同步":
            self.out_of_sync_value = value
        elif label_text == "缺失":
            self.missing_value = value
        return block

    def build_matrix_card(self) -> QFrame:
        card = self.card()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(22, 18, 22, 18)
        layout.setSpacing(12)
        header = QHBoxLayout()
        title = QLabel("檔案同步狀態概覽")
        title.setObjectName("SectionTitle")
        header.addWidget(title)
        header.addStretch(1)
        self.btn_rescan_inline = QPushButton("重新檢查狀態")
        self.btn_rescan_inline.setObjectName("SecondaryButton")
        self.btn_rescan_inline.clicked.connect(lambda: self.run_background("重新檢查狀態", lambda: file_flow.get_status_result(self.config_path)))
        header.addWidget(self.btn_rescan_inline)
        layout.addLayout(header)

        self.table = QTableWidget(0, 2)
        self.table.setAlternatingRowColors(False)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectItems)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self.show_selected_cell_detail)
        layout.addWidget(self.table, 1)

        self.detail_label = QLabel("點選任一狀態，可在這裡查看完整路徑、size、修改時間與 hash。")
        self.detail_label.setObjectName("Hint")
        self.detail_label.setWordWrap(True)
        layout.addWidget(self.detail_label)
        return card

    def build_action_area(self) -> QFrame:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)

        action_card = self.card()
        action_card.setMinimumHeight(126)
        action_layout = QVBoxLayout(action_card)
        action_layout.setContentsMargins(22, 18, 22, 18)
        action_layout.setSpacing(14)
        row = QHBoxLayout()
        title = QLabel("常用操作")
        title.setObjectName("SectionTitle")
        row.addWidget(title)
        row.addStretch(1)
        source_label = QLabel("選定工作位置")
        source_label.setObjectName("Meta")
        row.addWidget(source_label)
        self.source_combo = QComboBox()
        self.source_combo.currentIndexChanged.connect(self.update_button_states)
        self.source_combo.setMinimumWidth(130)
        row.addWidget(self.source_combo)
        action_layout.addLayout(row)

        button_row = QHBoxLayout()
        button_row.setSpacing(12)
        self.btn_promote = self.action_button("推進為 Master", "把選定工作位置的檔案設為正式版本", "PrimaryButton")
        self.btn_reset = self.action_button("用 Master 覆蓋", "用正式版本同步全部工作位置", "SecondaryButton")
        self.btn_verify = self.action_button("檢查是否同步", "只檢查，不修改檔案", "SecondaryButton")
        self.btn_diff = self.action_button("查看差異", "查看 Master 與選定位置有哪些不同", "SecondaryButton")
        self.btn_more_inline = self.action_button("更多操作", "還原、備份、記錄與設定", "SoftButton")
        self.btn_more_inline.clicked.connect(self.show_more_menu)
        for button in [self.btn_promote, self.btn_reset, self.btn_verify, self.btn_diff, self.btn_more_inline]:
            button_row.addWidget(button)
        action_layout.addLayout(button_row)

        self.progress_label = QLabel("等待操作")
        self.progress_label.setObjectName("Meta")
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        action_layout.addWidget(self.progress_label)
        action_layout.addWidget(self.progress)
        layout.addWidget(action_card)

        result_card = self.card()
        result_layout = QVBoxLayout(result_card)
        result_layout.setContentsMargins(22, 18, 22, 18)
        result_layout.setSpacing(10)
        result_header = QHBoxLayout()
        result_title = QLabel("最近操作結果")
        result_title.setObjectName("SectionTitle")
        result_header.addWidget(result_title)
        result_header.addStretch(1)
        self.btn_open_log = QPushButton("開啟操作記錄")
        self.btn_open_log.setObjectName("SecondaryButton")
        self.btn_open_backup = QPushButton("開啟備份資料夾")
        self.btn_open_backup.setObjectName("SecondaryButton")
        self.btn_copy_summary = QPushButton("複製摘要")
        self.btn_copy_summary.setObjectName("SecondaryButton")
        result_header.addWidget(self.btn_open_log)
        result_header.addWidget(self.btn_open_backup)
        result_header.addWidget(self.btn_copy_summary)
        result_layout.addLayout(result_header)
        self.output = QTextBrowser()
        self.output.setMaximumHeight(132)
        self.output.setMinimumHeight(96)
        result_layout.addWidget(self.output)
        layout.addWidget(result_card)

        self.btn_verify.clicked.connect(lambda: self.run_background("檢查是否同步", lambda: file_flow.get_verify_result(self.config_path)))
        self.btn_diff.clicked.connect(self.run_diff)
        self.btn_promote.clicked.connect(lambda: self.run_promote(dry_run=False))
        self.btn_reset.clicked.connect(lambda: self.run_reset(dry_run=False))
        self.btn_open_log.clicked.connect(lambda: self.open_path(self.last_log_path))
        self.btn_open_backup.clicked.connect(lambda: self.open_path(self.last_backup_path))
        self.btn_copy_summary.clicked.connect(self.copy_summary)
        return container

    def action_button(self, title: str, subtitle: str, object_name: str) -> QPushButton:
        button = QPushButton(title)
        button.setObjectName(object_name)
        button.setCursor(Qt.PointingHandCursor)
        button.setMinimumHeight(44)
        button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        button.setToolTip(subtitle)
        return button

    def show_more_menu(self) -> None:
        menu = QMenu(self)
        actions: list[tuple[str, Callable[[], None]]] = [
            ("預覽推進結果", lambda: self.run_promote(dry_run=True)),
            ("預覽覆蓋結果", lambda: self.run_reset(dry_run=True)),
            ("提交 Master 變更", self.run_commit),
            ("還原上一次操作", self.run_undo),
            ("檢查設定是否正確", lambda: self.run_background("檢查設定是否正確", lambda: file_flow.config_check(self.config_path))),
            ("編輯同步設定", self.edit_config),
            ("清理舊備份", self.run_clean_backups),
            ("開啟操作記錄", lambda: self.open_path(self.last_log_path)),
            ("開啟備份資料夾", lambda: self.open_path(self.last_backup_path)),
            ("複製操作摘要", self.copy_summary),
        ]
        for label, callback in actions:
            action = QAction(label, self)
            action.triggered.connect(callback)
            menu.addAction(action)
        self._more_menu = menu
        anchor = self.sender() if isinstance(self.sender(), QPushButton) else self.btn_more
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def set_busy(self, busy: bool, label: str = "") -> None:
        self.progress_label.setText(label or ("執行中" if busy else "等待操作"))
        if busy:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
        self.update_button_states(busy=busy)

    def update_button_states(self, *, busy: bool | None = None) -> None:
        if busy is None:
            busy = self.thread is not None
        has_config = self.config is not None
        has_source = self.source_combo.currentIndex() >= 0
        for button in [self.btn_verify, self.btn_diff, self.btn_promote, self.btn_reset, self.btn_more_inline, self.btn_rescan_inline, self.btn_recommended, self.btn_more, self.btn_settings]:
            button.setEnabled(not busy)
        self.btn_verify.setEnabled(not busy and has_config)
        self.btn_diff.setEnabled(not busy and has_config and has_source)
        self.btn_promote.setEnabled(not busy and has_config and has_source)
        self.btn_reset.setEnabled(not busy and has_config)
        self.btn_open_log.setEnabled(not busy and self.last_log_path is not None and self.last_log_path.exists())
        self.btn_open_backup.setEnabled(not busy and self.last_backup_path is not None and self.last_backup_path.exists())
        self.btn_copy_summary.setEnabled(not busy and self.last_result is not None)

    def run_background(self, title: str, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        if self.thread is not None:
            return
        self.set_busy(True, title)
        self.thread = QThread()
        self.worker = Worker(action, with_progress=with_progress)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.failed.connect(self.on_worker_failed)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    @Slot(object)
    def on_worker_finished(self, result: Any) -> None:
        if isinstance(result, file_flow.CommandResult):
            self.apply_result(result)
        else:
            self.output.setPlainText(str(result))

    @Slot(object)
    def on_progress(self, info: object) -> None:
        if not isinstance(info, dict):
            return
        copied = int(info.get("copied_bytes") or 0)
        total = int(info.get("total_bytes") or 0)
        index = int(info.get("current_item_index") or 1)
        count = int(info.get("total_item_count") or 1)
        percent = int(copied * 100 / total) if total else 0
        self.progress.setRange(0, 100)
        self.progress.setValue(percent)
        self.progress_label.setText(f"複製中 {index}/{count}: {info.get('current_file', '')} ({percent}%)")

    @Slot(str)
    def on_worker_failed(self, message: str) -> None:
        self.output.setHtml(f"<h3>錯誤</h3><pre>{html.escape(message)}</pre>")
        QMessageBox.critical(self, "錯誤", message)

    @Slot()
    def cleanup_thread(self) -> None:
        self.thread = None
        self.worker = None
        self.set_busy(False)

    def apply_result(self, result: file_flow.CommandResult) -> None:
        self.last_result = result
        self.config = result.config or self.config
        self.last_log_path = result.operation_log_path
        self.last_backup_path = result.backup_dir
        if self.config:
            self.update_config_summary(self.config)
        self.update_overview(result)
        self.update_matrix(result)
        self.output.setHtml(self.result_to_html(result))
        self.update_button_states()

    def update_config_summary(self, config: file_flow.FlowConfig) -> None:
        self.files_value.setText(str(len(config.files)))
        self.locations_value.setText(str(len(config.locations)))
        old = [self.source_combo.itemText(i) for i in range(self.source_combo.count())]
        if old != list(config.locations):
            self.source_combo.clear()
            for name in config.locations:
                self.source_combo.addItem(name, name)

    def update_overview(self, result: file_flow.CommandResult) -> None:
        summary = result.metadata.get("summary", {}) if result.metadata else {}
        different = int(summary.get("different", 0) or 0)
        missing = int(summary.get("missing", 0) or 0)
        errors = int(summary.get("errors", len(result.errors)) or 0)
        self.out_of_sync_value.setText(str(different))
        self.missing_value.setText(str(missing))
        self.last_scan_label.setText(f"最後檢查：{file_flow.iso_now()}")
        if result.success and not different and not missing and not errors:
            self.set_status_visual("ok", "狀態良好", "所有檔案已同步", "所有檔案已同步")
            recommended = "提交 Master 變更" if result.operation in {"promote", "reset-all"} else "重新檢查狀態"
        elif errors or result.errors:
            self.set_status_visual("error", "需要處理", "發現錯誤，請先檢查設定或查看結果。", "發現錯誤")
            recommended = "檢查設定是否正確"
        else:
            self.set_status_visual("warn", "需要確認", "有檔案不同步或缺失，請查看差異或修復。", "需要確認")
            recommended = "查看差異"
        self.next_action_label.setText(" / ".join(result.suggestions[:1]) if result.suggestions else recommended)
        self.btn_recommended.setText(recommended)
        try:
            self.btn_recommended.clicked.disconnect()
        except (TypeError, RuntimeError):
            pass
        if recommended == "提交 Master 變更":
            self.btn_recommended.clicked.connect(self.run_commit)
        elif recommended == "檢查設定是否正確":
            self.btn_recommended.clicked.connect(lambda: self.run_background("檢查設定是否正確", lambda: file_flow.config_check(self.config_path)))
        elif recommended == "查看差異":
            self.btn_recommended.clicked.connect(self.run_diff)
        else:
            self.btn_recommended.clicked.connect(lambda: self.run_background("重新檢查狀態", lambda: file_flow.get_status_result(self.config_path)))

    def set_status_visual(self, level: str, title: str, subtitle: str, pill: str) -> None:
        if level == "ok":
            icon_name, pill_name = "StatusIconOk", "StatusPillOk"
        elif level == "error":
            icon_name, pill_name = "StatusIconError", "StatusPillError"
        else:
            icon_name, pill_name = "StatusIconWarn", "StatusPillWarn"
        self.status_icon.setObjectName(icon_name)
        self.status_icon.style().unpolish(self.status_icon)
        self.status_icon.style().polish(self.status_icon)
        self.hero_title.setText(title)
        self.hero_subtitle.setText(subtitle)
        self.status_pill.setObjectName(pill_name)
        self.status_pill.setText(pill)
        self.status_pill.style().unpolish(self.status_pill)
        self.status_pill.style().polish(self.status_pill)

    def update_matrix(self, result: file_flow.CommandResult) -> None:
        records = list(result.records)
        if not records:
            self.table.setColumnCount(2)
            self.table.setRowCount(0)
            self.table.setHorizontalHeaderLabels(["檔案", "狀態"])
            return
        locations = list(records[0].locations)
        headers = ["檔案名稱", "Master", *locations, "Git", "操作"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            self.table.setItem(row, 0, self.make_item(record.entry.relative_file.as_posix(), None))
            self.table.setItem(row, 1, self.make_item(self.status_text(record.master.status if record.master.exists else record.master.status), record.master))
            for col, location in enumerate(locations, start=2):
                self.table.setItem(row, col, self.make_item(self.status_text(record.locations[location].status), record.locations[location]))
            self.table.setItem(row, len(headers) - 2, self.make_item(record.git_status or "未追蹤", None))
            self.table.setItem(row, len(headers) - 1, self.make_item("···", None))
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setColumnWidth(0, 180)
        self.table.resizeRowsToContents()

    def status_text(self, status: str) -> str:
        color_dot = "●"
        label = STATUS_LABELS.get(status, status)
        return f"{color_dot} {label}"

    def make_item(self, text: str, state: file_flow.FileState | None) -> QTableWidgetItem:
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() & ~Qt.ItemIsEditable)
        if state:
            color = STATUS_COLORS.get(state.status, "#94A3B8")
            item.setForeground(QColor(color))
            item.setData(Qt.UserRole, file_flow.file_state_to_json(state))
        else:
            item.setForeground(QColor("#374151"))
        return item

    def show_selected_cell_detail(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        data = items[0].data(Qt.UserRole)
        if not data:
            self.detail_label.setText(items[0].text())
            return
        self.detail_label.setText(
            f"路徑：{data.get('path')}\n"
            f"狀態：{data.get('status')} · 存在：{data.get('exists')} · 大小：{data.get('size')} bytes\n"
            f"修改時間 ns：{data.get('mtime_ns')} · SHA-256：{data.get('sha256_short')}"
        )

    def result_to_html(self, result: file_flow.CommandResult) -> str:
        ok = "成功" if result.success else "失敗"
        color = "#166534" if result.success else "#991B1B"
        parts = [
            f"<h2 style='margin:0;color:{color}'>{html.escape(result.title)}：{ok}</h2>",
            f"<p>{html.escape(result.message)}</p>",
            "<p>",
            f"<b>已複製</b> {result.copied_count}　",
            f"<b>已跳過</b> {result.skipped_count}　",
            f"<b>失敗</b> {result.failed_count}　",
            f"<b>耗時</b> {result.elapsed_seconds:.3f}s",
            "</p>",
        ]
        if result.backup_dir:
            parts.append(f"<p><b>備份：</b>{html.escape(str(result.backup_dir))}</p>")
        if result.operation_log_path:
            parts.append(f"<p><b>記錄：</b>{html.escape(str(result.operation_log_path))}</p>")
        if result.suggestions:
            parts.append("<p><b>建議下一步：</b>" + html.escape(" / ".join(result.suggestions[:2])) + "</p>")
        detail = result.output or result.diff_text or ""
        if detail:
            parts.append("<details><summary>查看詳細內容</summary>")
            parts.append(f"<pre>{html.escape(detail)}</pre>")
            parts.append("</details>")
        return "".join(parts)

    def selected_source(self) -> str | None:
        return self.source_combo.currentData() or self.source_combo.currentText() or None

    def run_diff(self) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇工作位置", "請先選擇要與 Master 比較的工作位置。")
            return
        self.run_background("查看差異", lambda: file_flow.get_diff_preview_result(source, self.config_path))

    def run_promote(self, *, dry_run: bool) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇工作位置", "請先選擇要推進為 Master 的工作位置。")
            return
        if not dry_run and not self.confirm_text(
            "確認要把工作位置設為 Master？",
            f"{source} 的檔案會覆蓋 Master，然後同步到其他位置。請輸入 {source} 以確認。",
            source,
        ):
            return
        title = "預覽推進結果" if dry_run else "推進選定位置為 Master"
        self.run_background(title, lambda cb=None: file_flow.perform_promote(source, self.config_path, dry_run=dry_run, progress_callback=cb), with_progress=not dry_run)

    def run_reset(self, *, dry_run: bool) -> None:
        if not dry_run and not self.confirm_text(
            "確認要用 Master 覆蓋所有位置？",
            "所有工作位置都會回到 Master 的版本。請輸入 RESET 以確認。",
            "RESET",
        ):
            return
        title = "預覽覆蓋結果" if dry_run else "用 Master 覆蓋所有位置"
        self.run_background(title, lambda cb=None: file_flow.perform_reset_all(self.config_path, dry_run=dry_run, progress_callback=cb), with_progress=not dry_run)

    def run_commit(self) -> None:
        text, ok = QInputDialog.getText(self, "提交 Master 變更", "請輸入 Git commit message：")
        if not ok or not text.strip():
            return
        self.run_background("提交 Master 變更", lambda: file_flow.perform_commit(text, self.config_path))

    def run_undo(self) -> None:
        if not self.confirm_text("還原上一次操作", "即將從備份回復到前一次操作前。請輸入 UNDO 以確認。", "UNDO"):
            self.run_background("預覽還原結果", lambda: file_flow.perform_undo_last(self.config_path, dry_run=True))
            return
        self.run_background("還原上一次操作", lambda cb=None: file_flow.perform_undo_last(self.config_path, dry_run=False, yes=True, progress_callback=cb), with_progress=True)

    def run_clean_backups(self) -> None:
        if self.config is None:
            return
        if not self.confirm_text("清理舊備份", "即將依照保留策略刪除過期備份。請輸入 CLEAN 以確認。", "CLEAN"):
            self.run_background("預覽清理舊備份", lambda: file_flow.cleanup_backups(self.config, dry_run=True))
            return
        self.run_background("清理舊備份", lambda: file_flow.cleanup_backups(self.config, dry_run=False, yes=True))

    def confirm_text(self, title: str, message: str, expected: str) -> bool:
        text, ok = QInputDialog.getText(self, title, message)
        return bool(ok and text == expected)

    def open_path(self, path: Path | None) -> None:
        if not path or not path.exists():
            QMessageBox.warning(self, "無法開啟", "路徑不存在。")
            return
        target = path if path.is_dir() else path.parent
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))

    def copy_summary(self) -> None:
        if not self.last_result:
            return
        QApplication.clipboard().setText(file_flow.format_human_result(self.last_result))

    def edit_config(self) -> None:
        if self.config is None:
            QMessageBox.information(self, "編輯同步設定", "設定尚未載入。請先重新檢查狀態。")
            return
        QMessageBox.information(
            self,
            "編輯同步設定",
            "目前會開啟設定檔所在資料夾。修改後請執行『檢查設定是否正確』與『重新檢查狀態』。",
        )
        self.open_path(self.config.config_path)

    def on_profile_selected(self) -> None:
        data = self.profile_combo.currentData()
        if data:
            self.config_path = Path(data)


def main(argv: list[str] | None = None) -> int:
    ensure_qt_available()
    app = QApplication(sys.argv if argv is None else argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
