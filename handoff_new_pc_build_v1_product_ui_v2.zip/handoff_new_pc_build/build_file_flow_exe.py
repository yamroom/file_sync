from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tools import file_flow_gui, file_flow_icon

APP_NAME = "FileFlowApp"
EXCLUDED_MODULES = ["tkinter", "_tkinter", "PyQt5", "PyQt6", "PySide2"]


def repo_root() -> Path:
    return REPO_ROOT


def dist_dir() -> Path:
    return repo_root() / "dist"


def built_app_path() -> Path:
    suffix = ".exe" if sys.platform.startswith("win") else ""
    return dist_dir() / f"{APP_NAME}{suffix}"


def build_pyinstaller_command() -> list[str]:
    icon_file = file_flow_icon.icon_path(repo_root())
    command = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--noconfirm",
        "--clean",
        "--onefile",
        "--windowed",
        "--icon",
        str(icon_file),
        "--name",
        APP_NAME,
    ]
    for module_name in EXCLUDED_MODULES:
        command.extend(["--exclude-module", module_name])
    command.append("file_flow_gui.py")
    return command


def copy_runtime_files(target_dir: Path) -> None:
    target_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo_root() / "file_flow_paths.txt", target_dir / "file_flow_paths.txt")
    shutil.copy2(file_flow_icon.preview_path(repo_root()), target_dir / file_flow_icon.PREVIEW_FILE_NAME)


def run_build() -> None:
    file_flow_gui.ensure_qt_available()
    file_flow_icon.ensure_icon_assets(repo_root())
    subprocess.run(build_pyinstaller_command(), cwd=repo_root(), check=True)
    copy_runtime_files(dist_dir())


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build the File Flow GUI into a single Windows EXE.")
    parser.add_argument("--dry-run", action="store_true", help="Print the PyInstaller command without building.")
    args = parser.parse_args(argv)

    command = build_pyinstaller_command()
    if args.dry_run:
        print("Build command:")
        print(" ".join(command))
        print(f"Runtime config will be copied to: {dist_dir() / 'file_flow_paths.txt'}")
        print(f"Expected app output: {built_app_path()}")
        print(f"Icon used for build: {file_flow_icon.icon_path(repo_root())}")
        print(f"Preview asset copied to: {dist_dir() / file_flow_icon.PREVIEW_FILE_NAME}")
        return 0

    try:
        run_build()
    except RuntimeError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1

    print(f"Build complete: {built_app_path()}")
    print(f"Config copied to: {dist_dir() / 'file_flow_paths.txt'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
