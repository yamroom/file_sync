# Release Checklist

## 發版前
- [ ] 原始碼已提交且可重現 build
- [ ] 版本號已更新
- [ ] `version_info.txt` 已更新
- [ ] `CHANGELOG.md` 已更新
- [ ] 在乾淨環境測試過啟動
- [ ] 不使用 one-file
- [ ] 不使用 UPX
- [ ] 檢查是否有不必要的自動下載、開機自啟或隱藏行為

## 建置
- [ ] 執行 `build.ps1` 或 `build.bat`
- [ ] 產出 zip
- [ ] 產出 `SHA256SUMS.txt`

## 發版
- [ ] 建立 Git tag
- [ ] 上傳 zip 到 GitHub Releases
- [ ] 上傳 `SHA256SUMS.txt`
- [ ] 補 Release note
- [ ] 說明如何自行 build

## 發版後
- [ ] 重新下載 release 檔驗證 SHA256
- [ ] 在另一台乾淨機器測試
- [ ] 若被誤判，記錄檔案 SHA256 與掃描結果
