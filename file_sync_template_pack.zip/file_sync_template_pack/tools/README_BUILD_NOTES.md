# Build Notes

## 為什麼先用 onedir
`onedir` 通常比 `onefile` 更容易讓安全產品接受，因為它少了自解壓到暫存目錄的行為。

## 如果你之後一定要 onefile
請先完成以下幾件事再考慮：
- 有穩定 release 流程
- 有原始碼
- 有 SHA256
- 有版本資訊
- 最好有 code signing

## Tkinter / Tk/Tcl 備註
如果你的程式使用 Tkinter，PyInstaller 一般會自動處理 Tcl/Tk 相關檔案；但若你的專案有自訂資源或額外 DLL，請再手動加進 build。
