# FileFlowApp 發佈範本

這是一份給 Python 桌面工具（例如 Tkinter / Tk/Tcl）使用的最小可發佈範本。

目標：
- 不直接把裸 `exe` 丟到 repo 根目錄
- 使用 `PyInstaller --onedir`
- 附上版本資訊、雜湊值與 release 說明
- 讓使用者可以自行驗證 build 與下載檔案

## 建議 repo 結構

```text
repo/
  app.py
  requirements.txt
  README.md
  CHANGELOG.md
  build.ps1
  build.bat
  version_info.txt
  file_flow_paths.txt.example
  RELEASE_CHECKLIST.md
  .gitignore
  .github/
    workflows/
      release.yml
```

## 建議發佈方式

1. 原始碼保留在 repo。
2. 使用 `build.ps1` 或 `build.bat` 建置。
3. 輸出 `dist/FileFlowApp/` 後，再壓成 zip。
4. 產生 SHA256。
5. 將 zip 與 SHA256 上傳到 GitHub Releases。

## 建置前先修改

請先依你的專案修改下列項目：

- `app.py`：改成你的實際 entrypoint
- `APP_NAME=FileFlowApp`
- `version_info.txt` 內的版本與公司名稱
- `file_flow_paths.txt.example` 的預設路徑
- `requirements.txt` 內的相依套件

## PowerShell 建置

```powershell
./build.ps1
```

## 批次檔建置

```bat
build.bat
```

## 建議不要做的事

- 不要先用 one-file 模式
- 不要用 UPX
- 不要只發佈裸 `exe`
- 不要省略版本資訊

## Release 檔案建議

- `FileFlowApp-win64-v1.0.0.zip`
- `SHA256SUMS.txt`
- Release note

