$ErrorActionPreference = 'Stop'

# ===== 依需求修改 =====
$AppName = 'FileFlowApp'
$EntryPoint = 'app.py'
$VersionFile = 'version_info.txt'
$IconFile = ''   # 例如 '.\\assets\\app.ico'，沒有可留空
# =====================

Write-Host "[1/5] 清理舊輸出..."
if (Test-Path build) { Remove-Item -Recurse -Force build }
if (Test-Path dist) { Remove-Item -Recurse -Force dist }

Write-Host "[2/5] 確認 PyInstaller..."
python -m PyInstaller --version | Out-Host

Write-Host "[3/5] 建置 onedir..."
$Args = @(
    '--noconfirm'
    '--clean'
    '--windowed'
    '--onedir'
    '--noupx'
    '--name', $AppName
    '--version-file', $VersionFile
)

if ($IconFile -ne '') {
    $Args += @('--icon', $IconFile)
}

$Args += $EntryPoint

python -m PyInstaller @Args

Write-Host "[4/5] 產生 zip..."
$ZipName = "$AppName-win64-v1.0.0.zip"
if (Test-Path $ZipName) { Remove-Item -Force $ZipName }
Compress-Archive -Path ".\\dist\\$AppName\\*" -DestinationPath $ZipName

Write-Host "[5/5] 產生 SHA256..."
(Get-FileHash $ZipName -Algorithm SHA256).Hash + '  ' + $ZipName | Set-Content -Encoding ascii SHA256SUMS.txt

Write-Host "完成：$ZipName 與 SHA256SUMS.txt"
