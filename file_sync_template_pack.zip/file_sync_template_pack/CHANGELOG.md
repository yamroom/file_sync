# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2026-03-31
### Added
- Initial public release
- Windows desktop GUI build
- File path configuration example

### Changed
- N/A

### Fixed
- N/A
