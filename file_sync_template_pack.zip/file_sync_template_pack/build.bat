@echo off
setlocal

set APP_NAME=FileFlowApp
set ENTRY_POINT=app.py
set VERSION_FILE=version_info.txt

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist %APP_NAME%-win64-v1.0.0.zip del /f /q %APP_NAME%-win64-v1.0.0.zip

python -m PyInstaller --noconfirm --clean --windowed --onedir --noupx --name %APP_NAME% --version-file %VERSION_FILE% %ENTRY_POINT%
if errorlevel 1 exit /b 1

powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '.\\dist\\%APP_NAME%\\*' -DestinationPath '%APP_NAME%-win64-v1.0.0.zip'"
if errorlevel 1 exit /b 1

powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-FileHash '.\\%APP_NAME%-win64-v1.0.0.zip' -Algorithm SHA256).Hash + '  ' + '%APP_NAME%-win64-v1.0.0.zip' | Set-Content -Encoding ascii SHA256SUMS.txt"
if errorlevel 1 exit /b 1

echo Done.
endlocal
