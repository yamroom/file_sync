from __future__ import annotations

import argparse
import html
import sys
from pathlib import Path
from typing import Callable

try:
    from PySide6.QtCore import QObject, QThread, Qt, QUrl, Signal, Slot
    from PySide6.QtGui import QDesktopServices
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QInputDialog,
        QLabel,
        QMainWindow,
        QMessageBox,
        QPushButton,
        QSizePolicy,
        QSplitter,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
    )

    PYSIDE6_IMPORT_ERROR: ModuleNotFoundError | None = None
except ModuleNotFoundError as exc:  # pragma: no cover - depends on runtime image
    QObject = object  # type: ignore[assignment]
    QThread = object  # type: ignore[assignment]
    Qt = object  # type: ignore[assignment]
    QUrl = object  # type: ignore[assignment]

    def Signal(*_args, **_kwargs):  # type: ignore[override]
        return None

    def Slot(*_args, **_kwargs):  # type: ignore[override]
        def decorator(function):
            return function

        return decorator

    QApplication = object  # type: ignore[assignment]
    QComboBox = object  # type: ignore[assignment]
    QFrame = object  # type: ignore[assignment]
    QGridLayout = object  # type: ignore[assignment]
    QHBoxLayout = object  # type: ignore[assignment]
    QInputDialog = object  # type: ignore[assignment]
    QLabel = object  # type: ignore[assignment]
    QMainWindow = object  # type: ignore[assignment]
    QMessageBox = object  # type: ignore[assignment]
    QPushButton = object  # type: ignore[assignment]
    QSizePolicy = object  # type: ignore[assignment]
    QSplitter = object  # type: ignore[assignment]
    QTextBrowser = object  # type: ignore[assignment]
    QVBoxLayout = object  # type: ignore[assignment]
    QWidget = object  # type: ignore[assignment]
    QDesktopServices = object  # type: ignore[assignment]
    PYSIDE6_IMPORT_ERROR = exc

from . import file_flow


PALETTE = {
    "page_bg": "#eef4f1",
    "card_shadow": "#d6e1dc",
    "card_bg": "#ffffff",
    "card_alt": "#f5faf7",
    "border": "#d1ddd8",
    "text": "#19333a",
    "muted": "#62777d",
    "primary": "#0e6672",
    "primary_hover": "#0a5660",
    "primary_soft": "#d9ecef",
    "secondary_soft": "#edf3ef",
    "success": "#227354",
    "success_soft": "#dceee5",
    "warning": "#a86e18",
    "warning_soft": "#f4e9d5",
    "danger": "#bb584d",
    "danger_soft": "#f8e4e1",
    "commit": "#18323c",
    "commit_hover": "#122730",
    "disabled_bg": "#e8efeb",
    "disabled_fg": "#93a6ac",
    "output_bg": "#15252d",
    "output_fg": "#f2fafc",
    "output_muted": "#cad7dc",
    "output_info": "#9edced",
    "output_success": "#a3e7bf",
    "output_warning": "#f6d795",
    "output_error": "#f5b1aa",
    "output_success_soft": "#25463a",
    "output_warning_soft": "#4f3d1a",
    "output_error_soft": "#522628",
    "output_divider": "#35515d",
}

KIND_TO_COLORS = {
    "info": {"accent": PALETTE["primary"], "soft": PALETTE["primary_soft"]},
    "success": {"accent": PALETTE["success"], "soft": PALETTE["success_soft"]},
    "warning": {"accent": PALETTE["warning"], "soft": PALETTE["warning_soft"]},
    "error": {"accent": PALETTE["danger"], "soft": PALETTE["danger_soft"]},
    "busy": {"accent": PALETTE["primary"], "soft": PALETTE["primary_soft"]},
    "diff": {"accent": PALETTE["primary"], "soft": PALETTE["primary_soft"]},
}

DEFAULT_WINDOW_GEOMETRY = "980x860"
DEFAULT_WINDOW_SIZE = (980, 860)
MIN_WINDOW_SIZE = (860, 720)
DEFAULT_SPLITTER_SIZES = (360, 500)
OUTPUT_MIN_HEIGHT = 340

STATUS_MISMATCH_TEXT = "\u548c\u6b63\u5f0f\u7248\u672c\u4e0d\u540c"
STATUS_MATCH_TEXT = "\u548c\u6b63\u5f0f\u7248\u672c\u76f8\u540c"
STATUS_MISSING_TEXT = "\u4e0d\u5b58\u5728"
STATUS_UNCOMPARABLE_TEXT = "\u7121\u6cd5\u6bd4\u8f03"
SUMMARY_PREFIX = "\u6458\u8981:"
GIT_STATUS_PREFIX = "  Git \u72c0\u614b:"

TEXT_APP_TITLE = "File Flow App"
TEXT_RELOAD_CONFIG = "\u91cd\u65b0\u8f09\u5165\u8a2d\u5b9a"
TEXT_OPEN_CONFIG = "\u958b\u555f\u8a2d\u5b9a\u6a94"
TEXT_STATUS = "\u67e5\u770b\u72c0\u614b"
TEXT_VERIFY = "\u9a57\u8b49"
TEXT_RESET_ALL = "\u5168\u90e8\u91cd\u7f6e"
TEXT_COMMIT = "Commit \u6b63\u5f0f\u8cc7\u6599\u593e"
TEXT_PROMOTE = "\u63a1\u7528\u9019\u500b\u4f4d\u7f6e"
TEXT_PROMOTE_PANEL = "\u63a1\u7528\u5de5\u4f5c\u4f4d\u7f6e"
TEXT_CLEAR_OUTPUT = "\u6e05\u7a7a\u8f38\u51fa"
TEXT_OUTPUT = "\u6d3b\u52d5\u8f38\u51fa"
TEXT_LOADING = "\u57f7\u884c\u4e2d"
TEXT_READY = "\u8a2d\u5b9a\u5df2\u8f09\u5165"
TEXT_CONFIG_ERROR = "\u8a2d\u5b9a\u6709\u8aa4"
TEXT_COMMIT_CANCELLED = "\u53d6\u6d88 Commit"
TEXT_DIFF_ON = "\u5dee\u7570\u9810\u89bd\uff1a\u958b"
TEXT_DIFF_OFF = "\u5dee\u7570\u9810\u89bd\uff1a\u95dc"
TEXT_MASTER_FOLDER = "\u6b63\u5f0f\u8cc7\u6599\u593e"
TEXT_WORK_LOCATIONS = "\u5de5\u4f5c\u4f4d\u7f6e"
TEXT_LAST_STATUS = "\u6700\u8fd1\u72c0\u614b"
TEXT_QUICK_ACTIONS = "\u5feb\u901f\u64cd\u4f5c"
TEXT_LOCATION_FIELD = "\u5de5\u4f5c\u4f4d\u7f6e"
TEXT_CONFIG_LOADED_DETAIL = "\u8a2d\u5b9a\u5df2\u8f09\u5165\uff0c\u53ef\u76f4\u63a5\u67e5\u770b\u72c0\u614b\u3001\u9a57\u8b49\u6216\u63a1\u7528\u5de5\u4f5c\u4f4d\u7f6e\u3002"
TEXT_CONFIG_LOAD_START = "\u6e96\u5099\u8b80\u53d6\u8a2d\u5b9a\u6a94"
TEXT_MASTER_WAITING = "\u6e96\u5099\u8b80\u53d6\u6b63\u5f0f\u8cc7\u6599\u593e"
TEXT_MASTER_WAITING_DETAIL = "\u8f09\u5165\u8a2d\u5b9a\u5f8c\u6703\u986f\u793a\u6b63\u5f0f\u8cc7\u6599\u593e\u8207\u6a94\u6848\u8cc7\u8a0a\u3002"
TEXT_LOCATIONS_WAITING = "0 \u500b\u5de5\u4f5c\u4f4d\u7f6e"
TEXT_LOCATIONS_WAITING_DETAIL = "\u6e96\u5099\u8b80\u53d6\u5de5\u4f5c\u4f4d\u7f6e\u8a2d\u5b9a"
TEXT_LAST_WAITING = "\u5c1a\u672a\u64cd\u4f5c"
TEXT_LAST_WAITING_DETAIL = "\u53ef\u4ee5\u5148\u57f7\u884c\u67e5\u770b\u72c0\u614b\u6216\u9a57\u8b49\u3002"
TEXT_NO_LOCATIONS = "\u76ee\u524d\u6c92\u6709\u5de5\u4f5c\u4f4d\u7f6e"
TEXT_BUSY_DETAIL = "\u6b63\u5728\u57f7\u884c\u52d5\u4f5c\uff0c\u8acb\u7a0d\u5019\u3002"
TEXT_RESET_CONFIRM = "\u78ba\u5b9a\u8981\u5c07\u6240\u6709\u6a94\u6848\u56de\u5fa9\u6210\u6b63\u5f0f\u7248\u672c\u55ce\uff1f"
TEXT_PROMOTE_CONFIRM = "\u78ba\u5b9a\u8981\u63a1\u7528 {source} \u7684\u5167\u5bb9\uff0c\u8986\u84cb\u6b63\u5f0f\u7248\u672c\u55ce\uff1f"
TEXT_SELECT_LOCATION = "\u8acb\u5148\u9078\u64c7\u8981\u63a1\u7528\u7684\u5de5\u4f5c\u4f4d\u7f6e\u3002"
TEXT_COMMIT_PROMPT = "\u8acb\u8f38\u5165 Commit \u8a0a\u606f\uff1a"
TEXT_COMMIT_CANCEL_OUTPUT = "\u6c92\u6709\u8f38\u5165 Commit \u8a0a\u606f\uff0c\u5df2\u53d6\u6d88\u63d0\u4ea4\u3002"
TEXT_COMMIT_CANCEL_DETAIL = "\u5df2\u4fdd\u7559\u76ee\u524d\u72c0\u614b\uff0c\u672a\u57f7\u884c commit\u3002"
TEXT_RESET_SUCCESS = "\u5168\u90e8\u91cd\u7f6e\u5b8c\u6210\uff0c\u4e26\u5df2\u91cd\u65b0\u9a57\u8b49\u3002"
TEXT_PROMOTE_SUCCESS = "\u5df2\u63a1\u7528 {source} \u7684\u5167\u5bb9\uff0c\u4e26\u91cd\u65b0\u9a57\u8b49\u3002"

BUTTON_BADGES = {
    "info": "\u8cc7\u8a0a",
    "success": "\u5b8c\u6210",
    "warning": "\u63d0\u9192",
    "error": "\u932f\u8aa4",
    "busy": "\u9032\u884c\u4e2d",
    "diff": "\u9810\u89bd",
}

APP_STYLESHEET = f"""
QMainWindow {{
    background: {PALETTE["page_bg"]};
}}
QWidget#AppRoot {{
    background: {PALETTE["page_bg"]};
}}
QFrame[role="cardShell"] {{
    background: {PALETTE["card_shadow"]};
    border-radius: 18px;
}}
QFrame[role="cardPanel"] {{
    background: {PALETTE["card_bg"]};
    border-radius: 17px;
}}
QWidget[role="cardBody"] {{
    background: transparent;
}}
QLabel[role="headerTitle"] {{
    color: {PALETTE["text"]};
    font-size: 24px;
    font-weight: 700;
}}
QLabel[role="sectionTitle"] {{
    color: {PALETTE["text"]};
    font-size: 16px;
    font-weight: 700;
}}
QLabel[role="sectionSub"] {{
    color: {PALETTE["muted"]};
    font-size: 11px;
}}
QLabel[role="cardTitle"] {{
    color: {PALETTE["muted"]};
    font-size: 11px;
}}
QLabel[role="cardValue"] {{
    color: {PALETTE["text"]};
    font-size: 18px;
    font-weight: 700;
}}
QLabel[role="cardDetail"] {{
    color: {PALETTE["muted"]};
    font-size: 11px;
}}
QLabel[role="fieldTitle"] {{
    color: {PALETTE["muted"]};
    font-size: 11px;
}}
QLabel[role="path"] {{
    color: {PALETTE["text"]};
    font-size: 13px;
}}
QPushButton {{
    border: none;
    border-radius: 12px;
    padding: 8px 12px;
    font-size: 12px;
}}
QPushButton[role="secondary"] {{
    background: {PALETTE["secondary_soft"]};
    color: {PALETTE["text"]};
    font-weight: 600;
}}
QPushButton[role="secondary"]:hover {{
    background: #e5eeea;
}}
QPushButton[role="primary"] {{
    background: {PALETTE["primary"]};
    color: white;
    font-weight: 700;
}}
QPushButton[role="primary"]:hover {{
    background: {PALETTE["primary_hover"]};
}}
QPushButton[role="warning"] {{
    background: {PALETTE["warning_soft"]};
    color: {PALETTE["warning"]};
    font-weight: 700;
}}
QPushButton[role="commit"] {{
    background: {PALETTE["commit"]};
    color: white;
    font-weight: 700;
}}
QPushButton[role="ghost"] {{
    background: transparent;
    color: {PALETTE["primary"]};
    padding: 6px 8px;
    font-size: 12px;
    font-weight: 600;
}}
QPushButton:disabled {{
    background: {PALETTE["disabled_bg"]};
    color: {PALETTE["disabled_fg"]};
}}
QComboBox#LocationCombo {{
    background: {PALETTE["card_alt"]};
    color: {PALETTE["text"]};
    border: 1px solid {PALETTE["border"]};
    border-radius: 12px;
    padding: 7px 12px;
    min-height: 18px;
    font-size: 13px;
}}
QComboBox#LocationCombo:hover {{
    border: 1px solid {PALETTE["primary"]};
}}
QComboBox#LocationCombo::drop-down {{
    border: none;
    width: 28px;
}}
QComboBox#LocationCombo:disabled {{
    background: {PALETTE["disabled_bg"]};
    color: {PALETTE["disabled_fg"]};
}}
QSplitter::handle {{
    background: transparent;
}}
QSplitter::handle:vertical {{
    height: 10px;
}}
QTextBrowser#OutputText {{
    background: {PALETTE["output_bg"]};
    color: {PALETTE["output_fg"]};
    border: none;
    border-radius: 16px;
    selection-background-color: #2b6b7a;
    selection-color: #ffffff;
    padding: 10px 12px;
}}
"""

LOCATION_COMBO_POPUP_STYLESHEET = f"""
QAbstractItemView {{
    background: #f6fbf8;
    color: {PALETTE["text"]};
    border: 1px solid {PALETTE["border"]};
    border-radius: 12px;
    outline: none;
    padding: 6px;
    selection-background-color: {PALETTE["primary"]};
    selection-color: #ffffff;
}}
QAbstractItemView::item {{
    min-height: 30px;
    padding: 6px 10px;
    margin: 2px 0;
    border-radius: 8px;
}}
QAbstractItemView::item:hover {{
    background: {PALETTE["primary_soft"]};
    color: {PALETTE["text"]};
}}
QAbstractItemView::item:selected {{
    background: {PALETTE["primary"]};
    color: #ffffff;
}}
"""

OUTPUT_DOCUMENT_STYLESHEET = f"""
body {{
    color: {PALETTE["output_fg"]};
    background: {PALETTE["output_bg"]};
    font-family: "Microsoft JhengHei UI", "Segoe UI", sans-serif;
    font-size: 14px;
    margin: 0;
}}
.log-section {{
    border-bottom: 1px solid {PALETTE["output_divider"]};
    padding: 0 0 12px 0;
    margin: 0 0 12px 0;
}}
.log-header {{
    margin: 0 0 6px 0;
}}
.log-title {{
    font-size: 17px;
    font-weight: 700;
    color: {PALETTE["output_fg"]};
}}
.badge {{
    display: inline-block;
    margin-left: 8px;
    padding: 4px 8px;
    border-radius: 10px;
    font-size: 11px;
    font-weight: 700;
}}
.badge-info, .badge-diff, .badge-busy {{
    color: {PALETTE["output_bg"]};
    background: {PALETTE["output_info"]};
}}
.badge-success {{
    color: {PALETTE["output_bg"]};
    background: {PALETTE["output_success"]};
}}
.badge-warning {{
    color: {PALETTE["output_bg"]};
    background: {PALETTE["output_warning"]};
}}
.badge-error {{
    color: {PALETTE["output_bg"]};
    background: {PALETTE["output_error"]};
}}
.log-detail {{
    color: {PALETTE["output_muted"]};
    font-size: 13px;
    margin: 0 0 8px 0;
}}
.log-line {{
    white-space: pre-wrap;
    color: {PALETTE["output_fg"]};
    margin: 3px 0;
    line-height: 145%;
}}
.body {{
    color: {PALETTE["output_fg"]};
}}
.body_mono {{
    color: {PALETTE["output_fg"]};
    font-family: Consolas, "Courier New", monospace;
}}
.body_muted {{
    color: {PALETTE["output_muted"]};
    font-size: 13px;
}}
.line_success {{
    color: {PALETTE["output_success"]};
    background: {PALETTE["output_success_soft"]};
    font-weight: 700;
    border-radius: 8px;
    padding: 4px 8px;
}}
.line_warning {{
    color: {PALETTE["output_warning"]};
    background: {PALETTE["output_warning_soft"]};
    font-weight: 700;
    border-radius: 8px;
    padding: 4px 8px;
}}
.line_error {{
    color: {PALETTE["output_error"]};
    background: {PALETTE["output_error_soft"]};
    font-weight: 700;
    border-radius: 8px;
    padding: 4px 8px;
}}
.text-body {{ color: {PALETTE["output_fg"]}; }}
.text-mono {{ color: {PALETTE["output_fg"]}; font-family: Consolas, "Courier New", monospace; }}
.text-muted {{ color: {PALETTE["output_muted"]}; }}
.text-success {{ color: {PALETTE["output_success"]}; }}
.text-warning {{ color: {PALETTE["output_warning"]}; }}
.text-error {{ color: {PALETTE["output_error"]}; }}
"""


def ensure_qt_available() -> None:
    if PYSIDE6_IMPORT_ERROR is not None:
        raise RuntimeError(
            "PySide6 is not installed in this Python environment, so the GUI cannot start."
        ) from PYSIDE6_IMPORT_ERROR


def output_highlight_tag(line: str) -> str | None:
    stripped = line.strip()
    if not stripped:
        return None
    if stripped.startswith("ERROR:") or STATUS_MISMATCH_TEXT in stripped:
        return "line_error"
    if STATUS_MISSING_TEXT in stripped or STATUS_UNCOMPARABLE_TEXT in stripped:
        return "line_warning"
    if STATUS_MATCH_TEXT in stripped or stripped.startswith("VERIFY OK"):
        return "line_success"
    if stripped.startswith(SUMMARY_PREFIX):
        if (
            STATUS_MISMATCH_TEXT in stripped
            or STATUS_MISSING_TEXT in stripped
            or STATUS_UNCOMPARABLE_TEXT in stripped
        ):
            return "line_warning"
        return "line_success"
    return None


def _base_output_tag(line: str, kind: str) -> str:
    stripped = line.strip()
    if not stripped:
        return "body_mono" if kind == "diff" else "body"
    if stripped.startswith(GIT_STATUS_PREFIX.strip()):
        return "body_muted"
    if kind == "diff":
        return "body_mono"
    return "body"


def classify_output_line(line: str, kind: str) -> str:
    stripped = line.strip()
    line_tag = output_highlight_tag(line)
    if stripped.startswith("ERROR:") or stripped.startswith("VERIFY OK"):
        return line_tag or _base_output_tag(line, kind)
    if stripped.startswith(SUMMARY_PREFIX) or "|" in stripped:
        return _base_output_tag(line, kind)
    if line_tag is not None:
        return line_tag
    return _base_output_tag(line, kind)


def split_output_line_segments(line: str, kind: str) -> list[tuple[str, str]]:
    stripped = line.strip()
    line_tag = output_highlight_tag(line)
    base_tag = _base_output_tag(line, kind)
    if line_tag is None:
        return [(line, base_tag)]

    phrases_by_tag = {
        "line_error": ("ERROR:", STATUS_MISMATCH_TEXT),
        "line_warning": (STATUS_MISSING_TEXT, STATUS_UNCOMPARABLE_TEXT),
        "line_success": ("VERIFY OK", STATUS_MATCH_TEXT),
    }

    def split_on_phrases(text: str, base_tag: str) -> list[tuple[str, str]]:
        phrases = phrases_by_tag.get(line_tag, ())
        if not phrases:
            return [(text, base_tag)]

        segments: list[tuple[str, str]] = []
        cursor = 0
        while cursor < len(text):
            match_index = len(text)
            match_phrase = ""
            for phrase in phrases:
                found = text.find(phrase, cursor)
                if found != -1 and found < match_index:
                    match_index = found
                    match_phrase = phrase

            if not match_phrase:
                segments.append((text[cursor:], base_tag))
                break

            if match_index > cursor:
                segments.append((text[cursor:match_index], base_tag))
            segments.append((match_phrase, line_tag))
            cursor = match_index + len(match_phrase)
        return segments

    if stripped.startswith(SUMMARY_PREFIX) and ":" in line:
        prefix, suffix = line.split(":", 1)
        return [(prefix + ": ", "body_muted"), *split_on_phrases(suffix.lstrip(), base_tag)]
    return split_on_phrases(line, base_tag)


def _html(text: str) -> str:
    return html.escape(text)


def _segment_class(tag: str) -> str:
    return {
        "body": "text-body",
        "body_mono": "text-mono",
        "body_muted": "text-muted",
        "line_success": "text-success",
        "line_warning": "text-warning",
        "line_error": "text-error",
    }[tag]


def render_output_html(title: str, text: str, *, kind: str = "info", detail: str | None = None) -> str:
    line_html: list[str] = []
    body_text = text.rstrip("\n")
    if body_text:
        for line in body_text.splitlines():
            line_class = classify_output_line(line, kind)
            segments = split_output_line_segments(line, kind)
            rendered_segments = "".join(
                f'<span class="{_segment_class(tag)}">{_html(segment)}</span>'
                for segment, tag in segments
            )
            line_html.append(f'<div class="log-line {line_class}">{rendered_segments or "&nbsp;"}</div>')
    else:
        line_html.append('<div class="log-line body">&nbsp;</div>')

    detail_html = f'<div class="log-detail">{_html(detail)}</div>' if detail else ""
    badge_html = ""
    if kind in {"success", "error"}:
        badge_text = BUTTON_BADGES[kind]
        badge_class = f"badge badge-{kind}"
        badge_html = f'<span class="{badge_class}">{_html(badge_text)}</span>'
    return (
        '<div class="log-section">'
        f'<div class="log-header"><span class="log-title">{_html(title)}</span>'
        f"{badge_html}</div>"
        f"{detail_html}"
        + "".join(line_html)
        + "</div>"
    )


def set_widget_role(widget: QWidget, role: str) -> None:
    widget.setProperty("role", role)
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)
    widget.update()


class JobWorker(QObject):
    finished = Signal(object)

    def __init__(self, title: str, job: Callable[[], file_flow.CommandResult]) -> None:
        super().__init__()
        self.title = title
        self.job = job

    @Slot()
    def run(self) -> None:
        try:
            result = self.job()
        except Exception as exc:  # pragma: no cover - safety net
            result = file_flow.CommandResult(
                title=self.title,
                success=False,
                exit_code=file_flow.EXIT_FAILURE,
                message=str(exc),
                output=f"ERROR: {exc}",
            )
        self.finished.emit(result)


class FileFlowApp(QMainWindow):
    def __init__(
        self,
        *,
        config_path: Path | str | None = None,
        use_worker_thread: bool = True,
    ) -> None:
        ensure_qt_available()
        super().__init__()
        self.setWindowTitle(TEXT_APP_TITLE)
        self.resize(*DEFAULT_WINDOW_SIZE)
        self.setMinimumSize(*MIN_WINDOW_SIZE)
        self.setStyleSheet(APP_STYLESHEET)

        self.config_path = file_flow.resolve_config_path(config_path).resolve(strict=False)
        self.use_worker_thread = use_worker_thread
        self.busy = False
        self.current_config: file_flow.FlowConfig | None = None
        self.last_result_kind = "info"
        self.output_sections: list[str] = []
        self._active_thread: QThread | None = None
        self._active_worker: JobWorker | None = None
        self._pending_success_callback: Callable[[file_flow.CommandResult], None] | None = None
        self.show_diff_enabled = True

        self.summary_cards: dict[str, QWidget] = {}

        self._build_widgets()
        self.reload_config(initial=True)

    def _build_widgets(self) -> None:
        central = QWidget()
        central.setObjectName("AppRoot")
        self.setCentralWidget(central)

        page = QVBoxLayout(central)
        page.setContentsMargins(10, 8, 10, 10)
        page.setSpacing(8)

        self.main_splitter = QSplitter(Qt.Orientation.Vertical)
        self.main_splitter.setChildrenCollapsible(False)
        self.main_splitter.setHandleWidth(10)
        page.addWidget(self.main_splitter, 1)

        top_content = QWidget()
        top_layout = QVBoxLayout(top_content)
        top_layout.setContentsMargins(0, 0, 0, 0)
        top_layout.setSpacing(8)
        self.main_splitter.addWidget(top_content)

        header_shell, self.header_card, _ = self._create_card(PALETTE["primary"], padding=(12, 10, 12, 10))
        top_layout.addWidget(header_shell)
        header_layout = self._card_layout(self.header_card)

        title_row = QHBoxLayout()
        title_row.setSpacing(12)
        header_layout.addLayout(title_row)

        title_label = QLabel(TEXT_APP_TITLE)
        title_label.setProperty("role", "headerTitle")
        title_row.addWidget(title_label, 1)

        self.state_badge_label = QLabel(TEXT_CONFIG_LOAD_START)
        self.state_badge_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_row.addWidget(self.state_badge_label, 0, Qt.AlignmentFlag.AlignRight)

        self.config_path_label = QLabel(str(self.config_path))
        self.config_path_label.setProperty("role", "path")
        self.config_path_label.setWordWrap(True)
        header_layout.addWidget(self.config_path_label)

        config_actions = QHBoxLayout()
        config_actions.setSpacing(8)
        header_layout.addLayout(config_actions)

        self.reload_button = QPushButton(TEXT_RELOAD_CONFIG)
        set_widget_role(self.reload_button, "secondary")
        self.reload_button.clicked.connect(self.reload_config)
        config_actions.addWidget(self.reload_button)

        self.open_config_button = QPushButton(TEXT_OPEN_CONFIG)
        set_widget_role(self.open_config_button, "ghost")
        self.open_config_button.clicked.connect(self.open_config)
        config_actions.addWidget(self.open_config_button)
        config_actions.addStretch(1)

        self.status_label = QLabel(TEXT_CONFIG_LOAD_START)
        self.status_label.setProperty("role", "sectionSub")
        self.status_label.setWordWrap(True)
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        config_actions.addWidget(self.status_label, 0)

        summary_row = QHBoxLayout()
        summary_row.setSpacing(10)
        top_layout.addLayout(summary_row)

        self.summary_cards["master"], _ = self._create_summary_card(
            summary_row,
            TEXT_MASTER_FOLDER,
            PALETTE["primary"],
            record_dynamic_accent=False,
        )
        self.summary_cards["locations"], _ = self._create_summary_card(
            summary_row,
            TEXT_WORK_LOCATIONS,
            "#3d8ba4",
            record_dynamic_accent=False,
        )
        self.summary_cards["last"], self.last_status_strip = self._create_summary_card(
            summary_row,
            TEXT_LAST_STATUS,
            PALETTE["primary"],
            record_dynamic_accent=True,
        )

        controls_row = QHBoxLayout()
        controls_row.setSpacing(10)
        top_layout.addLayout(controls_row)

        quick_shell, self.quick_actions_card, _ = self._create_card(PALETTE["primary"], padding=(10, 10, 10, 10))
        controls_row.addWidget(quick_shell, 1)
        quick_layout = self._card_layout(self.quick_actions_card)

        quick_title = QLabel(TEXT_QUICK_ACTIONS)
        quick_title.setProperty("role", "sectionTitle")
        quick_layout.addWidget(quick_title)

        quick_grid = QGridLayout()
        quick_grid.setHorizontalSpacing(8)
        quick_grid.setVerticalSpacing(8)
        quick_layout.addLayout(quick_grid)

        self.status_button = QPushButton(TEXT_STATUS)
        set_widget_role(self.status_button, "secondary")
        self.status_button.clicked.connect(self.on_status)
        quick_grid.addWidget(self.status_button, 0, 0)

        self.verify_button = QPushButton(TEXT_VERIFY)
        set_widget_role(self.verify_button, "secondary")
        self.verify_button.clicked.connect(self.on_verify)
        quick_grid.addWidget(self.verify_button, 0, 1)

        self.reset_button = QPushButton(TEXT_RESET_ALL)
        set_widget_role(self.reset_button, "warning")
        self.reset_button.clicked.connect(self.on_reset_all)
        quick_grid.addWidget(self.reset_button, 1, 0)

        self.commit_button = QPushButton(TEXT_COMMIT)
        set_widget_role(self.commit_button, "commit")
        self.commit_button.clicked.connect(self.on_commit)
        quick_grid.addWidget(self.commit_button, 1, 1)

        promote_shell, self.promote_card, _ = self._create_card("#3d8ba4", padding=(10, 10, 10, 10))
        controls_row.addWidget(promote_shell, 1)
        promote_layout = self._card_layout(self.promote_card)

        promote_title = QLabel(TEXT_PROMOTE_PANEL)
        promote_title.setProperty("role", "sectionTitle")
        promote_layout.addWidget(promote_title)

        field_title = QLabel(TEXT_LOCATION_FIELD)
        field_title.setProperty("role", "fieldTitle")
        promote_layout.addWidget(field_title)

        self.location_combo = QComboBox()
        self.location_combo.setObjectName("LocationCombo")
        self.location_combo.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.location_combo.view().setStyleSheet(LOCATION_COMBO_POPUP_STYLESHEET)
        self.location_combo.setMaxVisibleItems(10)
        promote_layout.addWidget(self.location_combo)

        promote_actions = QHBoxLayout()
        promote_actions.setSpacing(8)
        promote_layout.addLayout(promote_actions)

        self.show_diff_button = QPushButton()
        self.show_diff_button.clicked.connect(self.toggle_show_diff)
        promote_actions.addWidget(self.show_diff_button, 0, Qt.AlignmentFlag.AlignLeft)
        promote_actions.addStretch(1)

        self.promote_button = QPushButton(TEXT_PROMOTE)
        set_widget_role(self.promote_button, "primary")
        self.promote_button.clicked.connect(self.on_promote)
        promote_actions.addWidget(self.promote_button, 0, Qt.AlignmentFlag.AlignRight)

        self.output_shell, self.output_card, _ = self._create_card(PALETTE["commit"], padding=(0, 0, 0, 0))
        self.output_shell.setMinimumHeight(OUTPUT_MIN_HEIGHT)
        self.main_splitter.addWidget(self.output_shell)
        output_layout = self._card_layout(self.output_card)
        output_layout.setContentsMargins(0, 0, 0, 0)
        output_layout.setSpacing(0)

        output_header = QWidget()
        header_row = QHBoxLayout(output_header)
        header_row.setContentsMargins(12, 8, 12, 6)
        header_row.setSpacing(10)
        output_layout.addWidget(output_header)

        output_title = QLabel(TEXT_OUTPUT)
        output_title.setProperty("role", "sectionTitle")
        header_row.addWidget(output_title)
        header_row.addStretch(1)

        self.clear_output_button = QPushButton(TEXT_CLEAR_OUTPUT)
        set_widget_role(self.clear_output_button, "ghost")
        self.clear_output_button.clicked.connect(self.clear_output)
        header_row.addWidget(self.clear_output_button)

        output_body = QWidget()
        output_body_layout = QVBoxLayout(output_body)
        output_body_layout.setContentsMargins(12, 0, 12, 10)
        output_body_layout.setSpacing(0)
        output_layout.addWidget(output_body, 1)

        self.output_text = QTextBrowser()
        self.output_text.setObjectName("OutputText")
        self.output_text.setOpenExternalLinks(False)
        self.output_text.setFrameShape(QFrame.Shape.NoFrame)
        self.output_text.setMinimumHeight(OUTPUT_MIN_HEIGHT - 44)
        self.output_text.document().setDefaultStyleSheet(OUTPUT_DOCUMENT_STYLESHEET)
        output_body_layout.addWidget(self.output_text, 1)

        self.main_splitter.setStretchFactor(0, 3)
        self.main_splitter.setStretchFactor(1, 6)
        self.main_splitter.setSizes(list(DEFAULT_SPLITTER_SIZES))

        self.refresh_diff_toggle()
        self._update_state_banner(TEXT_CONFIG_LOAD_START, TEXT_LAST_WAITING_DETAIL, kind="info")
        self._refresh_summary_from_config(None)
        self._render_output_sections()

    def _card_layout(self, body: QWidget) -> QVBoxLayout:
        layout = body.layout()
        assert isinstance(layout, QVBoxLayout)
        return layout

    def _create_card(
        self,
        accent: str,
        *,
        padding: tuple[int, int, int, int],
    ) -> tuple[QFrame, QWidget, QFrame]:
        shell = QFrame()
        shell.setProperty("role", "cardShell")
        shell_layout = QVBoxLayout(shell)
        shell_layout.setContentsMargins(1, 1, 1, 1)
        shell_layout.setSpacing(0)

        panel = QFrame()
        panel.setProperty("role", "cardPanel")
        shell_layout.addWidget(panel)

        panel_layout = QVBoxLayout(panel)
        panel_layout.setContentsMargins(0, 0, 0, 0)
        panel_layout.setSpacing(0)

        accent_strip = QFrame()
        accent_strip.setFixedHeight(5)
        accent_strip.setStyleSheet(
            f"background: {accent}; border-top-left-radius: 17px; border-top-right-radius: 17px;"
        )
        panel_layout.addWidget(accent_strip)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(*padding)
        body_layout.setSpacing(6)
        panel_layout.addWidget(body)
        return shell, body, accent_strip

    def _create_summary_card(
        self,
        parent_layout: QHBoxLayout,
        title: str,
        accent: str,
        *,
        record_dynamic_accent: bool,
    ) -> tuple[QWidget, QFrame]:
        shell, body, accent_strip = self._create_card(accent, padding=(10, 6, 10, 6))
        parent_layout.addWidget(shell, 1)
        layout = self._card_layout(body)

        title_label = QLabel(title)
        title_label.setProperty("role", "cardTitle")
        layout.addWidget(title_label)

        value_label = QLabel("")
        value_label.setProperty("role", "cardValue")
        value_label.setWordWrap(True)
        layout.addWidget(value_label)

        detail_label = QLabel("")
        detail_label.setProperty("role", "cardDetail")
        detail_label.setWordWrap(True)
        layout.addWidget(detail_label)

        if title == TEXT_MASTER_FOLDER:
            self.master_summary_value_label = value_label
            self.master_summary_detail_label = detail_label
        elif title == TEXT_WORK_LOCATIONS:
            self.location_summary_value_label = value_label
            self.location_summary_detail_label = detail_label
        else:
            self.last_result_value_label = value_label
            self.last_result_detail_label = detail_label

        if record_dynamic_accent:
            self.last_status_strip = accent_strip
        return body, accent_strip

    def _render_output_sections(self) -> None:
        html_sections = "".join(self.output_sections)
        self.output_text.setHtml(f"<html><body>{html_sections}</body></html>")
        scrollbar = self.output_text.verticalScrollBar()
        scrollbar.setValue(scrollbar.minimum())

    def refresh_action_states(self) -> None:
        open_enabled = not self.busy
        self.reload_button.setEnabled(open_enabled)
        self.open_config_button.setEnabled(open_enabled)
        self.clear_output_button.setEnabled(open_enabled)

        enabled = self.current_config is not None and not self.busy
        self.status_button.setEnabled(enabled)
        self.verify_button.setEnabled(enabled)
        self.reset_button.setEnabled(enabled)
        self.commit_button.setEnabled(enabled)
        self.show_diff_button.setEnabled(enabled)
        self.location_combo.setEnabled(enabled)
        self.promote_button.setEnabled(enabled and self.location_combo.count() > 0)

    def refresh_diff_toggle(self) -> None:
        self.show_diff_button.setText(TEXT_DIFF_ON if self.show_diff_enabled else TEXT_DIFF_OFF)
        set_widget_role(self.show_diff_button, "secondary" if self.show_diff_enabled else "ghost")

    def toggle_show_diff(self) -> None:
        self.show_diff_enabled = not self.show_diff_enabled
        self.refresh_diff_toggle()

    def set_busy(self, busy: bool) -> None:
        self.busy = busy
        if busy:
            self._update_state_banner(TEXT_LOADING, TEXT_BUSY_DETAIL, kind="busy")
        else:
            self._apply_badge_style(self.last_result_kind)
        self.refresh_action_states()

    def clear_output(self) -> None:
        self.output_sections = []
        self._render_output_sections()

    def append_output(self, title: str, text: str, *, kind: str = "info", detail: str | None = None) -> None:
        self.output_sections.insert(0, render_output_html(title, text, kind=kind, detail=detail))
        self._render_output_sections()

    def _result_kind_for_output(self, result: file_flow.CommandResult) -> str:
        if not result.success:
            return "error"
        if result.title == "\u5dee\u7570\u9810\u89bd":
            return "diff"
        if result.title in {
            "\u63a1\u7528\u5de5\u4f5c\u4f4d\u7f6e",
            TEXT_COMMIT,
            "\u9a57\u8b49",
        }:
            return "success"
        if result.title == "\u5168\u90e8\u91cd\u7f6e":
            return "warning"
        return "info"

    def _update_state_banner(self, headline: str, detail: str, *, kind: str) -> None:
        self.last_result_kind = kind
        self.state_badge_label.setText(headline)
        self.last_result_value_label.setText(headline)
        self.last_result_detail_label.setText(detail)
        self._apply_badge_style(kind)

    def _apply_badge_style(self, kind: str) -> None:
        colors = KIND_TO_COLORS.get(kind, KIND_TO_COLORS["info"])
        self.state_badge_label.setStyleSheet(
            "border-radius: 14px; padding: 6px 12px; font-size: 12px; font-weight: 700;"
            f"color: {colors['accent']}; background: {colors['soft']};"
        )
        self.last_status_strip.setStyleSheet(
            f"background: {colors['accent']}; border-top-left-radius: 17px; border-top-right-radius: 17px;"
        )

    def _refresh_summary_from_config(self, config: file_flow.FlowConfig | None) -> None:
        if config is None:
            self.master_summary_value_label.setText(TEXT_MASTER_WAITING)
            self.master_summary_detail_label.setText(TEXT_MASTER_WAITING_DETAIL)
            self.location_summary_value_label.setText(TEXT_LOCATIONS_WAITING)
            self.location_summary_detail_label.setText(TEXT_LOCATIONS_WAITING_DETAIL)
            return

        master_name = config.master_folder.name or str(config.master_folder)
        self.master_summary_value_label.setText(master_name)
        self.master_summary_detail_label.setText(f"\u5171 {len(config.files)} \u500b\u6a94\u6848")
        self.location_summary_value_label.setText(f"{len(config.locations)} \u500b\u5de5\u4f5c\u4f4d\u7f6e")
        self.location_summary_detail_label.setText(", ".join(config.locations) if config.locations else TEXT_NO_LOCATIONS)

    def load_config_into_ui(self, config: file_flow.FlowConfig) -> None:
        self.current_config = config
        current_selection = self.location_combo.currentText()
        self.location_combo.blockSignals(True)
        self.location_combo.clear()
        self.location_combo.addItems(list(config.locations))
        if current_selection and current_selection in config.locations:
            self.location_combo.setCurrentText(current_selection)
        elif self.location_combo.count():
            self.location_combo.setCurrentIndex(0)
        self.location_combo.blockSignals(False)

        self.config_path_label.setText(str(config.config_path))
        self.status_label.setText(TEXT_CONFIG_LOADED_DETAIL)
        self._refresh_summary_from_config(config)
        self.refresh_action_states()

    def reload_config(self, *, initial: bool = False) -> None:
        try:
            config = file_flow.load_config(self.config_path)
        except file_flow.FlowError as exc:
            self.current_config = None
            self.location_combo.clear()
            self.status_label.setText(str(exc))
            self._refresh_summary_from_config(None)
            self._update_state_banner(TEXT_CONFIG_ERROR, str(exc), kind="error")
            self.refresh_action_states()
            self.append_output(TEXT_RELOAD_CONFIG, f"ERROR: {exc}", kind="error", detail=str(exc))
            if not initial:
                QMessageBox.critical(self, TEXT_CONFIG_ERROR, str(exc))
            return

        self.load_config_into_ui(config)
        detail = f"{len(config.locations)} \u500b\u5de5\u4f5c\u4f4d\u7f6e\u5df2\u8f09\u5165\u3002"
        self._update_state_banner(TEXT_READY, detail, kind="info")
        self.append_output(
            TEXT_RELOAD_CONFIG,
            "\n".join(
                [
                    f"\u8a2d\u5b9a\u6a94: {config.config_path}",
                    f"{TEXT_MASTER_FOLDER}: {config.master_folder}",
                    f"{TEXT_WORK_LOCATIONS}: {', '.join(config.locations)}",
                ]
            ),
            kind="info",
            detail=TEXT_CONFIG_LOADED_DETAIL,
        )

    def open_config(self) -> None:
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.config_path))):
            QMessageBox.critical(self, TEXT_OPEN_CONFIG, str(self.config_path))

    def run_job(
        self,
        title: str,
        job: Callable[[], file_flow.CommandResult],
        *,
        on_success: Callable[[file_flow.CommandResult], None] | None = None,
    ) -> None:
        if self.busy:
            return
        self.set_busy(True)
        self._pending_success_callback = on_success

        if not self.use_worker_thread:
            try:
                result = job()
            except Exception as exc:  # pragma: no cover - safety net
                result = file_flow.CommandResult(
                    title=title,
                    success=False,
                    exit_code=file_flow.EXIT_FAILURE,
                    message=str(exc),
                    output=f"ERROR: {exc}",
                )
            callback = self._pending_success_callback
            self._pending_success_callback = None
            self.finish_job(result, callback)
            return

        thread = QThread(self)
        worker = JobWorker(title, job)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.finished.connect(thread.quit)
        worker.finished.connect(worker.deleteLater)
        worker.finished.connect(self._handle_worker_result, Qt.ConnectionType.QueuedConnection)
        thread.finished.connect(self._handle_thread_finished, Qt.ConnectionType.QueuedConnection)
        thread.finished.connect(thread.deleteLater)
        self._active_thread = thread
        self._active_worker = worker
        thread.start()

    @Slot()
    def _handle_thread_finished(self) -> None:
        sender = self.sender()
        if sender is self._active_thread:
            self._active_thread = None
            self._active_worker = None

    @Slot(object)
    def _handle_worker_result(self, result: file_flow.CommandResult) -> None:
        callback = self._pending_success_callback
        self._pending_success_callback = None
        self.finish_job(result, callback)

    def finish_job(
        self,
        result: file_flow.CommandResult,
        on_success: Callable[[file_flow.CommandResult], None] | None = None,
    ) -> None:
        self.set_busy(False)
        kind = self._result_kind_for_output(result)
        self.append_output(result.title, result.output, kind=kind, detail=result.message)
        if result.config is not None:
            self.load_config_into_ui(result.config)

        headline = result.title if result.success else f"{result.title}\u5931\u6557"
        self.status_label.setText(result.message)
        self._update_state_banner(headline, result.message, kind=kind)

        if result.success:
            if on_success is not None:
                on_success(result)
            return
        QMessageBox.critical(self, result.title, result.message)

    def closeEvent(self, event) -> None:  # type: ignore[override]
        if self._active_thread is not None:
            self._active_thread.quit()
            self._active_thread.wait(5000)
        super().closeEvent(event)

    def on_status(self) -> None:
        self.run_job("\u67e5\u770b\u72c0\u614b", lambda: file_flow.get_status_result(self.config_path))

    def on_verify(self) -> None:
        self.run_job("\u9a57\u8b49", lambda: file_flow.get_verify_result(self.config_path))

    def on_reset_all(self) -> None:
        answer = QMessageBox.question(
            self,
            TEXT_RESET_ALL,
            TEXT_RESET_CONFIRM,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return

        def job() -> file_flow.CommandResult:
            return file_flow.combine_results(
                "\u5168\u90e8\u91cd\u7f6e",
                file_flow.get_reset_all_result(self.config_path),
                file_flow.get_verify_result(self.config_path),
                message=TEXT_RESET_SUCCESS,
            )

        self.run_job("\u5168\u90e8\u91cd\u7f6e", job)

    def on_promote(self) -> None:
        source_name = self.location_combo.currentText().strip()
        if not source_name:
            QMessageBox.warning(self, TEXT_PROMOTE_PANEL, TEXT_SELECT_LOCATION)
            return

        if self.show_diff_enabled:
            self.run_job(
                "\u5dee\u7570\u9810\u89bd",
                lambda: file_flow.get_promote_preview_result(source_name, self.config_path),
                on_success=lambda _result: self.confirm_promote(source_name),
            )
            return
        self.confirm_promote(source_name)

    def confirm_promote(self, source_name: str) -> None:
        answer = QMessageBox.question(
            self,
            TEXT_PROMOTE_PANEL,
            TEXT_PROMOTE_CONFIRM.format(source=source_name),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return

        def job() -> file_flow.CommandResult:
            return file_flow.combine_results(
                "\u63a1\u7528\u5de5\u4f5c\u4f4d\u7f6e",
                file_flow.get_promote_result(source_name, show_diff=False, config_path=self.config_path),
                file_flow.get_verify_result(self.config_path),
                message=TEXT_PROMOTE_SUCCESS.format(source=source_name),
            )

        self.run_job("\u63a1\u7528\u5de5\u4f5c\u4f4d\u7f6e", job)

    def on_commit(self) -> None:
        self.run_job(
            "\u9a57\u8b49",
            lambda: file_flow.get_verify_result(self.config_path),
            on_success=self.prompt_commit_message,
        )

    def prompt_commit_message(self, _result: file_flow.CommandResult) -> None:
        message, accepted = QInputDialog.getText(self, TEXT_COMMIT, TEXT_COMMIT_PROMPT)
        if not accepted or not message.strip():
            self.append_output(
                TEXT_COMMIT,
                TEXT_COMMIT_CANCEL_OUTPUT,
                kind="warning",
                detail=TEXT_COMMIT_CANCEL_DETAIL,
            )
            self._update_state_banner(TEXT_COMMIT_CANCELLED, TEXT_COMMIT_CANCEL_DETAIL, kind="warning")
            self.status_label.setText(TEXT_COMMIT_CANCEL_DETAIL)
            return
        self.run_job(TEXT_COMMIT, lambda: file_flow.get_commit_result(message.strip(), self.config_path))


def build_gui_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Launch the File Flow desktop app.")
    parser.add_argument(
        "--config",
        default=str(file_flow.default_config_path()),
        help=f"Path to the config file. Defaults to {file_flow.DEFAULT_CONFIG_NAME}.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    ensure_qt_available()
    args = build_gui_parser().parse_args(argv)

    app = QApplication.instance()
    owns_app = app is None
    if app is None:
        app = QApplication([sys.argv[0]])
        app.setApplicationName(TEXT_APP_TITLE)
        app.setStyle("Fusion")

    window = FileFlowApp(config_path=args.config, use_worker_thread=True)
    window.show()
    if owns_app:
        return app.exec()
    return 0
