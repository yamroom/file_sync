# FileFlow Version C UI Test Report

Date: 2026-05-24

## Environment

- OS: Linux container
- Python: 3.13.5
- PySide6: 6.11.1
- PyInstaller: 6.20.0

## Completed tests

| Area | Result |
|---|---|
| Python compileall | PASS |
| Unit tests | PASS, 10 tests |
| CLI JSON status | PASS |
| Config check with real temp workspace | PASS |
| GUI smoke test | PASS |
| GUI screenshot test | PASS |
| Build script dry-run | PASS |
| Qt availability check | PASS |
| Icon asset generation check | PASS |

## PyInstaller full build result

A full PyInstaller build was attempted in this Linux container. It did not complete within the available execution limit. To isolate whether this was caused by this project, a minimal `hello.py` PyInstaller build was also attempted and also timed out at the PyInstaller base-library analysis stage.

Conclusion: the full packaging timeout appears to be an execution-environment / PyInstaller issue in this container, not a FileFlow code error. A real Windows `.exe` must still be built and smoke-tested on a Windows machine.

The build command itself is generated correctly by `python build_file_flow_exe.py --dry-run`.

## GUI changes

- Implemented compact dashboard version C.
- Main actions are reduced to four: `重新檢查`, `看差異`, `更新 Master`, `還原工作區`.
- Advanced actions are moved to `進階 ▾`.
- Default window area is one quarter of the screen: width 50%, height 50%.
- Minimum window size is 512 x 384.
- Added GUI smoke-test mode: `python file_flow_gui.py --smoke-test`.
- Added GUI screenshot mode: `python file_flow_gui.py --screenshot path.png`.

## Sample TOML

A sample TOML config is included at `file_flow_paths.example.toml`.
