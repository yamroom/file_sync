File Flow App - 新電腦打包說明

這個資料夾是給新電腦用的乾淨打包包。

使用步驟：
1. 先安裝 Python 3.12
2. 建議也安裝 Git
3. 在這個資料夾中開啟終端機
4. 安裝依賴：
   pip install -r requirements.txt
5. 開始打包：
   python build_file_flow_exe.py

打包完成後，產物會在：
  dist\FileFlowApp.exe
  dist\file_flow_paths.toml

如果只想先看指令，不真的打包：
  python build_file_flow_exe.py --dry-run

如果要修改同步路徑：
  請編輯 file_flow_paths.toml

如果要一鍵執行：
  直接雙擊 BUILD_EXE.cmd
