"""Local tools package for repository automation."""
