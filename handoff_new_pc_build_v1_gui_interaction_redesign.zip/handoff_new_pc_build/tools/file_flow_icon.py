from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path

ASSETS_DIR_NAME = "assets"
ICON_FILE_NAME = "file_flow_app.ico"
PREVIEW_FILE_NAME = "file_flow_app_preview.png"
ICON_SIZE = 256


def asset_dir(base_dir: Path | None = None) -> Path:
    if base_dir is None:
        base_dir = Path(__file__).resolve().parents[1]
    return base_dir / ASSETS_DIR_NAME


def icon_path(base_dir: Path | None = None) -> Path:
    return asset_dir(base_dir) / ICON_FILE_NAME


def preview_path(base_dir: Path | None = None) -> Path:
    return asset_dir(base_dir) / PREVIEW_FILE_NAME


def ensure_icon_assets(base_dir: Path | None = None) -> tuple[Path, Path]:
    output_dir = asset_dir(base_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    png_bytes = build_preview_png_bytes(ICON_SIZE)
    preview_file = preview_path(base_dir)
    preview_file.write_bytes(png_bytes)

    ico_bytes = build_ico_bytes(png_bytes)
    icon_file = icon_path(base_dir)
    icon_file.write_bytes(ico_bytes)
    return icon_file, preview_file


def build_preview_png_bytes(size: int) -> bytes:
    pixels = bytearray(size * size * 4)

    draw_rounded_rect(
        pixels,
        size,
        26,
        30,
        204,
        204,
        48,
        (0, 0, 0, 50),
        (0, 0, 0, 8),
    )
    draw_rounded_rect(
        pixels,
        size,
        18,
        18,
        220,
        220,
        52,
        (17, 33, 57, 255),
        (19, 111, 157, 255),
    )

    draw_card(pixels, size, 42, 70, 72, 52, (245, 121, 98, 255), folded=(255, 229, 220, 255))
    draw_card(pixels, size, 56, 104, 72, 52, (255, 195, 82, 255), folded=(255, 241, 201, 255))
    draw_card(pixels, size, 70, 138, 72, 52, (62, 207, 190, 255), folded=(207, 251, 244, 255))

    draw_thick_line(pixels, size, 126, 128, 152, 128, 12, (235, 245, 255, 220))
    draw_thick_line(pixels, size, 144, 114, 168, 128, 12, (235, 245, 255, 220))
    draw_thick_line(pixels, size, 144, 142, 168, 128, 12, (235, 245, 255, 220))

    draw_card(pixels, size, 148, 58, 66, 106, (250, 252, 255, 255), folded=(221, 234, 244, 255), line_color=(168, 185, 205, 255))

    draw_circle(pixels, size, 190, 186, 28, (42, 186, 129, 255))
    draw_thick_line(pixels, size, 177, 186, 187, 196, 8, (255, 255, 255, 255))
    draw_thick_line(pixels, size, 186, 196, 205, 177, 8, (255, 255, 255, 255))

    return encode_png_rgba(size, size, bytes(pixels))


def draw_card(
    pixels: bytearray,
    size: int,
    x: int,
    y: int,
    width: int,
    height: int,
    fill: tuple[int, int, int, int],
    *,
    folded: tuple[int, int, int, int],
    line_color: tuple[int, int, int, int] = (255, 255, 255, 180),
) -> None:
    draw_rounded_rect(pixels, size, x, y, width, height, 14, with_alpha(fill, 70), with_alpha(fill, 18))
    draw_rounded_rect(pixels, size, x, y, width, height, 14, fill, fill)
    draw_folded_corner(pixels, size, x, y, width, 18, folded)
    for offset in (16, 26, 36):
        draw_rounded_rect(pixels, size, x + 12, y + offset, width - 28, 5, 2, line_color, line_color)


def draw_folded_corner(
    pixels: bytearray,
    size: int,
    x: int,
    y: int,
    width: int,
    fold_size: int,
    color: tuple[int, int, int, int],
) -> None:
    start_x = x + width - fold_size - 4
    start_y = y + 6
    for py in range(fold_size):
        for px in range(fold_size - py):
            blend_pixel(pixels, size, start_x + px + py, start_y + py, color)


def with_alpha(color: tuple[int, int, int, int], alpha: int) -> tuple[int, int, int, int]:
    return (color[0], color[1], color[2], alpha)


def draw_rounded_rect(
    pixels: bytearray,
    size: int,
    x: int,
    y: int,
    width: int,
    height: int,
    radius: int,
    color_top: tuple[int, int, int, int],
    color_bottom: tuple[int, int, int, int],
) -> None:
    max_x = min(size, x + width)
    max_y = min(size, y + height)
    for py in range(max(0, y), max_y):
        blend = 0 if height <= 1 else (py - y) / (height - 1)
        color = interpolate_color(color_top, color_bottom, blend)
        for px in range(max(0, x), max_x):
            if point_in_rounded_rect(px, py, x, y, width, height, radius):
                blend_pixel(pixels, size, px, py, color)


def point_in_rounded_rect(px: int, py: int, x: int, y: int, width: int, height: int, radius: int) -> bool:
    right = x + width - 1
    bottom = y + height - 1
    if x + radius <= px <= right - radius or y + radius <= py <= bottom - radius:
        return True

    corners = (
        (x + radius, y + radius),
        (right - radius, y + radius),
        (x + radius, bottom - radius),
        (right - radius, bottom - radius),
    )
    for cx, cy in corners:
        if (px - cx) ** 2 + (py - cy) ** 2 <= radius ** 2:
            return True
    return False


def draw_circle(
    pixels: bytearray,
    size: int,
    center_x: int,
    center_y: int,
    radius: int,
    color: tuple[int, int, int, int],
) -> None:
    for py in range(max(0, center_y - radius), min(size, center_y + radius + 1)):
        for px in range(max(0, center_x - radius), min(size, center_x + radius + 1)):
            if (px - center_x) ** 2 + (py - center_y) ** 2 <= radius ** 2:
                blend_pixel(pixels, size, px, py, color)


def draw_thick_line(
    pixels: bytearray,
    size: int,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    thickness: int,
    color: tuple[int, int, int, int],
) -> None:
    radius = thickness / 2
    min_x = max(0, int(min(x1, x2) - radius - 1))
    max_x = min(size, int(max(x1, x2) + radius + 2))
    min_y = max(0, int(min(y1, y2) - radius - 1))
    max_y = min(size, int(max(y1, y2) + radius + 2))

    for py in range(min_y, max_y):
        for px in range(min_x, max_x):
            if distance_to_segment(px + 0.5, py + 0.5, x1, y1, x2, y2) <= radius:
                blend_pixel(pixels, size, px, py, color)


def distance_to_segment(px: float, py: float, x1: int, y1: int, x2: int, y2: int) -> float:
    dx = x2 - x1
    dy = y2 - y1
    if dx == 0 and dy == 0:
        return math.hypot(px - x1, py - y1)
    t = ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)
    t = max(0.0, min(1.0, t))
    proj_x = x1 + t * dx
    proj_y = y1 + t * dy
    return math.hypot(px - proj_x, py - proj_y)


def interpolate_color(
    start: tuple[int, int, int, int],
    end: tuple[int, int, int, int],
    factor: float,
) -> tuple[int, int, int, int]:
    return tuple(int(a + (b - a) * factor) for a, b in zip(start, end))  # type: ignore[return-value]


def blend_pixel(
    pixels: bytearray,
    size: int,
    x: int,
    y: int,
    color: tuple[int, int, int, int],
) -> None:
    if not (0 <= x < size and 0 <= y < size):
        return

    offset = (y * size + x) * 4
    src_r, src_g, src_b, src_a = color
    if src_a <= 0:
        return

    dst_r = pixels[offset]
    dst_g = pixels[offset + 1]
    dst_b = pixels[offset + 2]
    dst_a = pixels[offset + 3]

    src_alpha = src_a / 255.0
    dst_alpha = dst_a / 255.0
    out_alpha = src_alpha + dst_alpha * (1.0 - src_alpha)
    if out_alpha <= 0:
        return

    out_r = int((src_r * src_alpha + dst_r * dst_alpha * (1.0 - src_alpha)) / out_alpha)
    out_g = int((src_g * src_alpha + dst_g * dst_alpha * (1.0 - src_alpha)) / out_alpha)
    out_b = int((src_b * src_alpha + dst_b * dst_alpha * (1.0 - src_alpha)) / out_alpha)
    out_a = int(out_alpha * 255)

    pixels[offset] = out_r
    pixels[offset + 1] = out_g
    pixels[offset + 2] = out_b
    pixels[offset + 3] = out_a


def encode_png_rgba(width: int, height: int, rgba: bytes) -> bytes:
    scanlines = bytearray()
    row_bytes = width * 4
    for row in range(height):
        start = row * row_bytes
        scanlines.append(0)
        scanlines.extend(rgba[start : start + row_bytes])

    compressed = zlib.compress(bytes(scanlines), level=9)
    png = bytearray(b"\x89PNG\r\n\x1a\n")
    png.extend(png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)))
    png.extend(png_chunk(b"IDAT", compressed))
    png.extend(png_chunk(b"IEND", b""))
    return bytes(png)


def png_chunk(chunk_type: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + chunk_type
        + data
        + struct.pack(">I", zlib.crc32(chunk_type + data) & 0xFFFFFFFF)
    )


def build_ico_bytes(png_bytes: bytes) -> bytes:
    header = struct.pack("<HHH", 0, 1, 1)
    entry = struct.pack(
        "<BBBBHHII",
        0,
        0,
        0,
        0,
        1,
        32,
        len(png_bytes),
        6 + 16,
    )
    return header + entry + png_bytes


def main() -> int:
    icon_file, preview_file = ensure_icon_assets()
    print(f"Icon created: {icon_file}")
    print(f"Preview created: {preview_file}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
