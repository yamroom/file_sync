from __future__ import annotations

import argparse
import filecmp
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

DEFAULT_CONFIG_NAME = "file_flow_paths.toml"
LEGACY_CONFIG_NAME = "file_flow_paths.txt"
BACKUP_DIR_NAME = ".tool_backups"
LOG_DIR_NAME = ".tool_logs"
STATE_DIR_NAME = ".tool_state"
DEFAULT_MAX_WORKERS = 4
COPY_CHUNK_SIZE = 1024 * 1024
RESERVED_CONFIG_KEYS = {
    "MASTER_FOLDER",
    "FILES",
    "MAX_WORKERS",
    "BACKUP_KEEP_LAST",
    "BACKUP_KEEP_DAYS",
    "USE_HASH_CACHE",
}
YES_WORDS = {"y", "yes", "1", "是"}
NO_WORDS = {"n", "no", "0", "否"}
DUBIOUS_OWNERSHIP_PATTERN = re.compile(r"repository at '([^']+)'", re.IGNORECASE)

STATUS_OK = "OK"
STATUS_SAME = "SAME"
STATUS_DIFFERENT = "DIFFERENT"
STATUS_MISSING = "MISSING"
STATUS_PERMISSION_DENIED = "PERMISSION_DENIED"
STATUS_UNREADABLE = "UNREADABLE"
STATUS_UNTRACKED = "UNTRACKED"
STATUS_MODIFIED = "MODIFIED"
STATUS_DELETED = "DELETED"
STATUS_ERROR = "ERROR"
STATUS_UNKNOWN = "UNKNOWN"
STATUS_SKIPPED = "SKIPPED"
STATUS_COPIED = "COPIED"

EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_CONFIG = 3
EXIT_VERIFY = 4
EXIT_GIT = 5

ProgressCallback = Callable[[dict[str, Any]], None]


class FlowError(Exception):
    def __init__(self, message: str, exit_code: int = EXIT_FAILURE, suggestions: Iterable[str] | None = None) -> None:
        super().__init__(message)
        self.exit_code = exit_code
        self.suggestions = tuple(suggestions or ())


@dataclass(frozen=True)
class FlowConfig:
    config_dir: Path
    config_path: Path
    master_folder: Path
    files: list[Path]
    locations: dict[str, Path]
    max_workers: int = DEFAULT_MAX_WORKERS
    backup_keep_last: int | None = None
    backup_keep_days: int | None = None
    use_hash_cache: bool = False
    format: str = "txt"


@dataclass(frozen=True)
class FileState:
    path: Path
    exists: bool
    sha256: str | None = None
    size: int | None = None
    mtime_ns: int | None = None
    status: str = STATUS_UNKNOWN
    error: str = ""


@dataclass(frozen=True)
class FileEntry:
    name: str
    relative_file: Path
    master_path: Path
    location_paths: dict[str, Path]


@dataclass(frozen=True)
class FileRecord:
    entry: FileEntry
    master: FileState
    locations: dict[str, FileState]
    git_status: str


@dataclass
class TransferItem:
    relative_file: str
    source_label: str
    destination_label: str
    source: str
    destination: str
    action: str
    reason: str
    size: int | None = None
    source_sha256: str | None = None
    destination_sha256: str | None = None
    backup_path: str | None = None
    error: str = ""


@dataclass
class CommandResult:
    title: str
    success: bool
    exit_code: int
    message: str
    output: str = ""
    operation: str = ""
    config: FlowConfig | None = None
    problems: tuple[str, ...] = ()
    records: tuple[FileRecord, ...] = ()
    diff_text: str = ""
    backup_dir: Path | None = None
    operation_log_path: Path | None = None
    operation_json_path: Path | None = None
    copied_files: tuple[str, ...] = ()
    skipped_files: tuple[str, ...] = ()
    failed_files: tuple[str, ...] = ()
    planned_files: tuple[TransferItem, ...] = ()
    errors: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()
    suggestions: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
    elapsed_seconds: float = 0.0

    @property
    def copied_count(self) -> int:
        return len(self.copied_files)

    @property
    def skipped_count(self) -> int:
        return len(self.skipped_files)

    @property
    def failed_count(self) -> int:
        return len(self.failed_files)


def now_timestamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S-%f")


def iso_now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def runtime_base_dir(*, frozen: bool | None = None, executable_path: Path | None = None) -> Path:
    if frozen is None:
        frozen = bool(getattr(sys, "frozen", False))
    if frozen:
        executable = executable_path or Path(sys.executable)
        return executable.resolve().parent
    return Path(__file__).resolve().parents[1]


def default_config_path(*, frozen: bool | None = None, executable_path: Path | None = None) -> Path:
    base = runtime_base_dir(frozen=frozen, executable_path=executable_path)
    preferred = base / DEFAULT_CONFIG_NAME
    legacy = base / LEGACY_CONFIG_NAME
    if preferred.exists():
        return preferred
    if legacy.exists():
        return legacy
    return preferred


def resolve_config_path(config_path: Path | str | None = None) -> Path:
    if config_path is None:
        return default_config_path()
    return Path(config_path).expanduser()


def path_to_str(path: Path | None) -> str | None:
    return None if path is None else str(path)


def short_hash(value: str | None, length: int = 8) -> str:
    if not value:
        return ""
    return value[:length] + "..."


def as_jsonable(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, tuple):
        return [as_jsonable(item) for item in value]
    if isinstance(value, list):
        return [as_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(key): as_jsonable(item) for key, item in value.items()}
    if hasattr(value, "__dataclass_fields__"):
        return {key: as_jsonable(item) for key, item in asdict(value).items()}
    return value


def command_result_to_json(result: CommandResult) -> dict[str, Any]:
    config = result.config
    return {
        "ok": result.success,
        "operation": result.operation or result.title,
        "timestamp": result.metadata.get("timestamp", iso_now()),
        "title": result.title,
        "message": result.message,
        "exit_code": result.exit_code,
        "summary": {
            "copied": result.copied_count,
            "skipped": result.skipped_count,
            "failed": result.failed_count,
            "planned": len(result.planned_files),
            "elapsed_seconds": result.elapsed_seconds,
        },
        "config": None if config is None else {
            "config_path": str(config.config_path),
            "master_folder": str(config.master_folder),
            "locations": {name: str(path) for name, path in config.locations.items()},
            "files": [file.as_posix() for file in config.files],
            "max_workers": config.max_workers,
            "backup_keep_last": config.backup_keep_last,
            "backup_keep_days": config.backup_keep_days,
            "format": config.format,
        },
        "copied_files": list(result.copied_files),
        "skipped_files": list(result.skipped_files),
        "failed_files": list(result.failed_files),
        "planned_files": as_jsonable(list(result.planned_files)),
        "errors": list(result.errors),
        "warnings": list(result.warnings),
        "suggestions": list(result.suggestions),
        "problems": list(result.problems),
        "backup_path": path_to_str(result.backup_dir),
        "operation_log_path": path_to_str(result.operation_log_path),
        "operation_json_path": path_to_str(result.operation_json_path),
        "records": records_to_json(result.records),
        "metadata": as_jsonable(result.metadata),
    }


def records_to_json(records: Iterable[FileRecord]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in records:
        rows.append({
            "file": record.entry.relative_file.as_posix(),
            "master": file_state_to_json(record.master),
            "locations": {name: file_state_to_json(state) for name, state in record.locations.items()},
            "git_status": record.git_status,
        })
    return rows


def file_state_to_json(state: FileState) -> dict[str, Any]:
    return {
        "path": str(state.path),
        "exists": state.exists,
        "sha256_short": short_hash(state.sha256),
        "sha256": state.sha256,
        "size": state.size,
        "mtime_ns": state.mtime_ns,
        "status": state.status,
        "error": state.error,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="管理正式資料夾與多個工作位置的同步流程。")
    parser.add_argument("--config", default=str(default_config_path()), help=f"設定檔路徑，預設優先使用 {DEFAULT_CONFIG_NAME}，找不到時使用 {LEGACY_CONFIG_NAME}")
    parser.add_argument("--json", action="store_true", help="只輸出 machine-readable JSON。")
    parser.add_argument("--max-workers", type=int, default=None, help="覆蓋設定檔中的 MAX_WORKERS。")
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("status", help="查看正式資料夾與所有工作位置的目前狀態。")
    subparsers.add_parser("verify", help="檢查所有檔案是否一致。")
    subparsers.add_parser("flow", help="用互動方式帶你完成日常操作。")
    subparsers.add_parser("config-check", help="檢查設定檔與資料夾安全性。")

    promote_parser = subparsers.add_parser("promote", help="採用某個工作位置的內容，更新正式資料夾。")
    promote_parser.add_argument("source", help="要採用的工作位置名稱。")
    promote_parser.add_argument("--diff", action="store_true", help="在執行前先顯示差異。")
    promote_parser.add_argument("--dry-run", action="store_true", help="只預覽，不修改檔案。")
    promote_parser.add_argument("--commit", action="store_true", help="promote 成功後 commit master 變更。")
    promote_parser.add_argument("-m", "--message", default="", help="promote --commit 使用的 commit message。")

    reset_parser = subparsers.add_parser("reset-all", help="用正式資料夾覆蓋全部工作位置。")
    reset_parser.add_argument("--dry-run", action="store_true", help="只預覽，不修改檔案。")

    undo_parser = subparsers.add_parser("undo-last", help="還原最近一次可還原操作。")
    undo_parser.add_argument("--dry-run", action="store_true", help="只預覽，不修改檔案。")
    undo_parser.add_argument("--yes", action="store_true", help="確認執行 undo。未指定時只會顯示預覽。")

    commit_parser = subparsers.add_parser("commit", help="Commit master 變更。")
    commit_parser.add_argument("-m", "--message", required=True, help="Commit message，不可空白。")
    commit_parser.add_argument("--dry-run", action="store_true", help="只預覽 git status，不執行 commit。")

    clean_parser = subparsers.add_parser("clean-backups", help="清理舊備份。")
    clean_parser.add_argument("--dry-run", action="store_true", help="只列出將清理的備份。")
    clean_parser.add_argument("--yes", action="store_true", help="確認刪除舊備份。")
    return parser


def apply_worker_override(config: FlowConfig, max_workers: int | None) -> FlowConfig:
    if max_workers is None:
        return config
    if max_workers < 1:
        raise FlowError("--max-workers 必須大於 0", EXIT_CONFIG)
    return FlowConfig(**{**asdict(config), "max_workers": min(max_workers, 32)})


def load_config(config_path: Path) -> FlowConfig:
    config_path = config_path.expanduser().resolve(strict=False)
    if not config_path.exists():
        raise FlowError(
            f"找不到設定檔: {config_path}",
            EXIT_CONFIG,
            ["請確認 --config 指向正確檔案。", "可先執行 config-check 檢查設定。"],
        )
    if not config_path.is_file():
        raise FlowError(f"設定檔不是一般檔案: {config_path}", EXIT_CONFIG)
    if config_path.suffix.lower() == ".toml":
        return load_toml_config(config_path)
    return load_legacy_config(config_path)


def load_toml_config(config_path: Path) -> FlowConfig:
    try:
        import tomllib
    except ModuleNotFoundError as exc:  # pragma: no cover - Python < 3.11 only
        raise FlowError("目前 Python 版本不支援 tomllib；請使用 Python 3.11+ 或改用 txt config。", EXIT_CONFIG) from exc
    data = tomllib.loads(config_path.read_text(encoding="utf-8"))
    config_dir = config_path.parent.resolve(strict=False)
    master_raw = data.get("master_folder") or data.get("MASTER_FOLDER")
    files_raw = data.get("files") or data.get("FILES")
    locations_raw = data.get("locations") or {}
    if not master_raw:
        raise FlowError("TOML config 缺少 master_folder", EXIT_CONFIG)
    if not files_raw:
        raise FlowError("TOML config 缺少 files", EXIT_CONFIG)
    if not isinstance(files_raw, list):
        raise FlowError("TOML config 的 files 必須是字串陣列。", EXIT_CONFIG)
    if not isinstance(locations_raw, dict) or not locations_raw:
        raise FlowError("TOML config 的 [locations] 至少要設定一個工作位置。", EXIT_CONFIG)
    backup = data.get("backup") or {}
    performance = data.get("performance") or {}
    return FlowConfig(
        config_dir=config_dir,
        config_path=config_path,
        master_folder=resolve_folder_path(config_dir, str(master_raw)),
        files=parse_file_list(config_dir, ",".join(str(item) for item in files_raw)),
        locations={str(name): resolve_folder_path(config_dir, str(path)) for name, path in locations_raw.items()},
        max_workers=parse_int_value(performance.get("max_workers"), DEFAULT_MAX_WORKERS, "performance.max_workers"),
        backup_keep_last=parse_optional_int(backup.get("keep_last"), "backup.keep_last"),
        backup_keep_days=parse_optional_int(backup.get("keep_days"), "backup.keep_days"),
        use_hash_cache=parse_bool_value(performance.get("use_hash_cache"), False),
        format="toml",
    )


def load_legacy_config(config_path: Path) -> FlowConfig:
    raw_values: dict[str, str] = {}
    for lineno, raw_line in enumerate(config_path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise FlowError(f"第 {lineno} 行格式錯誤，應為 KEY=VALUE", EXIT_CONFIG)
        key, value = [part.strip() for part in line.split("=", 1)]
        if not key:
            raise FlowError(f"第 {lineno} 行缺少鍵名", EXIT_CONFIG)
        if key in raw_values:
            raise FlowError(f"設定檔重複定義: {key}", EXIT_CONFIG)
        if not value:
            raise FlowError(f"{key} 沒有值", EXIT_CONFIG)
        raw_values[key] = value

    missing = [key for key in ("MASTER_FOLDER", "FILES") if key not in raw_values]
    if missing:
        raise FlowError(f"設定檔缺少必要欄位: {', '.join(missing)}", EXIT_CONFIG)

    config_dir = config_path.parent.resolve(strict=False)
    return FlowConfig(
        config_dir=config_dir,
        config_path=config_path,
        master_folder=resolve_folder_path(config_dir, raw_values["MASTER_FOLDER"]),
        files=parse_file_list(config_dir, raw_values["FILES"]),
        locations=parse_locations(config_dir, raw_values),
        max_workers=parse_int_value(raw_values.get("MAX_WORKERS"), DEFAULT_MAX_WORKERS, "MAX_WORKERS"),
        backup_keep_last=parse_optional_int(raw_values.get("BACKUP_KEEP_LAST"), "BACKUP_KEEP_LAST"),
        backup_keep_days=parse_optional_int(raw_values.get("BACKUP_KEEP_DAYS"), "BACKUP_KEEP_DAYS"),
        use_hash_cache=parse_bool_value(raw_values.get("USE_HASH_CACHE"), False),
        format="txt",
    )


def parse_int_value(value: Any, default: int, label: str) -> int:
    if value in (None, ""):
        return default
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise FlowError(f"{label} 必須是整數。", EXIT_CONFIG) from exc
    if parsed < 1:
        raise FlowError(f"{label} 必須大於 0。", EXIT_CONFIG)
    return min(parsed, 32)


def parse_optional_int(value: Any, label: str) -> int | None:
    if value in (None, ""):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise FlowError(f"{label} 必須是整數。", EXIT_CONFIG) from exc
    if parsed < 0:
        raise FlowError(f"{label} 不能小於 0。", EXIT_CONFIG)
    return parsed


def parse_bool_value(value: Any, default: bool) -> bool:
    if value in (None, ""):
        return default
    if isinstance(value, bool):
        return value
    normalized = str(value).strip().lower()
    if normalized in {"true", "1", "yes", "y", "on"}:
        return True
    if normalized in {"false", "0", "no", "n", "off"}:
        return False
    return default


def parse_file_list(config_dir: Path, value: str) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    for item in [part.strip() for part in value.split(",")]:
        if not item:
            raise FlowError("FILES 裡有空白項目，請刪掉多餘的逗號。", EXIT_CONFIG)
        candidate = Path(item)
        if candidate.is_absolute():
            raise FlowError(f"FILES 只能放相對檔名，不能是完整路徑: {item}", EXIT_CONFIG)
        resolved = resolve_child_path(config_dir, candidate, "FILES")
        try:
            rel = resolved.relative_to(config_dir)
        except ValueError as exc:
            raise FlowError(f"FILES 內的檔名不能跳出設定檔所在資料夾: {item}", EXIT_CONFIG) from exc
        normalized = rel.as_posix()
        if normalized in seen:
            raise FlowError(f"FILES 重複列出相同檔名: {item}", EXIT_CONFIG)
        files.append(rel)
        seen.add(normalized)
    if not files:
        raise FlowError("FILES 不能是空的。", EXIT_CONFIG)
    return files


def parse_locations(config_dir: Path, raw_values: dict[str, str]) -> dict[str, Path]:
    locations: dict[str, Path] = {}
    for key, value in raw_values.items():
        if key in RESERVED_CONFIG_KEYS:
            continue
        if re.search(r"\s", key):
            raise FlowError(f"工作位置名稱不能包含空白: {key}", EXIT_CONFIG)
        locations[key] = resolve_folder_path(config_dir, value)
    if not locations:
        raise FlowError("至少要設定一個工作位置，例如 A=... 或 B=...", EXIT_CONFIG)
    return locations


def resolve_folder_path(config_dir: Path, raw_path: str) -> Path:
    candidate = Path(raw_path).expanduser()
    if candidate.is_absolute():
        return candidate.resolve(strict=False)
    return (config_dir / candidate).resolve(strict=False)


def resolve_child_path(base_folder: Path, relative_path: Path, label: str) -> Path:
    if relative_path.is_absolute():
        raise FlowError(f"{label} 不能使用完整路徑: {relative_path}", EXIT_CONFIG)
    base_folder = base_folder.resolve(strict=False)
    target = (base_folder / relative_path).resolve(strict=False)
    try:
        target.relative_to(base_folder)
    except ValueError as exc:
        raise FlowError(f"{label} 不能跳出資料夾範圍: {relative_path.as_posix()}", EXIT_CONFIG) from exc
    return target


def build_file_entries(config: FlowConfig) -> list[FileEntry]:
    entries: list[FileEntry] = []
    for relative_file in config.files:
        master_path = resolve_child_path(config.master_folder, relative_file, "MASTER_FOLDER")
        location_paths = {
            name: resolve_child_path(folder, relative_file, f"工作位置 {name}")
            for name, folder in config.locations.items()
        }
        entries.append(FileEntry(relative_file.as_posix(), relative_file, master_path, location_paths))
    return entries


def compute_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def get_file_state(path: Path, *, need_hash: bool = True) -> FileState:
    try:
        stat = path.stat()
    except FileNotFoundError:
        return FileState(path=path, exists=False, status=STATUS_MISSING)
    except PermissionError as exc:
        return FileState(path=path, exists=False, status=STATUS_PERMISSION_DENIED, error=str(exc))
    except OSError as exc:
        return FileState(path=path, exists=False, status=STATUS_UNREADABLE, error=str(exc))
    if not path.is_file():
        return FileState(path=path, exists=False, status=STATUS_UNREADABLE, error="不是一般檔案")
    sha = None
    status = STATUS_OK
    if need_hash:
        try:
            sha = compute_sha256(path)
        except PermissionError as exc:
            status = STATUS_PERMISSION_DENIED
            return FileState(path=path, exists=True, size=stat.st_size, mtime_ns=stat.st_mtime_ns, status=status, error=str(exc))
        except OSError as exc:
            status = STATUS_UNREADABLE
            return FileState(path=path, exists=True, size=stat.st_size, mtime_ns=stat.st_mtime_ns, status=status, error=str(exc))
    return FileState(path=path, exists=True, sha256=sha, size=stat.st_size, mtime_ns=stat.st_mtime_ns, status=status)


def build_file_records(config: FlowConfig) -> list[FileRecord]:
    entries = build_file_entries(config)
    jobs: list[tuple[str, str, Path, FileEntry | None]] = []
    for entry in entries:
        jobs.append((entry.relative_file.as_posix(), "master", entry.master_path, entry))
        for location, path in entry.location_paths.items():
            jobs.append((entry.relative_file.as_posix(), location, path, entry))
    state_map: dict[tuple[str, str], FileState] = {}
    with ThreadPoolExecutor(max_workers=config.max_workers) as executor:
        future_map = {executor.submit(get_file_state, path): (rel, label) for rel, label, path, _entry in jobs}
        for future in as_completed(future_map):
            rel, label = future_map[future]
            state_map[(rel, label)] = future.result()
    records: list[FileRecord] = []
    for entry in entries:
        master = state_map[(entry.relative_file.as_posix(), "master")]
        locations: dict[str, FileState] = {}
        for name in entry.location_paths:
            state = state_map[(entry.relative_file.as_posix(), name)]
            status = classify_location_state(master, state)
            locations[name] = FileState(**{**asdict(state), "status": status})
        records.append(FileRecord(entry, master, locations, get_git_status_for_path(config.master_folder, entry.master_path)))
    return records


def classify_location_state(master: FileState, location: FileState) -> str:
    if not location.exists:
        return location.status or STATUS_MISSING
    if not master.exists:
        return STATUS_UNKNOWN
    if location.error:
        return location.status or STATUS_UNREADABLE
    if master.sha256 and location.sha256 and master.sha256 == location.sha256:
        return STATUS_SAME
    return STATUS_DIFFERENT


def get_git_root(path: Path) -> Path | None:
    target = path if path.is_dir() else path.parent
    try:
        completed = subprocess.run(
            ["git", "-C", str(target), "rev-parse", "--show-toplevel"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
    except OSError:
        return None
    if completed.returncode != 0:
        return None
    return Path(completed.stdout.strip()).resolve(strict=False)


def get_git_status_for_path(repo_hint: Path, path: Path) -> str:
    git_root = get_git_root(repo_hint)
    if git_root is None:
        return "Git repo 不可用"
    try:
        rel = path.resolve(strict=False).relative_to(git_root)
    except ValueError:
        return "不在 Git repo 內"
    completed = subprocess.run(
        ["git", "-C", str(git_root), "status", "--porcelain", "--", rel.as_posix()],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if completed.returncode != 0:
        return f"Git status 失敗: {completed.stderr.strip()}"
    line = completed.stdout.strip()
    if not line:
        return "clean"
    code = line[:2]
    if code == "??":
        return STATUS_UNTRACKED
    if "D" in code:
        return STATUS_DELETED
    if "M" in code:
        return STATUS_MODIFIED
    return code.strip() or STATUS_UNKNOWN


def collect_status_summary(records: Iterable[FileRecord]) -> dict[str, int]:
    summary = {"same": 0, "different": 0, "missing": 0, "errors": 0, "unknown": 0}
    for record in records:
        if not record.master.exists:
            summary["missing"] += 1
        for state in record.locations.values():
            if state.status == STATUS_SAME:
                summary["same"] += 1
            elif state.status == STATUS_DIFFERENT:
                summary["different"] += 1
            elif state.status == STATUS_MISSING:
                summary["missing"] += 1
            elif state.status in {STATUS_PERMISSION_DENIED, STATUS_UNREADABLE, STATUS_ERROR}:
                summary["errors"] += 1
            else:
                summary["unknown"] += 1
    return summary


def get_status_result(config_path: Path | str | None = None, *, max_workers: int | None = None, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    records = tuple(build_file_records(config))
    summary = collect_status_summary(records)
    success = summary["different"] == 0 and summary["missing"] == 0 and summary["errors"] == 0
    suggestions = build_suggestions_for_summary(summary)
    output = format_status_output(config, records, summary)
    result = CommandResult(
        title="檔案同步狀態",
        operation="status",
        success=success,
        exit_code=EXIT_OK if success else EXIT_VERIFY,
        message="所有檔案已同步。" if success else "部分檔案尚未同步或缺失。",
        output=output,
        config=config,
        records=records,
        suggestions=tuple(suggestions),
        warnings=tuple([] if success else ["狀態檢查發現不同步、缺檔或不可讀檔案。"]),
        metadata={"summary": summary, "timestamp": iso_now()},
        elapsed_seconds=time.perf_counter() - start,
    )
    if write_log:
        write_operation_log(result)
    return result


def get_verify_result(config_path: Path | str | None = None, *, max_workers: int | None = None, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    records = tuple(build_file_records(config))
    problems: list[str] = []
    for record in records:
        rel = record.entry.relative_file.as_posix()
        if not record.master.exists:
            problems.append(f"Master 缺少檔案: {rel}")
            continue
        if record.master.status in {STATUS_PERMISSION_DENIED, STATUS_UNREADABLE}:
            problems.append(f"Master 無法讀取: {record.master.path} ({record.master.error})")
        for location, state in record.locations.items():
            if not state.exists:
                problems.append(f"{location} 缺少檔案: {rel}")
            elif state.status == STATUS_DIFFERENT:
                problems.append(f"{location}/{rel} 與 Master 不同")
            elif state.status in {STATUS_PERMISSION_DENIED, STATUS_UNREADABLE}:
                problems.append(f"{location}/{rel} 無法讀取: {state.error}")
    success = not problems
    result = CommandResult(
        title="驗證同步結果",
        operation="verify",
        success=success,
        exit_code=EXIT_OK if success else EXIT_VERIFY,
        message="驗證通過，所有檔案一致。" if success else "驗證失敗，請先處理問題。",
        output=format_verify_output(records, problems),
        config=config,
        problems=tuple(problems),
        records=records,
        errors=tuple(problems),
        suggestions=tuple(build_verify_suggestions(problems)),
        metadata={"timestamp": iso_now()},
        elapsed_seconds=time.perf_counter() - start,
    )
    if write_log:
        write_operation_log(result)
    return result


def build_suggestions_for_summary(summary: dict[str, int]) -> list[str]:
    if summary["errors"]:
        return ["請先執行 config-check，確認路徑與權限。"]
    if summary["missing"]:
        return ["若 Master 是正確版本，可以使用 reset-all 補齊缺失檔案。", "若某個工作位置才是正確版本，請先確認後 promote。"]
    if summary["different"]:
        return ["請先比較 Master 與不同步的工作位置。", "確認正確來源後再 promote 或 reset-all。"]
    return ["目前看起來已同步；可視需要 commit Master 變更。"]


def build_verify_suggestions(problems: Iterable[str]) -> list[str]:
    problems = list(problems)
    if not problems:
        return ["驗證已通過，可視需要 commit Master 變更。"]
    suggestions = ["請先查看狀態表格與 diff，確認哪一份是正確版本。"]
    if any("缺少" in problem for problem in problems):
        suggestions.append("若 Master 是正確版本，可使用 reset-all 補齊缺檔。")
    if any("不同" in problem for problem in problems):
        suggestions.append("若某個工作位置是正確版本，可使用 promote 將它推進成 Master。")
    return suggestions


def format_status_output(config: FlowConfig, records: Iterable[FileRecord], summary: dict[str, int]) -> str:
    lines = [
        "檔案同步狀態",
        f"Config: {config.config_path}",
        f"Master: {config.master_folder}",
        f"Locations: {', '.join(config.locations)}",
        f"Summary: same={summary['same']} different={summary['different']} missing={summary['missing']} errors={summary['errors']}",
        "",
    ]
    for record in records:
        lines.append(f"[{record.entry.relative_file.as_posix()}]")
        lines.append(format_state_line("Master", record.master))
        for location, state in record.locations.items():
            lines.append(format_state_line(location, state))
        lines.append(f"  Git: {record.git_status}")
    return "\n".join(lines)


def format_state_line(label: str, state: FileState) -> str:
    if not state.exists:
        return f"  {label}: {state.status} - {state.path}"
    return f"  {label}: {state.status} size={state.size} sha={short_hash(state.sha256)} path={state.path}"


def format_verify_output(records: Iterable[FileRecord], problems: Iterable[str]) -> str:
    problems = list(problems)
    if not problems:
        return "驗證通過，所有工作位置都與 Master 相同。"
    return "驗證失敗：\n" + "\n".join(f"- {problem}" for problem in problems)


def config_check(config_path: Path | str | None = None, *, max_workers: int | None = None, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []
    suggestions: list[str] = []
    config: FlowConfig | None = None
    try:
        config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    except FlowError as exc:
        errors.append(str(exc))
        suggestions.extend(exc.suggestions or ["請修正設定檔格式後重新執行 config-check。"])
        return CommandResult(
            title="設定檢查",
            operation="config-check",
            success=False,
            exit_code=exc.exit_code,
            message="設定檔讀取失敗。",
            output=format_config_check_output(errors, warnings, info, suggestions),
            errors=tuple(errors),
            warnings=tuple(warnings),
            suggestions=tuple(suggestions),
            elapsed_seconds=time.perf_counter() - start,
        )
    if not config.master_folder.exists():
        errors.append(f"MASTER_FOLDER 不存在: {config.master_folder}")
        suggestions.append("請建立 master folder，或修正 MASTER_FOLDER 路徑。")
    elif not config.master_folder.is_dir():
        errors.append(f"MASTER_FOLDER 不是資料夾: {config.master_folder}")
    else:
        info.append(f"MASTER_FOLDER 存在: {config.master_folder}")
    for relative_file in config.files:
        if relative_file.is_absolute() or ".." in relative_file.parts:
            errors.append(f"FILES 包含不安全路徑: {relative_file}")
        master_file = config.master_folder / relative_file
        if not master_file.exists():
            warnings.append(f"Master 目前缺少 tracked file: {relative_file.as_posix()}")
    if len({file.as_posix() for file in config.files}) != len(config.files):
        errors.append("FILES 有重複項目。")
    for name, folder in config.locations.items():
        if not folder.exists():
            warnings.append(f"工作位置 {name} 不存在: {folder}")
        elif not folder.is_dir():
            errors.append(f"工作位置 {name} 不是資料夾: {folder}")
        if paths_overlap(config.master_folder, folder):
            errors.append(f"工作位置 {name} 與 MASTER_FOLDER 重疊，這很危險: {folder}")
    location_items = list(config.locations.items())
    for index, (left_name, left_path) in enumerate(location_items):
        for right_name, right_path in location_items[index + 1:]:
            if paths_overlap(left_path, right_path):
                errors.append(f"工作位置 {left_name} 與 {right_name} 互相重疊。")
    git_root = get_git_root(config.master_folder)
    if git_root is None:
        warnings.append("Master folder 不在可用的 Git repo 中；commit 功能會停用，但同步功能仍可使用。")
    else:
        info.append(f"Git repo: {git_root}")
    for folder_name in (BACKUP_DIR_NAME, LOG_DIR_NAME):
        folder = config.config_dir / folder_name
        try:
            folder.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=folder, delete=True):
                pass
            info.append(f"{folder_name} 可寫入: {folder}")
        except OSError as exc:
            errors.append(f"{folder_name} 無法寫入: {folder} ({exc})")
    if not errors:
        suggestions.append("設定檢查完成；若只有 warning，可依使用情境決定是否修正。")
    result = CommandResult(
        title="設定檢查",
        operation="config-check",
        success=not errors,
        exit_code=EXIT_OK if not errors else EXIT_CONFIG,
        message="設定檢查通過。" if not errors else "設定檢查失敗。",
        output=format_config_check_output(errors, warnings, info, suggestions),
        config=config,
        errors=tuple(errors),
        warnings=tuple(warnings),
        suggestions=tuple(suggestions),
        metadata={"info": info, "timestamp": iso_now()},
        elapsed_seconds=time.perf_counter() - start,
    )
    if write_log:
        write_operation_log(result)
    return result


def paths_overlap(left: Path, right: Path) -> bool:
    left_resolved = left.resolve(strict=False)
    right_resolved = right.resolve(strict=False)
    try:
        left_resolved.relative_to(right_resolved)
        return True
    except ValueError:
        pass
    try:
        right_resolved.relative_to(left_resolved)
        return True
    except ValueError:
        return False


def format_config_check_output(errors: list[str], warnings: list[str], info: list[str], suggestions: list[str]) -> str:
    lines: list[str] = []
    if errors:
        lines.append("Errors:")
        lines.extend(f"- {item}" for item in errors)
    if warnings:
        lines.append("Warnings:")
        lines.extend(f"- {item}" for item in warnings)
    if info:
        lines.append("Info:")
        lines.extend(f"- {item}" for item in info)
    if suggestions:
        lines.append("Suggestions:")
        lines.extend(f"- {item}" for item in suggestions)
    return "\n".join(lines) or "設定檢查沒有發現問題。"


def build_transfer_plan(config: FlowConfig, source_label: str, destination_pairs: list[tuple[str, Path]], *, source_base: Path) -> list[TransferItem]:
    items: list[TransferItem] = []
    for relative_file in config.files:
        source = resolve_child_path(source_base, relative_file, source_label)
        for destination_label, destination_base in destination_pairs:
            destination = resolve_child_path(destination_base, relative_file, destination_label)
            items.append(plan_single_transfer(relative_file, source_label, source, destination_label, destination))
    return items


def plan_single_transfer(relative_file: Path, source_label: str, source: Path, destination_label: str, destination: Path) -> TransferItem:
    source_state = get_file_state(source, need_hash=False)
    if not source_state.exists:
        return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_ERROR, "source missing or unreadable", error=source_state.error or "source missing")
    destination_state = get_file_state(destination, need_hash=False)
    if not destination_state.exists:
        return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_COPIED, "destination missing", size=source_state.size)
    if destination_state.status in {STATUS_PERMISSION_DENIED, STATUS_UNREADABLE}:
        return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_ERROR, "destination unreadable", size=source_state.size, error=destination_state.error)
    if source_state.size != destination_state.size:
        return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_COPIED, "size differs", size=source_state.size)
    source_hash = compute_sha256(source)
    destination_hash = compute_sha256(destination)
    if source_hash == destination_hash:
        return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_SKIPPED, "unchanged", size=source_state.size, source_sha256=source_hash, destination_sha256=destination_hash)
    return TransferItem(relative_file.as_posix(), source_label, destination_label, str(source), str(destination), STATUS_COPIED, "hash differs", size=source_state.size, source_sha256=source_hash, destination_sha256=destination_hash)


def preflight_source_files(config: FlowConfig, base: Path, label: str) -> list[str]:
    errors: list[str] = []
    for relative_file in config.files:
        state = get_file_state(resolve_child_path(base, relative_file, label), need_hash=False)
        if not state.exists:
            errors.append(f"{label} 缺少或無法讀取 {relative_file.as_posix()}: {state.error or state.status}")
    return errors


def backup_destination_files(config: FlowConfig, items: Iterable[TransferItem], operation: str) -> tuple[Path, dict[str, str]]:
    backup_dir = config.config_dir / BACKUP_DIR_NAME / f"{now_timestamp()}-{operation}"
    backup_files: dict[str, str] = {}
    for item in items:
        destination = Path(item.destination)
        if item.action != STATUS_COPIED or not destination.exists() or not destination.is_file():
            continue
        label = sanitize_filename(item.destination_label)
        backup_path = backup_dir / label / item.relative_file
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(destination, backup_path)
        backup_files[str(destination)] = str(backup_path)
        item.backup_path = str(backup_path)
    return backup_dir, backup_files


def sanitize_filename(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_") or "item"


def atomic_copy_file(source: Path, destination: Path, *, progress_callback: ProgressCallback | None = None, item_index: int = 1, total_items: int = 1) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    tmp = destination.parent / f".fileflow_tmp_{destination.name}_{uuid.uuid4().hex}"
    total = source.stat().st_size
    copied = 0
    try:
        with source.open("rb") as src, tmp.open("wb") as dst:
            while True:
                chunk = src.read(COPY_CHUNK_SIZE)
                if not chunk:
                    break
                dst.write(chunk)
                copied += len(chunk)
                if progress_callback:
                    progress_callback({
                        "source": str(source),
                        "destination": str(destination),
                        "copied_bytes": copied,
                        "total_bytes": total,
                        "current_file": source.name,
                        "current_item_index": item_index,
                        "total_item_count": total_items,
                    })
        shutil.copystat(source, tmp)
        source_hash = compute_sha256(source)
        tmp_hash = compute_sha256(tmp)
        if source_hash != tmp_hash:
            raise FlowError(f"Atomic copy 驗證失敗: {source} -> {destination} tmp={tmp}", EXIT_FAILURE)
        os.replace(tmp, destination)
    except Exception:
        try:
            if tmp.exists():
                tmp.unlink()
        finally:
            raise


def execute_transfer_plan(config: FlowConfig, plan: list[TransferItem], *, progress_callback: ProgressCallback | None = None) -> tuple[list[str], list[str], list[str]]:
    copied: list[str] = []
    skipped: list[str] = []
    failed: list[str] = []
    copy_items = [item for item in plan if item.action == STATUS_COPIED]
    skipped.extend(format_transfer_label(item) for item in plan if item.action == STATUS_SKIPPED)
    failed.extend(f"{format_transfer_label(item)} - {item.error or item.reason}" for item in plan if item.action == STATUS_ERROR)

    def run_one(index_item: tuple[int, TransferItem]) -> tuple[TransferItem, str, str]:
        index, item = index_item
        try:
            atomic_copy_file(Path(item.source), Path(item.destination), progress_callback=progress_callback, item_index=index, total_items=len(copy_items))
            return item, STATUS_COPIED, ""
        except Exception as exc:  # noqa: BLE001 - preserve full failure reason for user
            return item, STATUS_ERROR, str(exc)

    if copy_items:
        with ThreadPoolExecutor(max_workers=min(config.max_workers, max(1, len(copy_items)))) as executor:
            futures = [executor.submit(run_one, (index, item)) for index, item in enumerate(copy_items, start=1)]
            for future in as_completed(futures):
                item, status, error = future.result()
                if status == STATUS_COPIED:
                    copied.append(format_transfer_label(item))
                else:
                    item.error = error
                    failed.append(f"{format_transfer_label(item)} - {error}")
    return copied, skipped, failed


def format_transfer_label(item: TransferItem) -> str:
    return f"{item.relative_file}: {item.source_label} -> {item.destination_label}"


def perform_promote(
    source: str,
    config_path: Path | str | None = None,
    *,
    show_diff: bool = False,
    dry_run: bool = False,
    progress_callback: ProgressCallback | None = None,
    commit_message: str = "",
    auto_commit: bool = False,
    max_workers: int | None = None,
) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    if source not in config.locations:
        return failure_result("Promote 失敗", "promote", f"未知工作位置: {source}", EXIT_CONFIG, config=config, suggestions=["請確認 source location 名稱是否存在於 config。"])
    preflight_errors = preflight_source_files(config, config.locations[source], source)
    if preflight_errors:
        return failure_result("Promote 失敗", "promote", "來源檔案不完整，已停止。", EXIT_VERIFY, config=config, errors=preflight_errors, suggestions=["請確認來源 location 是否為正確版本。"])
    master_plan = build_transfer_plan(config, source, [("Master", config.master_folder)], source_base=config.locations[source])
    # In dry-run, locations should be planned from the source-derived master content. Same file paths and hashes are sufficient for preview.
    location_plan = build_transfer_plan(config, "Master", list(config.locations.items()), source_base=config.locations[source])
    full_plan = master_plan + location_plan
    diff_text = get_diff_preview_result(source, config_path, max_workers=max_workers, write_log=False).diff_text if show_diff else ""
    if dry_run:
        result = CommandResult(
            title=f"Promote {source} 預覽",
            operation="promote-dry-run",
            success=not any(item.action == STATUS_ERROR for item in full_plan),
            exit_code=EXIT_OK,
            message="dry-run 完成，沒有修改任何檔案。",
            output=format_plan_output(full_plan, f"Promote {source} dry-run"),
            config=config,
            planned_files=tuple(full_plan),
            diff_text=diff_text,
            warnings=tuple(item.error for item in full_plan if item.action == STATUS_ERROR),
            suggestions=("確認預覽無誤後，再執行 promote。",),
            metadata={"dry_run": True, "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        write_operation_log(result)
        return result
    backup_dir, backup_files = backup_destination_files(config, full_plan, "promote")
    copied_master, skipped_master, failed_master = execute_transfer_plan(config, master_plan, progress_callback=progress_callback)
    if failed_master:
        result = CommandResult(
            title=f"Promote {source} 失敗",
            operation="promote",
            success=False,
            exit_code=EXIT_FAILURE,
            message="source -> master 階段失敗，已停止同步到其他 locations。",
            output="\n".join(failed_master),
            config=config,
            backup_dir=backup_dir,
            copied_files=tuple(copied_master),
            skipped_files=tuple(skipped_master),
            failed_files=tuple(failed_master),
            planned_files=tuple(full_plan),
            errors=tuple(failed_master),
            suggestions=("請檢查檔案權限、磁碟空間與 temporary file 是否可寫。",),
            metadata={"backup_files": backup_files, "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        write_operation_log(result)
        return result
    master_verify_errors = verify_master_equals_source(config, config.locations[source], source)
    if master_verify_errors:
        result = CommandResult(
            title=f"Promote {source} 失敗",
            operation="promote",
            success=False,
            exit_code=EXIT_VERIFY,
            message="Master 更新後驗證失敗，已停止同步到其他 locations。",
            output="\n".join(master_verify_errors),
            config=config,
            backup_dir=backup_dir,
            copied_files=tuple(copied_master),
            skipped_files=tuple(skipped_master),
            failed_files=tuple(master_verify_errors),
            planned_files=tuple(full_plan),
            errors=tuple(master_verify_errors),
            metadata={"backup_files": backup_files, "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        write_operation_log(result)
        return result
    copied_locations, skipped_locations, failed_locations = execute_transfer_plan(config, location_plan, progress_callback=progress_callback)
    verify_result = get_verify_result(config.config_path, max_workers=config.max_workers, write_log=False)
    success = not failed_locations and verify_result.success
    copied = copied_master + copied_locations
    skipped = skipped_master + skipped_locations
    failed = failed_locations + list(verify_result.problems)
    message = f"已採用 {source} 的內容，並重新驗證。" if success else "Promote 部分完成，但驗證或同步有問題。"
    result = CommandResult(
        title=f"Promote {source}",
        operation="promote",
        success=success,
        exit_code=EXIT_OK if success else EXIT_VERIFY,
        message=message,
        output=format_operation_summary("Promote", copied, skipped, failed, backup_dir, verify_result.success),
        config=config,
        records=verify_result.records,
        backup_dir=backup_dir,
        copied_files=tuple(copied),
        skipped_files=tuple(skipped),
        failed_files=tuple(failed),
        planned_files=tuple(full_plan),
        errors=tuple(failed),
        suggestions=tuple(["建議 Commit Master 變更。", "建議重新掃描狀態。"] if success else build_verify_suggestions(failed)),
        metadata={"backup_files": backup_files, "timestamp": iso_now(), "source": source},
        elapsed_seconds=time.perf_counter() - start,
    )
    write_operation_log(result)
    cleanup_backups(config, dry_run=False, write_log=False)
    if auto_commit and success:
        if not commit_message.strip():
            result.warnings += ("已要求 --commit，但 commit message 為空，已略過 commit。",)
        else:
            commit_result = perform_commit(commit_message, config.config_path, max_workers=config.max_workers, write_log=True)
            result.metadata["commit"] = command_result_to_json(commit_result)
    return result


def verify_master_equals_source(config: FlowConfig, source_base: Path, source_label: str) -> list[str]:
    errors: list[str] = []
    for relative_file in config.files:
        source = get_file_state(resolve_child_path(source_base, relative_file, source_label), need_hash=True)
        master = get_file_state(resolve_child_path(config.master_folder, relative_file, "Master"), need_hash=True)
        if not source.exists or not master.exists or source.sha256 != master.sha256:
            errors.append(f"Master 與 {source_label} 不一致: {relative_file.as_posix()}")
    return errors


def perform_reset_all(
    config_path: Path | str | None = None,
    *,
    dry_run: bool = False,
    progress_callback: ProgressCallback | None = None,
    max_workers: int | None = None,
) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    preflight_errors = preflight_source_files(config, config.master_folder, "Master")
    if preflight_errors:
        return failure_result("Reset All 失敗", "reset-all", "Master 檔案不完整，已停止。", EXIT_VERIFY, config=config, errors=preflight_errors, suggestions=["請先修復 Master 檔案，或 promote 正確工作位置。"])
    plan = build_transfer_plan(config, "Master", list(config.locations.items()), source_base=config.master_folder)
    if dry_run:
        result = CommandResult(
            title="Reset All 預覽",
            operation="reset-all-dry-run",
            success=not any(item.action == STATUS_ERROR for item in plan),
            exit_code=EXIT_OK,
            message="dry-run 完成，沒有修改任何檔案。",
            output=format_plan_output(plan, "Reset All dry-run"),
            config=config,
            planned_files=tuple(plan),
            warnings=tuple(item.error for item in plan if item.action == STATUS_ERROR),
            suggestions=("確認預覽無誤後，再執行 reset-all。",),
            metadata={"dry_run": True, "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        write_operation_log(result)
        return result
    backup_dir, backup_files = backup_destination_files(config, plan, "reset-all")
    copied, skipped, failed = execute_transfer_plan(config, plan, progress_callback=progress_callback)
    verify_result = get_verify_result(config.config_path, max_workers=config.max_workers, write_log=False)
    failed = failed + list(verify_result.problems)
    success = not failed and verify_result.success
    result = CommandResult(
        title="Reset All",
        operation="reset-all",
        success=success,
        exit_code=EXIT_OK if success else EXIT_VERIFY,
        message="全部 location 已用 Master 更新並通過驗證。" if success else "Reset All 部分完成，但有問題需要處理。",
        output=format_operation_summary("Reset All", copied, skipped, failed, backup_dir, verify_result.success),
        config=config,
        records=verify_result.records,
        backup_dir=backup_dir,
        copied_files=tuple(copied),
        skipped_files=tuple(skipped),
        failed_files=tuple(failed),
        planned_files=tuple(plan),
        errors=tuple(failed),
        suggestions=tuple(["建議重新掃描狀態。", "若 Master 變更需要追蹤，請 Commit Master 變更。"] if success else build_verify_suggestions(failed)),
        metadata={"backup_files": backup_files, "timestamp": iso_now()},
        elapsed_seconds=time.perf_counter() - start,
    )
    write_operation_log(result)
    cleanup_backups(config, dry_run=False, write_log=False)
    return result


def failure_result(title: str, operation: str, message: str, exit_code: int, *, config: FlowConfig | None = None, errors: Iterable[str] = (), suggestions: Iterable[str] = ()) -> CommandResult:
    errors = tuple(errors or (message,))
    return CommandResult(
        title=title,
        operation=operation,
        success=False,
        exit_code=exit_code,
        message=message,
        output="\n".join(errors),
        config=config,
        errors=errors,
        suggestions=tuple(suggestions),
        metadata={"timestamp": iso_now()},
    )


def format_plan_output(plan: Iterable[TransferItem], title: str) -> str:
    lines = [title, ""]
    for item in plan:
        label = "COPY" if item.action == STATUS_COPIED else "SKIP" if item.action == STATUS_SKIPPED else "ERROR"
        lines.append(f"[{label}] {item.relative_file}: {item.source_label} -> {item.destination_label} ({item.reason})")
        lines.append(f"    source: {item.source}")
        lines.append(f"    destination: {item.destination}")
        if item.error:
            lines.append(f"    error: {item.error}")
    return "\n".join(lines)


def format_operation_summary(operation: str, copied: list[str], skipped: list[str], failed: list[str], backup_dir: Path | None, verify_success: bool) -> str:
    lines = [f"{operation} 結果", "", f"Copied: {len(copied)}", f"Skipped unchanged: {len(skipped)}", f"Failed: {len(failed)}"]
    if backup_dir:
        lines.append(f"Backup: {backup_dir}")
    lines.append(f"Verify: {'通過' if verify_success else '失敗'}")
    if copied:
        lines.append("\nCopied files:")
        lines.extend(f"- {item}" for item in copied)
    if skipped:
        lines.append("\nSkipped files:")
        lines.extend(f"- {item}" for item in skipped)
    if failed:
        lines.append("\nFailed files:")
        lines.extend(f"- {item}" for item in failed)
    return "\n".join(lines)


def is_binary_file(path: Path, sample_size: int = 4096) -> bool:
    try:
        sample = path.read_bytes()[:sample_size]
    except OSError:
        return True
    if b"\x00" in sample:
        return True
    try:
        sample.decode("utf-8")
        return False
    except UnicodeDecodeError:
        return True


def get_diff_preview_result(source: str, config_path: Path | str | None = None, *, max_workers: int | None = None, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    if source not in config.locations:
        return failure_result("Diff 失敗", "diff", f"未知工作位置: {source}", EXIT_CONFIG, config=config)
    lines: list[str] = []
    summary: list[str] = []
    for relative_file in config.files:
        master = config.master_folder / relative_file
        candidate = config.locations[source] / relative_file
        if not master.exists() or not candidate.exists():
            summary.append(f"{relative_file.as_posix()}: missing")
            lines.append(f"## {relative_file.as_posix()}\n檔案缺失，無法比較。")
            continue
        if is_binary_file(master) or is_binary_file(candidate):
            left = get_file_state(master)
            right = get_file_state(candidate)
            summary.append(f"{relative_file.as_posix()}: binary differs")
            lines.append(
                "\n".join([
                    f"## {relative_file.as_posix()}",
                    "binary file differs",
                    f"master size: {left.size}",
                    f"source size: {right.size}",
                    f"master sha256: {short_hash(left.sha256)}",
                    f"source sha256: {short_hash(right.sha256)}",
                ])
            )
            continue
        completed = subprocess.run(
            ["git", "diff", "--no-index", "--", str(master), str(candidate)],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        diff = completed.stdout if completed.stdout else completed.stderr
        added = sum(1 for line in diff.splitlines() if line.startswith("+") and not line.startswith("+++"))
        removed = sum(1 for line in diff.splitlines() if line.startswith("-") and not line.startswith("---"))
        status = "same" if completed.returncode == 0 else "different"
        summary.append(f"{relative_file.as_posix()}: {status}, +{added}, -{removed}")
        if len(diff) > 20000:
            diff = diff[:20000] + "\n... diff 太長，已截斷 ..."
        lines.append(f"## {relative_file.as_posix()}\nSummary: +{added}, -{removed}\n{diff or '無差異'}")
    diff_text = "Diff summary:\n" + "\n".join(f"- {item}" for item in summary) + "\n\n" + "\n\n".join(lines)
    result = CommandResult(
        title=f"比較 Master 與 {source}",
        operation="diff",
        success=True,
        exit_code=EXIT_OK,
        message="Diff preview 完成。",
        output=diff_text,
        diff_text=diff_text,
        config=config,
        suggestions=("請確認 diff 後再執行 promote 或 reset-all。",),
        metadata={"timestamp": iso_now(), "source": source},
        elapsed_seconds=time.perf_counter() - start,
    )
    if write_log:
        write_operation_log(result)
    return result


def perform_commit(message: str, config_path: Path | str | None = None, *, dry_run: bool = False, max_workers: int | None = None, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    if not message.strip():
        return failure_result("Commit 失敗", "commit", "Commit message 不可為空。", EXIT_CONFIG, config=config)
    verify_result = get_verify_result(config.config_path, max_workers=config.max_workers, write_log=False)
    if not verify_result.success:
        return failure_result("Commit 失敗", "commit", "commit 前 verify 失敗。", EXIT_VERIFY, config=config, errors=verify_result.problems, suggestions=build_verify_suggestions(verify_result.problems))
    git_root = get_git_root(config.master_folder)
    if git_root is None:
        return failure_result("Commit 失敗", "commit", "Master folder 不在可用的 Git repo 中。", EXIT_GIT, config=config, suggestions=["若不需要 Git，可忽略 commit 功能。"])
    rels = [(config.master_folder / file).resolve(strict=False).relative_to(git_root).as_posix() for file in config.files]
    status = subprocess.run(["git", "-C", str(git_root), "status", "--short", "--", *rels], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if dry_run:
        result = CommandResult(
            title="Commit 預覽",
            operation="commit-dry-run",
            success=True,
            exit_code=EXIT_OK,
            message="dry-run 完成，沒有執行 git add / commit。",
            output=status.stdout or "沒有 master 變更。",
            config=config,
            metadata={"dry_run": True, "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        if write_log:
            write_operation_log(result)
        return result
    if not status.stdout.strip():
        result = CommandResult(
            title="Commit Master 變更",
            operation="commit",
            success=True,
            exit_code=EXIT_OK,
            message="沒有變更可 commit。",
            output="Git working tree clean for tracked master files.",
            config=config,
            suggestions=("沒有需要 commit 的 master 變更。",),
            metadata={"timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        if write_log:
            write_operation_log(result)
        return result
    add = subprocess.run(["git", "-C", str(git_root), "add", "--", *rels], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if add.returncode != 0:
        return failure_result("Commit 失敗", "commit", f"git add 失敗: {add.stderr.strip()}", EXIT_GIT, config=config)
    commit = subprocess.run(["git", "-C", str(git_root), "commit", "-m", message], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    success = commit.returncode == 0
    result = CommandResult(
        title="Commit Master 變更",
        operation="commit",
        success=success,
        exit_code=EXIT_OK if success else EXIT_GIT,
        message="Commit 完成。" if success else "Commit 失敗。",
        output=(commit.stdout + "\n" + commit.stderr).strip(),
        config=config,
        errors=tuple([] if success else [commit.stderr.strip() or commit.stdout.strip()]),
        suggestions=tuple(["Commit 已完成。"] if success else ["請檢查 git stderr，確認 repo 狀態。"]),
        metadata={"timestamp": iso_now(), "git_root": str(git_root)},
        elapsed_seconds=time.perf_counter() - start,
    )
    if write_log:
        write_operation_log(result)
    return result


def write_operation_log(result: CommandResult) -> None:
    config = result.config
    if config is None:
        return
    log_dir = config.config_dir / LOG_DIR_NAME
    log_dir.mkdir(parents=True, exist_ok=True)
    name = f"{now_timestamp()}-{sanitize_filename(result.operation or result.title)}"
    json_path = log_dir / f"{name}.json"
    log_path = log_dir / f"{name}.log"
    data = command_result_to_json(result)
    json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    log_path.write_text(format_human_result(result), encoding="utf-8")
    result.operation_json_path = json_path
    result.operation_log_path = log_path


def format_human_result(result: CommandResult) -> str:
    lines = [result.title, "=" * len(result.title), "", f"Success: {result.success}", f"Message: {result.message}", f"Elapsed: {result.elapsed_seconds:.3f}s", ""]
    if result.output:
        lines.extend(["Output:", result.output, ""])
    if result.suggestions:
        lines.append("Suggestions:")
        lines.extend(f"- {item}" for item in result.suggestions)
    return "\n".join(lines)


def find_last_restorable_log(config: FlowConfig) -> dict[str, Any] | None:
    log_dir = config.config_dir / LOG_DIR_NAME
    if not log_dir.exists():
        return None
    for path in sorted(log_dir.glob("*.json"), reverse=True):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        backup_files = data.get("metadata", {}).get("backup_files") or {}
        if backup_files:
            data["__path"] = str(path)
            return data
    return None


def perform_undo_last(config_path: Path | str | None = None, *, dry_run: bool = True, yes: bool = False, progress_callback: ProgressCallback | None = None, max_workers: int | None = None) -> CommandResult:
    start = time.perf_counter()
    config = apply_worker_override(load_config(resolve_config_path(config_path)), max_workers)
    data = find_last_restorable_log(config)
    if data is None:
        return failure_result("Undo Last", "undo-last", "沒有可還原的操作。", EXIT_FAILURE, config=config, suggestions=["只有包含 backup_files 的 promote/reset 操作可以還原。"])
    backup_files: dict[str, str] = data.get("metadata", {}).get("backup_files") or {}
    plan = [TransferItem(Path(destination).name, "Backup", "Original", backup, destination, STATUS_COPIED, "restore from backup") for destination, backup in backup_files.items()]
    if dry_run or not yes:
        result = CommandResult(
            title="Undo Last 預覽",
            operation="undo-last-dry-run",
            success=True,
            exit_code=EXIT_OK,
            message="這是 undo preview；未指定 --yes 時不會修改檔案。",
            output=format_plan_output(plan, "Undo Last dry-run"),
            config=config,
            planned_files=tuple(plan),
            suggestions=("確認後執行 undo-last --yes。",),
            metadata={"dry_run": True, "source_log": data.get("__path"), "timestamp": iso_now()},
            elapsed_seconds=time.perf_counter() - start,
        )
        write_operation_log(result)
        return result
    copied, skipped, failed = execute_transfer_plan(config, plan, progress_callback=progress_callback)
    result = CommandResult(
        title="Undo Last",
        operation="undo-last",
        success=not failed,
        exit_code=EXIT_OK if not failed else EXIT_FAILURE,
        message="Undo 完成。" if not failed else "Undo 部分失敗。",
        output=format_operation_summary("Undo Last", copied, skipped, failed, None, not failed),
        config=config,
        copied_files=tuple(copied),
        skipped_files=tuple(skipped),
        failed_files=tuple(failed),
        planned_files=tuple(plan),
        errors=tuple(failed),
        metadata={"source_log": data.get("__path"), "timestamp": iso_now()},
        elapsed_seconds=time.perf_counter() - start,
    )
    write_operation_log(result)
    return result


def cleanup_backups(config: FlowConfig, *, dry_run: bool = True, yes: bool = False, write_log: bool = True) -> CommandResult:
    start = time.perf_counter()
    backup_root = config.config_dir / BACKUP_DIR_NAME
    keep_last = config.backup_keep_last
    keep_days = config.backup_keep_days
    if not backup_root.exists():
        return CommandResult("清理舊備份", True, EXIT_OK, "沒有備份資料夾。", operation="clean-backups", config=config)
    backups = [path for path in backup_root.iterdir() if path.is_dir()]
    backups.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    protected: set[Path] = set()
    last_log = find_last_restorable_log(config)
    if last_log:
        for backup in (last_log.get("metadata", {}).get("backup_files") or {}).values():
            backup_path = Path(backup).resolve(strict=False)
            try:
                relative = backup_path.relative_to(backup_root.resolve(strict=False))
            except ValueError:
                continue
            if relative.parts:
                protected.add(backup_root / relative.parts[0])
    cutoff = time.time() - keep_days * 86400 if keep_days is not None else None
    to_delete: list[Path] = []
    for index, backup in enumerate(backups):
        if backup.resolve(strict=False) in {item.resolve(strict=False) for item in protected}:
            continue
        if keep_last is not None and index < keep_last:
            continue
        if cutoff is not None and backup.stat().st_mtime >= cutoff:
            continue
        to_delete.append(backup)
    output = "\n".join(str(path) for path in to_delete) if to_delete else "沒有需要清理的備份。"
    if dry_run or not yes:
        result = CommandResult("清理舊備份預覽", True, EXIT_OK, "dry-run 完成，未刪除任何備份。", output, operation="clean-backups-dry-run", config=config, metadata={"to_delete": [str(p) for p in to_delete], "timestamp": iso_now()}, elapsed_seconds=time.perf_counter() - start)
        if write_log:
            write_operation_log(result)
        return result
    failed: list[str] = []
    for path in to_delete:
        try:
            shutil.rmtree(path)
        except OSError as exc:
            failed.append(f"{path}: {exc}")
    result = CommandResult("清理舊備份", not failed, EXIT_OK if not failed else EXIT_FAILURE, "清理完成。" if not failed else "部分備份清理失敗。", output, operation="clean-backups", config=config, failed_files=tuple(failed), errors=tuple(failed), metadata={"deleted": [str(p) for p in to_delete], "timestamp": iso_now()}, elapsed_seconds=time.perf_counter() - start)
    if write_log:
        write_operation_log(result)
    return result


def save_legacy_config(config_path: Path, master_folder: str, files: list[str], locations: dict[str, str], *, max_workers: int = DEFAULT_MAX_WORKERS, backup_keep_last: int | None = None, backup_keep_days: int | None = None) -> None:
    if config_path.exists():
        backup = config_path.with_suffix(config_path.suffix + f".{now_timestamp()}.bak")
        shutil.copy2(config_path, backup)
    lines = ["# 正式資料夾", f"MASTER_FOLDER={master_folder}", "", "# 要管理的檔名清單，以逗號分隔", f"FILES={','.join(files)}", "", "# 效能與備份", f"MAX_WORKERS={max_workers}"]
    if backup_keep_last is not None:
        lines.append(f"BACKUP_KEEP_LAST={backup_keep_last}")
    if backup_keep_days is not None:
        lines.append(f"BACKUP_KEEP_DAYS={backup_keep_days}")
    lines.extend(["", "# 工作位置"])
    lines.extend(f"{name}={path}" for name, path in locations.items())
    config_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run_interactive_flow(config_path: Path) -> int:
    print(get_status_result(config_path).output)
    answer = input("要執行 reset-all 嗎？(y/n): ").strip().lower()
    if answer in YES_WORDS:
        preview = perform_reset_all(config_path, dry_run=True)
        print(preview.output)
        confirm = input("輸入 RESET 確認執行: ").strip()
        if confirm == "RESET":
            print(perform_reset_all(config_path).output)
            return EXIT_OK
    return EXIT_OK


def print_result(result: CommandResult, *, json_output: bool = False) -> None:
    if json_output:
        print(json.dumps(command_result_to_json(result), ensure_ascii=False, indent=2))
    else:
        print(format_human_result(result))


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    json_requested = "--json" in raw_argv
    if json_requested:
        raw_argv = [item for item in raw_argv if item != "--json"]
    args = parser.parse_args(raw_argv)
    args.json = bool(getattr(args, "json", False) or json_requested)
    try:
        config_path = resolve_config_path(args.config)
        if args.command == "status":
            result = get_status_result(config_path, max_workers=args.max_workers)
        elif args.command == "verify":
            result = get_verify_result(config_path, max_workers=args.max_workers)
        elif args.command == "config-check":
            result = config_check(config_path, max_workers=args.max_workers)
        elif args.command == "promote":
            result = perform_promote(args.source, config_path, show_diff=args.diff, dry_run=args.dry_run, auto_commit=args.commit, commit_message=args.message, max_workers=args.max_workers)
        elif args.command == "reset-all":
            result = perform_reset_all(config_path, dry_run=args.dry_run, max_workers=args.max_workers)
        elif args.command == "undo-last":
            result = perform_undo_last(config_path, dry_run=args.dry_run or not args.yes, yes=args.yes, max_workers=args.max_workers)
        elif args.command == "commit":
            result = perform_commit(args.message, config_path, dry_run=args.dry_run, max_workers=args.max_workers)
        elif args.command == "clean-backups":
            config = apply_worker_override(load_config(config_path), args.max_workers)
            result = cleanup_backups(config, dry_run=args.dry_run or not args.yes, yes=args.yes)
        elif args.command == "flow":
            return run_interactive_flow(config_path)
        else:  # pragma: no cover
            parser.error("unknown command")
            return EXIT_FAILURE
        print_result(result, json_output=args.json)
        return result.exit_code
    except FlowError as exc:
        result = failure_result("FileFlow 錯誤", "error", str(exc), exc.exit_code, suggestions=exc.suggestions)
        print_result(result, json_output=getattr(args, "json", False))
        return exc.exit_code
    except KeyboardInterrupt:
        print("已取消。", file=sys.stderr)
        return EXIT_FAILURE


if __name__ == "__main__":
    raise SystemExit(main())
