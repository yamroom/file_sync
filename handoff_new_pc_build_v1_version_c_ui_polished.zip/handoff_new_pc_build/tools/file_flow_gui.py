from __future__ import annotations

import argparse
import html
import sys
from pathlib import Path
from typing import Any, Callable

try:
    from PySide6.QtCore import QObject, QThread, Qt, QTimer, QUrl, Signal, Slot
    from PySide6.QtGui import QAction, QColor, QDesktopServices
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QHeaderView,
        QInputDialog,
        QLabel,
        QMainWindow,
        QMenu,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QTableWidget,
        QTableWidgetItem,
        QTextBrowser,
        QToolButton,
        QVBoxLayout,
        QWidget,
    )
    PYSIDE6_IMPORT_ERROR: ModuleNotFoundError | None = None
except ModuleNotFoundError as exc:  # pragma: no cover - depends on runtime image
    QObject = object  # type: ignore[assignment]
    QThread = object  # type: ignore[assignment]
    Qt = object  # type: ignore[assignment]
    QTimer = object  # type: ignore[assignment]
    QUrl = object  # type: ignore[assignment]

    def Signal(*_args, **_kwargs):  # type: ignore[override]
        return None

    def Slot(*_args, **_kwargs):  # type: ignore[override]
        def decorator(function):
            return function
        return decorator

    QApplication = object  # type: ignore[assignment]
    QAction = object  # type: ignore[assignment]
    QComboBox = object  # type: ignore[assignment]
    QFrame = object  # type: ignore[assignment]
    QGridLayout = object  # type: ignore[assignment]
    QHBoxLayout = object  # type: ignore[assignment]
    QHeaderView = object  # type: ignore[assignment]
    QInputDialog = object  # type: ignore[assignment]
    QLabel = object  # type: ignore[assignment]
    QMainWindow = object  # type: ignore[assignment]
    QMenu = object  # type: ignore[assignment]
    QMessageBox = object  # type: ignore[assignment]
    QProgressBar = object  # type: ignore[assignment]
    QPushButton = object  # type: ignore[assignment]
    QTableWidget = object  # type: ignore[assignment]
    QTableWidgetItem = object  # type: ignore[assignment]
    QTextBrowser = object  # type: ignore[assignment]
    QToolButton = object  # type: ignore[assignment]
    QVBoxLayout = object  # type: ignore[assignment]
    QWidget = object  # type: ignore[assignment]
    QColor = object  # type: ignore[assignment]
    QDesktopServices = object  # type: ignore[assignment]
    PYSIDE6_IMPORT_ERROR = exc

from . import file_flow

APP_TITLE = "FileFlow"

STATUS_COLORS = {
    file_flow.STATUS_SAME: "#EAF7EF",
    file_flow.STATUS_OK: "#EAF7EF",
    file_flow.STATUS_COPIED: "#EAF2FF",
    file_flow.STATUS_SKIPPED: "#F1F5F7",
    file_flow.STATUS_DIFFERENT: "#FFF5D6",
    file_flow.STATUS_MISSING: "#FFE8E1",
    file_flow.STATUS_PERMISSION_DENIED: "#FFE8E1",
    file_flow.STATUS_UNREADABLE: "#FFE8E1",
    file_flow.STATUS_ERROR: "#FFE8E1",
    file_flow.STATUS_UNKNOWN: "#F1F5F7",
}

STATUS_TEXT = {
    file_flow.STATUS_OK: "OK",
    file_flow.STATUS_SAME: "OK",
    file_flow.STATUS_DIFFERENT: "Diff",
    file_flow.STATUS_MISSING: "Miss",
    file_flow.STATUS_PERMISSION_DENIED: "Err",
    file_flow.STATUS_UNREADABLE: "Err",
    file_flow.STATUS_UNTRACKED: "New",
    file_flow.STATUS_MODIFIED: "Mod",
    file_flow.STATUS_DELETED: "Del",
    file_flow.STATUS_ERROR: "Err",
    file_flow.STATUS_UNKNOWN: "Unknown",
    file_flow.STATUS_SKIPPED: "Skip",
    file_flow.STATUS_COPIED: "Copy",
}

APP_STYLESHEET = """
QWidget {
    background: #F6F8F7;
    color: #1F2A2D;
    font-family: "Inter", "Segoe UI", "Noto Sans CJK TC", "Microsoft JhengHei", sans-serif;
    font-size: 12px;
}
QMainWindow { background: #F6F8F7; }
QLabel { background: transparent; color: #1F2A2D; }
QLabel#Title {
    color: #102529;
    font-size: 22px;
    font-weight: 800;
    letter-spacing: -0.2px;
}
QLabel#Subtitle, QLabel#Muted, QLabel#MetaText {
    color: #6B7A7E;
    font-size: 11px;
}
QLabel#SectionTitle {
    color: #24383D;
    font-size: 12px;
    font-weight: 800;
}
QLabel#StatusPill {
    border-radius: 11px;
    padding: 4px 10px;
    font-weight: 800;
    background: #EAF7EF;
    color: #17643A;
}
QLabel#TinyPill {
    border-radius: 9px;
    padding: 3px 8px;
    color: #415155;
    background: #F0F4F3;
    font-weight: 700;
}
QLabel#SuggestionText {
    color: #2F464B;
    font-size: 11px;
    font-weight: 600;
}
QFrame#HeaderCard, QFrame#SummaryCard, QFrame#MatrixCard, QFrame#ActionCard, QFrame#DetailCard {
    background: #FFFFFF;
    border: 1px solid #E1E8E6;
    border-radius: 16px;
}
QFrame#ActionCard {
    background: #FBFCFC;
}
QPushButton, QToolButton {
    min-height: 27px;
    color: #223538;
    background: #EEF4F2;
    border: 1px solid #DCE6E3;
    border-radius: 12px;
    padding: 4px 10px;
    font-weight: 750;
}
QPushButton:hover, QToolButton:hover { background: #E5EEEB; }
QPushButton:pressed, QToolButton:pressed { background: #D8E5E1; }
QPushButton:disabled, QToolButton:disabled {
    background: #F3F6F5;
    color: #A4B0B3;
    border-color: #E9EFED;
}
QPushButton#PrimaryButton {
    background: #0F6E76;
    color: white;
    border: 1px solid #0F6E76;
}
QPushButton#PrimaryButton:hover { background: #0B5F66; }
QPushButton#DangerButton {
    background: #FFF1EB;
    color: #9B3C1B;
    border: 1px solid #FFD4C2;
}
QPushButton#DangerButton:hover { background: #FFE6DA; }
QToolButton#MoreButton {
    background: #FFFFFF;
    color: #223538;
}
QComboBox {
    min-height: 26px;
    background: #FFFFFF;
    color: #213236;
    border: 1px solid #DCE6E3;
    border-radius: 10px;
    padding: 4px 9px;
    font-weight: 650;
}
QComboBox::drop-down { border: 0; width: 20px; }
QMenu {
    background: #FFFFFF;
    border: 1px solid #DCE6E3;
    border-radius: 10px;
    padding: 6px;
}
QMenu::item {
    padding: 7px 18px;
    border-radius: 8px;
    color: #25383D;
}
QMenu::item:selected { background: #EAF2F0; }
QTableWidget {
    background: #FFFFFF;
    border: 0;
    gridline-color: #EEF3F1;
    selection-background-color: #E7F1FF;
    selection-color: #102529;
    alternate-background-color: #FAFCFB;
}
QTableWidget::item {
    border-bottom: 1px solid #EEF3F1;
    padding: 5px;
}
QHeaderView::section {
    background: #F1F5F4;
    color: #34494E;
    border: 0;
    border-bottom: 1px solid #E2EAE7;
    padding: 6px;
    font-weight: 800;
}
QTextBrowser {
    background: #FCFDFD;
    color: #23363A;
    border: 1px solid #E1E8E6;
    border-radius: 12px;
    padding: 8px;
    font-family: "Cascadia Mono", "Consolas", monospace;
    font-size: 10px;
}
QProgressBar {
    border: 0;
    border-radius: 5px;
    height: 6px;
    background: #EAF0EE;
}
QProgressBar::chunk { border-radius: 5px; background: #0F6E76; }
QScrollBar:vertical {
    background: transparent;
    width: 9px;
    margin: 2px;
}
QScrollBar::handle:vertical {
    background: #C8D4D1;
    border-radius: 4px;
    min-height: 22px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { height: 0; background: transparent; }
"""


class Worker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(object)

    def __init__(self, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        super().__init__()
        self.action = action
        self.with_progress = with_progress

    @Slot()
    def run(self) -> None:
        try:
            if self.with_progress:
                self.finished.emit(self.action(self.progress.emit))
            else:
                self.finished.emit(self.action())
        except Exception as exc:  # noqa: BLE001 - GUI should report user-facing errors
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, config_path: Path | None = None) -> None:
        super().__init__()
        self.config_path = file_flow.resolve_config_path(config_path)
        self.config: file_flow.FlowConfig | None = None
        self.last_result: file_flow.CommandResult | None = None
        self.last_log_path: Path | None = None
        self.last_backup_path: Path | None = None
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self.log_expanded = False
        self.setWindowTitle(APP_TITLE)
        self.setMinimumSize(512, 384)
        self._resize_to_quarter_screen()
        self.setStyleSheet(APP_STYLESHEET)
        self._build_ui()
        self.run_background("重新檢查", lambda: file_flow.get_status_result(self.config_path))

    def _resize_to_quarter_screen(self) -> None:
        app = QApplication.instance()
        screen = app.primaryScreen() if app else None
        if screen is None:
            self.resize(512, 384)
            return
        area = screen.availableGeometry()
        width = max(512, int(area.width() * 0.5))
        height = max(384, int(area.height() * 0.5))
        self.resize(width, height)

    def _build_ui(self) -> None:
        root = QWidget()
        main = QVBoxLayout(root)
        main.setContentsMargins(12, 12, 12, 12)
        main.setSpacing(8)

        # Header: compact product identity + profile/workspace + status + more menu.
        header = QFrame()
        header.setObjectName("HeaderCard")
        header.setFixedHeight(62)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(14, 10, 12, 10)
        header_layout.setSpacing(8)

        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        self.title_label = QLabel("FileFlow")
        self.title_label.setObjectName("Title")
        self.master_label = QLabel("Master: 載入中…")
        self.master_label.setObjectName("Subtitle")
        self.master_label.setToolTip(str(self.config_path))
        title_box.addWidget(self.title_label)
        title_box.addWidget(self.master_label)
        header_layout.addLayout(title_box, 1)

        self.source_combo = QComboBox()
        self.source_combo.setMinimumWidth(72)
        self.source_combo.setMaximumWidth(110)
        self.source_combo.setToolTip("選擇要和 Master 比較或更新的工作區")
        self.source_combo.currentIndexChanged.connect(self.update_button_states)
        self.status_pill = QLabel("尚未檢查")
        self.status_pill.setObjectName("StatusPill")
        self.btn_advanced = QToolButton()
        self.btn_advanced.setObjectName("MoreButton")
        self.btn_advanced.setText("更多 ▾")
        self.btn_advanced.setPopupMode(QToolButton.InstantPopup)
        header_layout.addWidget(self.source_combo)
        header_layout.addWidget(self.status_pill)
        header_layout.addWidget(self.btn_advanced)
        main.addWidget(header, 0)
        self._build_advanced_menu()

        # Summary strip: one card, short text only.
        summary_card = QFrame()
        summary_card.setObjectName("SummaryCard")
        summary_card.setFixedHeight(36)
        summary_layout = QHBoxLayout(summary_card)
        summary_layout.setContentsMargins(12, 7, 12, 7)
        summary_layout.setSpacing(8)
        self.summary_label = QLabel("0 files · 0 workspaces · Last scan: -")
        self.summary_label.setObjectName("MetaText")
        self.missing_pill = QLabel("Miss 0")
        self.missing_pill.setObjectName("TinyPill")
        self.diff_pill = QLabel("Diff 0")
        self.diff_pill.setObjectName("TinyPill")
        summary_layout.addWidget(self.summary_label, 1)
        summary_layout.addWidget(self.diff_pill)
        summary_layout.addWidget(self.missing_pill)
        main.addWidget(summary_card, 0)

        # Matrix card: the main information area.
        matrix_panel = QFrame()
        matrix_panel.setObjectName("MatrixCard")
        matrix_layout = QVBoxLayout(matrix_panel)
        matrix_layout.setContentsMargins(10, 9, 10, 8)
        matrix_layout.setSpacing(6)
        matrix_header = QHBoxLayout()
        matrix_header.setSpacing(8)
        matrix_title = QLabel("同步矩陣")
        matrix_title.setObjectName("SectionTitle")
        self.detail_label = QLabel("點選格子可查看完整資訊")
        self.detail_label.setObjectName("Muted")
        self.detail_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        self.detail_label.setWordWrap(False)
        matrix_header.addWidget(matrix_title)
        matrix_header.addStretch(1)
        matrix_header.addWidget(self.detail_label, 1)
        matrix_layout.addLayout(matrix_header)

        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["File", "Master"])
        self.table.setMinimumHeight(94)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectItems)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table.itemSelectionChanged.connect(self.show_selected_cell_detail)
        matrix_layout.addWidget(self.table, 1)
        main.addWidget(matrix_panel, 1)

        # Actions: four main controls in one compact row.
        action_card = QFrame()
        action_card.setObjectName("ActionCard")
        action_card.setFixedHeight(48)
        action_bar = QHBoxLayout(action_card)
        action_bar.setContentsMargins(10, 7, 10, 7)
        action_bar.setSpacing(8)
        self.btn_status = QPushButton("重新檢查")
        self.btn_diff = QPushButton("看差異")
        self.btn_promote = QPushButton("更新 Master")
        self.btn_reset = QPushButton("還原工作區")
        self.btn_promote.setObjectName("PrimaryButton")
        self.btn_reset.setObjectName("DangerButton")
        self.btn_status.setToolTip("重新掃描 Master 與工作區狀態，不修改檔案")
        self.btn_diff.setToolTip("查看選定工作區與 Master 的差異，不修改檔案")
        self.btn_promote.setToolTip("用選定工作區更新 Master，執行前會要求確認")
        self.btn_reset.setToolTip("用 Master 覆蓋所有工作區，執行前會要求確認")
        for button in [self.btn_status, self.btn_diff, self.btn_promote, self.btn_reset]:
            action_bar.addWidget(button)
        main.addWidget(action_card, 0)

        # Bottom: one-line suggestion, compact progress, collapsible log.
        bottom = QFrame()
        bottom.setObjectName("DetailCard")
        bottom.setFixedHeight(62)
        bottom_layout = QVBoxLayout(bottom)
        bottom_layout.setContentsMargins(10, 7, 10, 8)
        bottom_layout.setSpacing(5)
        bottom_top = QHBoxLayout()
        bottom_top.setSpacing(8)
        self.next_action_label = QLabel("建議：先重新檢查。")
        self.next_action_label.setObjectName("SuggestionText")
        self.progress_label = QLabel("等待操作")
        self.progress_label.setObjectName("Muted")
        self.btn_toggle_log = QToolButton()
        self.btn_toggle_log.setText("詳細紀錄 ▾")
        self.btn_toggle_log.clicked.connect(self.toggle_log)
        bottom_top.addWidget(self.next_action_label, 1)
        bottom_top.addWidget(self.progress_label)
        bottom_top.addWidget(self.btn_toggle_log)
        bottom_layout.addLayout(bottom_top)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        bottom_layout.addWidget(self.progress)
        self.output = QTextBrowser()
        self.output.setMaximumHeight(0)
        self.output.setVisible(False)
        self.output.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.output.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.output.setPlaceholderText("操作紀錄會顯示在這裡。")
        bottom_layout.addWidget(self.output)
        main.addWidget(bottom, 0)

        self.setCentralWidget(root)

        self.btn_status.clicked.connect(lambda: self.run_background("重新檢查", lambda: file_flow.get_status_result(self.config_path)))
        self.btn_diff.clicked.connect(self.run_diff)
        self.btn_promote.clicked.connect(lambda: self.run_promote(dry_run=False))
        self.btn_reset.clicked.connect(lambda: self.run_reset(dry_run=False))
        self.update_button_states()

    def _build_advanced_menu(self) -> None:
        menu = QMenu(self)
        self.act_verify = QAction("檢查同步", self)
        self.act_preview_promote = QAction("預覽更新", self)
        self.act_preview_reset = QAction("預覽還原", self)
        self.act_commit = QAction("記錄版本", self)
        self.act_undo = QAction("復原上次", self)
        self.act_config_check = QAction("檢查設定", self)
        self.act_edit_config = QAction("編輯設定", self)
        self.act_clean_backups = QAction("清理備份", self)
        self.act_open_log = QAction("操作紀錄", self)
        self.act_open_backup = QAction("開啟備份", self)
        self.act_copy_summary = QAction("複製摘要", self)
        for action in [
            self.act_verify,
            self.act_preview_promote,
            self.act_preview_reset,
            self.act_commit,
            self.act_undo,
            self.act_config_check,
            self.act_edit_config,
            self.act_clean_backups,
        ]:
            menu.addAction(action)
        menu.addSeparator()
        for action in [self.act_open_log, self.act_open_backup, self.act_copy_summary]:
            menu.addAction(action)
        self.btn_advanced.setMenu(menu)
        self.act_verify.triggered.connect(lambda: self.run_background("檢查同步", lambda: file_flow.get_verify_result(self.config_path)))
        self.act_config_check.triggered.connect(lambda: self.run_background("檢查設定", lambda: file_flow.config_check(self.config_path)))
        self.act_preview_promote.triggered.connect(lambda: self.run_promote(dry_run=True))
        self.act_preview_reset.triggered.connect(lambda: self.run_reset(dry_run=True))
        self.act_commit.triggered.connect(self.run_commit)
        self.act_undo.triggered.connect(self.run_undo)
        self.act_clean_backups.triggered.connect(self.run_clean_backups)
        self.act_open_log.triggered.connect(lambda: self.open_path(self.last_log_path))
        self.act_open_backup.triggered.connect(lambda: self.open_path(self.last_backup_path))
        self.act_copy_summary.triggered.connect(self.copy_summary)
        self.act_edit_config.triggered.connect(self.edit_config)

    @staticmethod
    def _short_path(path: Path | str | None, *, keep: int = 3) -> str:
        if path is None:
            return "-"
        text = str(path).replace("\\", "/")
        parts = [part for part in text.split("/") if part]
        if len(parts) <= keep:
            return text
        return ".../" + "/".join(parts[-keep:])

    def toggle_log(self) -> None:
        self.log_expanded = not self.log_expanded
        self.output.setVisible(self.log_expanded)
        self.output.setMaximumHeight(96 if self.log_expanded else 0)
        self.btn_toggle_log.setText("詳細紀錄 ▴" if self.log_expanded else "詳細紀錄 ▾")

    def set_busy(self, busy: bool, label: str = "") -> None:
        controls = [self.btn_status, self.btn_diff, self.btn_promote, self.btn_reset, self.btn_advanced]
        for control in controls:
            control.setEnabled(not busy)
        self.progress_label.setText(label or ("執行中" if busy else "等待操作"))
        if busy:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
        self.update_button_states()

    def update_button_states(self) -> None:
        if self.thread is not None:
            return
        has_config = self.config is not None
        has_source = self.source_combo.currentIndex() >= 0
        self.btn_status.setEnabled(True)
        self.btn_diff.setEnabled(has_config and has_source)
        self.btn_promote.setEnabled(has_config and has_source)
        self.btn_reset.setEnabled(has_config)
        self.btn_advanced.setEnabled(True)
        for action in [self.act_verify, self.act_config_check, self.act_edit_config]:
            action.setEnabled(True)
        for action in [self.act_preview_promote, self.act_commit, self.act_undo, self.act_clean_backups, self.act_preview_reset]:
            action.setEnabled(has_config)
        self.act_preview_promote.setEnabled(has_config and has_source)
        self.act_open_log.setEnabled(self.last_log_path is not None and self.last_log_path.exists())
        self.act_open_backup.setEnabled(self.last_backup_path is not None and self.last_backup_path.exists())
        self.act_copy_summary.setEnabled(self.last_result is not None)

    def run_background(self, title: str, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        if self.thread is not None:
            return
        self.set_busy(True, title)
        self.thread = QThread()
        self.worker = Worker(action, with_progress=with_progress)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.failed.connect(self.on_worker_failed)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    @Slot(object)
    def on_worker_finished(self, result: Any) -> None:
        if isinstance(result, file_flow.CommandResult):
            self.apply_result(result)
        else:
            self.output.setPlainText(str(result))

    @Slot(object)
    def on_progress(self, info: object) -> None:
        if not isinstance(info, dict):
            return
        copied = int(info.get("copied_bytes") or 0)
        total = int(info.get("total_bytes") or 0)
        index = int(info.get("current_item_index") or 1)
        count = int(info.get("total_item_count") or 1)
        percent = int(copied * 100 / total) if total else 0
        self.progress.setRange(0, 100)
        self.progress.setValue(percent)
        self.progress_label.setText(f"複製 {index}/{count} · {info.get('current_file', '')} · {percent}%")

    @Slot(str)
    def on_worker_failed(self, message: str) -> None:
        self.output.setHtml(f"<h3>錯誤</h3><pre>{html.escape(message)}</pre>")
        if not self.log_expanded:
            self.toggle_log()
        QMessageBox.critical(self, "錯誤", message)

    @Slot()
    def cleanup_thread(self) -> None:
        self.thread = None
        self.worker = None
        self.set_busy(False)

    def apply_result(self, result: file_flow.CommandResult) -> None:
        self.last_result = result
        self.config = result.config or self.config
        self.last_log_path = result.operation_log_path
        self.last_backup_path = result.backup_dir
        if self.config:
            self.update_config_summary(self.config)
        self.update_overview(result)
        self.update_matrix(result)
        self.output.setHtml(self.result_to_html(result))
        self.update_button_states()

    def update_config_summary(self, config: file_flow.FlowConfig) -> None:
        short_master = self._short_path(config.master_folder, keep=3)
        short_config = self._short_path(config.config_path, keep=2)
        self.master_label.setText(f"Master: {short_master} · {short_config}")
        self.master_label.setToolTip(f"Master: {config.master_folder}\nConfig: {config.config_path}")
        old = [self.source_combo.itemText(i) for i in range(self.source_combo.count())]
        if old != list(config.locations):
            self.source_combo.blockSignals(True)
            self.source_combo.clear()
            for name in config.locations:
                self.source_combo.addItem(name, name)
            self.source_combo.blockSignals(False)

    def update_overview(self, result: file_flow.CommandResult) -> None:
        summary = result.metadata.get("summary", {}) if result.metadata else {}
        different = int(summary.get("different", 0) or 0)
        missing = int(summary.get("missing", 0) or 0)
        errors = int(summary.get("errors", len(result.errors)) or 0)
        config = result.config or self.config
        files_count = len(config.files) if config else 0
        locations_count = len(config.locations) if config else 0
        timestamp = str(result.metadata.get("timestamp", "")) if result.metadata else ""
        scan_time = timestamp[11:16] if len(timestamp) >= 16 else "-"
        self.summary_label.setText(f"{files_count} files · {locations_count} workspaces · Last scan: {scan_time}")
        self.diff_pill.setText(f"Diff {different}")
        self.missing_pill.setText(f"Miss {missing}")
        if result.success and not different and not missing and not errors:
            status = "已同步"
            color = "#EAF7EF"
            text_color = "#17643A"
        elif errors or result.errors:
            status = "設定錯誤" if result.operation == "config-check" else "有錯誤"
            color = "#FFE8E1"
            text_color = "#9B3C1B"
        elif missing:
            status = "有缺檔"
            color = "#FFE8E1"
            text_color = "#9B3C1B"
        elif different:
            status = "有差異"
            color = "#FFF5D6"
            text_color = "#7A5A00"
        else:
            status = "需確認"
            color = "#F0F4F3"
            text_color = "#516064"
        self.status_pill.setText(status)
        self.status_pill.setStyleSheet(
            f"background: {color}; color: {text_color}; border-radius: 11px; padding: 4px 10px; font-weight: 800;"
        )
        suggestion = result.suggestions[0] if result.suggestions else "建議：目前已同步。"
        self.next_action_label.setText(self._short_suggestion(suggestion))

    @staticmethod
    def _short_suggestion(text: str) -> str:
        text = text.replace("若 Master 是正確版本，可以使用 reset-all 補齊缺失檔案。", "建議：先看差異，再決定更新或還原。")
        text = text.replace("若某個工作位置才是正確版本，請先確認後 promote。", "建議：確認正確工作區後再更新 Master。")
        if not text.startswith("建議"):
            text = "建議：" + text
        return text[:52] + ("…" if len(text) > 52 else "")

    def update_matrix(self, result: file_flow.CommandResult) -> None:
        records = list(result.records)
        if not records:
            self.table.setRowCount(0)
            return
        locations = list(records[0].locations)
        headers = ["File", "Master", *locations, "Git"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            file_item = self.make_item(record.entry.relative_file.as_posix(), None)
            file_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            self.table.setItem(row, 0, file_item)
            self.table.setItem(row, 1, self.make_item(record.master.status, record.master))
            for col, location in enumerate(locations, start=2):
                self.table.setItem(row, col, self.make_item(record.locations[location].status, record.locations[location]))
            git_text = record.git_status
            if "Git repo 不可用" in git_text or git_text.strip() in {"", "clean"}:
                git_text = "-"
            elif len(git_text) > 8:
                git_text = git_text[:8] + "…"
            self.table.setItem(row, len(headers) - 1, self.make_item(git_text, None))
        for r in range(self.table.rowCount()):
            self.table.setRowHeight(r, 24)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        for c in range(1, self.table.columnCount()):
            header.setSectionResizeMode(c, QHeaderView.Fixed)
            self.table.setColumnWidth(c, 55)
        self.table.resizeRowsToContents()

    def make_item(self, text: str, state: file_flow.FileState | None) -> QTableWidgetItem:
        visible_text = STATUS_TEXT.get(text, text)
        if state is not None:
            visible_text = STATUS_TEXT.get(state.status, state.status)
        item = QTableWidgetItem(visible_text)
        item.setTextAlignment(Qt.AlignCenter)
        item.setFlags(item.flags() ^ Qt.ItemIsEditable)
        status = state.status if state else text
        item.setBackground(QColor(STATUS_COLORS.get(status, "#FFFFFF")))
        if state:
            item.setData(Qt.UserRole, file_flow.file_state_to_json(state))
            tooltip = [
                f"status: {state.status}",
                f"path: {state.path}",
                f"exists: {state.exists}",
                f"size: {state.size}",
                f"mtime_ns: {state.mtime_ns}",
                f"sha256: {state.sha256 or '-'}",
            ]
            if state.error:
                tooltip.append(f"error: {state.error}")
            item.setToolTip("\n".join(tooltip))
        return item

    def show_selected_cell_detail(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        data = items[0].data(Qt.UserRole)
        if not data:
            self.detail_label.setText(items[0].text())
            return
        full_hash = data.get("sha256") or ""
        path = self._short_path(data.get("path"), keep=3)
        size = data.get("size") if data.get("size") is not None else "-"
        self.detail_label.setText(f"{data.get('status')} · {path} · {size}B · {file_flow.short_hash(full_hash)}")
        self.detail_label.setToolTip(str(data.get("path") or ""))

    def result_to_html(self, result: file_flow.CommandResult) -> str:
        title = html.escape(result.title)
        message = html.escape(result.message)
        badge = "成功" if result.success else "失敗"
        parts = [
            f"<b>{title}</b> ｜ {badge} ｜ copied {result.copied_count} ｜ skipped {result.skipped_count} ｜ failed {result.failed_count}<br>",
            f"{message}",
        ]
        if result.suggestions:
            parts.append("<br>建議：" + html.escape(result.suggestions[0]))
        if result.operation_log_path:
            parts.append("<br>Log: " + html.escape(str(result.operation_log_path)))
        return "".join(parts)

    def selected_source(self) -> str | None:
        return self.source_combo.currentData() or self.source_combo.currentText() or None

    def run_diff(self) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇", "請先選擇工作區。")
            return
        self.run_background("看差異", lambda: file_flow.get_diff_preview_result(source, self.config_path))

    def run_promote(self, *, dry_run: bool) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇", "請先選擇工作區。")
            return
        if not dry_run and not self.confirm_text(
            "更新 Master",
            f"你即將用 {source} 更新 Master，並同步到其他工作區。\n\n會建立備份。請輸入 {source} 確認。",
            source,
        ):
            return
        self.run_background(
            "預覽更新" if dry_run else "更新 Master",
            lambda cb=None: file_flow.perform_promote(source, self.config_path, dry_run=dry_run, progress_callback=cb),
            with_progress=not dry_run,
        )

    def run_reset(self, *, dry_run: bool) -> None:
        if not dry_run and not self.confirm_text(
            "還原工作區",
            "你即將用 Master 覆蓋所有工作區。\n\n請輸入 RESET 確認。",
            "RESET",
        ):
            return
        self.run_background(
            "預覽還原" if dry_run else "還原工作區",
            lambda cb=None: file_flow.perform_reset_all(self.config_path, dry_run=dry_run, progress_callback=cb),
            with_progress=not dry_run,
        )

    def run_commit(self) -> None:
        text, ok = QInputDialog.getText(self, "記錄版本", "版本訊息：")
        if not ok or not text.strip():
            return
        self.run_background("記錄版本", lambda: file_flow.perform_commit(text, self.config_path))

    def run_undo(self) -> None:
        if not self.confirm_text("復原上次", "將還原上一次可還原操作。\n\n請輸入 UNDO 確認。", "UNDO"):
            self.run_background("復原預覽", lambda: file_flow.perform_undo_last(self.config_path, dry_run=True))
            return
        self.run_background(
            "復原上次",
            lambda cb=None: file_flow.perform_undo_last(self.config_path, dry_run=False, yes=True, progress_callback=cb),
            with_progress=True,
        )

    def run_clean_backups(self) -> None:
        if self.config is None:
            return
        if not self.confirm_text("清理備份", "將依照保留策略清理舊備份。\n\n請輸入 CLEAN 確認。", "CLEAN"):
            self.run_background("清理備份預覽", lambda: file_flow.cleanup_backups(self.config, dry_run=True))
            return
        self.run_background("清理備份", lambda: file_flow.cleanup_backups(self.config, dry_run=False, yes=True))

    def confirm_text(self, title: str, message: str, expected: str) -> bool:
        text, ok = QInputDialog.getText(self, title, message)
        return bool(ok and text == expected)

    def open_path(self, path: Path | None) -> None:
        if not path or not path.exists():
            QMessageBox.warning(self, "無法開啟", "路徑不存在。")
            return
        target = path if path.is_dir() else path.parent
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))

    def copy_summary(self) -> None:
        if not self.last_result:
            return
        QApplication.clipboard().setText(file_flow.format_human_result(self.last_result))

    def edit_config(self) -> None:
        if self.config is None:
            return
        QMessageBox.information(self, "編輯設定", "目前會開啟設定檔所在資料夾。修改後請按『檢查設定』與『重新檢查』。")
        self.open_path(self.config.config_path)


def ensure_qt_available() -> None:
    if PYSIDE6_IMPORT_ERROR is not None:
        raise RuntimeError(
            "無法啟動 GUI：缺少 PySide6。請先執行 `python -m pip install PySide6`，或改用 CLI：`python file_flow.py status`。"
        ) from PYSIDE6_IMPORT_ERROR


def main(argv: list[str] | None = None) -> int:
    ensure_qt_available()
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--screenshot", type=Path, default=None)
    parser.add_argument("--help", action="store_true")
    args, qt_args = parser.parse_known_args(argv if argv is not None else sys.argv[1:])
    if args.help:
        print("FileFlow GUI options: --config PATH --smoke-test --screenshot PATH")
        return 0
    app = QApplication([sys.argv[0], *qt_args])
    window = MainWindow(args.config)
    window.show()

    if args.screenshot:
        def capture() -> None:
            args.screenshot.parent.mkdir(parents=True, exist_ok=True)
            window.grab().save(str(args.screenshot))
            app.quit()
        QTimer.singleShot(1400, capture)
        return app.exec()

    if args.smoke_test:
        QTimer.singleShot(900, app.quit)
        return app.exec()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
