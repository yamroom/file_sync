# FileFlow v1 Functional Upgrade Status

This package keeps the original root wrappers and improves the functional FileFlow core, excluding PyInstaller / `.exe` build optimization.

## Completed

- Skip unchanged files before copy using size + SHA-256.
- Atomic copy via temporary file + SHA-256 verification + `os.replace`.
- Parallel file-state scanning and parallel copy using `ThreadPoolExecutor` with conservative `MAX_WORKERS`.
- Progress callback support for chunked copy.
- Preflight and post-verify checks for promote and reset-all.
- Dry-run preview for promote and reset-all.
- Operation logs under `.tool_logs/` in `.json` and `.log` formats.
- Backup support under `.tool_backups/` and undo-last restore from backups.
- Backup retention settings: `BACKUP_KEEP_LAST` and `BACKUP_KEEP_DAYS`.
- CLI `config-check`, `commit`, `undo-last`, `clean-backups`.
- `--json` output for commands through the common result serializer.
- TOML config support while keeping legacy `KEY=VALUE` txt config compatibility.
- Binary diff detection with size / hash summary.
- Short hash display in human-readable output.
- GUI dashboard layout, sync matrix, clearer buttons, dry-run actions, typed confirmations, log / backup shortcuts.
- Unit tests using Python standard-library `unittest`.

## Notes

- GUI config editing currently opens the config location and provides safer validation flow rather than a full structured editor form.
- Profile support is available through CLI `--config` and GUI config selector foundation; full create/copy profile workflow can be expanded later.
- No new heavy runtime dependency was added.

## Validation

Validated with:

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
```

Current test result: 10 tests passed.

## UI refinement: compact dashboard version C

The GUI has been revised to a compact dashboard layout:

- Default window area is one quarter of the screen (`width = 50%`, `height = 50%`).
- Main actions are reduced to four buttons: `重新檢查`, `看差異`, `更新 Master`, `還原工作區`.
- Advanced actions are moved to `進階 ▾`.
- Status, tracked file count, location count, mismatch count, and missing count are shown as compact cards.
- The sync matrix remains visible for debugging, but the UI is less crowded.
- `--smoke-test` and `--screenshot PATH` were added for GUI validation and packaging checks.

A sample TOML config is provided at `file_flow_paths.example.toml`.

## GUI Redesign Follow-up

Implemented a more faithful Version C compact dashboard UI:

- Reworked `tools/file_flow_gui.py` visual hierarchy.
- Replaced dense utility layout with card-based dashboard.
- Kept only four primary buttons on the main screen.
- Moved secondary actions into `更多 ▾`.
- Added compact status badge and summary strip.
- Collapsed detailed logs by default.
- Added full QSS styling for modern card/table/button appearance.
- Verified with actual PySide6 offscreen screenshot.
- Verified PyInstaller Linux executable build and smoke test.

Windows `.exe` verification still requires a Windows environment.
