from __future__ import annotations

import html
import sys
from pathlib import Path
from typing import Any, Callable

try:
    from PySide6.QtCore import QObject, QThread, Qt, QUrl, Signal, Slot
    from PySide6.QtGui import QColor, QDesktopServices
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QFileDialog,
        QFrame,
        QGridLayout,
        QGroupBox,
        QHBoxLayout,
        QHeaderView,
        QInputDialog,
        QLabel,
        QLineEdit,
        QMainWindow,
        QMenu,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QTableWidget,
        QTableWidgetItem,
        QTextBrowser,
        QVBoxLayout,
        QWidget,
    )
    PYSIDE6_IMPORT_ERROR: ModuleNotFoundError | None = None
except ModuleNotFoundError as exc:  # pragma: no cover - depends on runtime image
    QObject = object  # type: ignore[assignment]
    QThread = object  # type: ignore[assignment]
    Qt = object  # type: ignore[assignment]
    QUrl = object  # type: ignore[assignment]

    def Signal(*_args, **_kwargs):  # type: ignore[override]
        return None

    def Slot(*_args, **_kwargs):  # type: ignore[override]
        def decorator(function):
            return function
        return decorator

    QApplication = object  # type: ignore[assignment]
    QComboBox = object  # type: ignore[assignment]
    QFileDialog = object  # type: ignore[assignment]
    QFrame = object  # type: ignore[assignment]
    QGridLayout = object  # type: ignore[assignment]
    QGroupBox = object  # type: ignore[assignment]
    QHBoxLayout = object  # type: ignore[assignment]
    QHeaderView = object  # type: ignore[assignment]
    QInputDialog = object  # type: ignore[assignment]
    QLabel = object  # type: ignore[assignment]
    QLineEdit = object  # type: ignore[assignment]
    QMainWindow = object  # type: ignore[assignment]
    QMenu = object  # type: ignore[assignment]
    QMessageBox = object  # type: ignore[assignment]
    QProgressBar = object  # type: ignore[assignment]
    QPushButton = object  # type: ignore[assignment]
    QTableWidget = object  # type: ignore[assignment]
    QTableWidgetItem = object  # type: ignore[assignment]
    QTextBrowser = object  # type: ignore[assignment]
    QVBoxLayout = object  # type: ignore[assignment]
    QWidget = object  # type: ignore[assignment]
    QColor = object  # type: ignore[assignment]
    QDesktopServices = object  # type: ignore[assignment]
    PYSIDE6_IMPORT_ERROR = exc

from . import file_flow

APP_TITLE = "FileFlow"

STATUS_DOT = {
    file_flow.STATUS_OK: "● 相同",
    file_flow.STATUS_SAME: "● 相同",
    file_flow.STATUS_COPIED: "● 已更新",
    file_flow.STATUS_SKIPPED: "● 已跳過",
    file_flow.STATUS_DIFFERENT: "● 不同",
    file_flow.STATUS_MISSING: "● 缺失",
    file_flow.STATUS_PERMISSION_DENIED: "● 無權限",
    file_flow.STATUS_UNREADABLE: "● 無法讀取",
    file_flow.STATUS_ERROR: "● 錯誤",
    file_flow.STATUS_UNKNOWN: "● 未知",
}

STATUS_COLORS = {
    file_flow.STATUS_OK: "#22C55E",
    file_flow.STATUS_SAME: "#22C55E",
    file_flow.STATUS_COPIED: "#2563EB",
    file_flow.STATUS_SKIPPED: "#94A3B8",
    file_flow.STATUS_DIFFERENT: "#F59E0B",
    file_flow.STATUS_MISSING: "#EF4444",
    file_flow.STATUS_PERMISSION_DENIED: "#EF4444",
    file_flow.STATUS_UNREADABLE: "#EF4444",
    file_flow.STATUS_ERROR: "#EF4444",
    file_flow.STATUS_UNKNOWN: "#94A3B8",
}

APP_STYLESHEET = """
QMainWindow { background: #F7F8FA; }
QWidget { font-family: "Segoe UI", "Noto Sans TC", "Inter", sans-serif; color: #111827; font-size: 13px; }
QFrame#sidebar { background: #FFFFFF; border-right: 1px solid #E5E7EB; }
QLabel#brand { font-size: 21px; font-weight: 700; color: #111827; }
QLabel#navItem { padding: 10px 14px; border-radius: 10px; color: #334155; }
QLabel#navItemActive { padding: 10px 14px; border-radius: 10px; background: #EEF4FF; color: #1D4ED8; font-weight: 600; }
QLabel#muted { color: #6B7280; font-size: 12px; }
QLabel#caption { color: #94A3B8; font-size: 11px; }
QLabel#heroTitle { font-size: 24px; font-weight: 700; color: #111827; }
QLabel#heroSubtitle { color: #6B7280; font-size: 13px; }
QLabel#metricValue { font-size: 22px; font-weight: 700; color: #111827; }
QLabel#metricLabel { color: #6B7280; font-size: 11px; }
QLabel#sectionTitle { font-size: 15px; font-weight: 700; color: #111827; }
QLabel#statusPill { color: #166534; background: #DCFCE7; border: 1px solid #BBF7D0; border-radius: 999px; padding: 7px 12px; font-weight: 600; }
QFrame#card, QGroupBox#card { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 16px; }
QGroupBox#card::title { color: transparent; }
QPushButton { background: #FFFFFF; color: #111827; border: 1px solid #DDE3EA; border-radius: 11px; padding: 9px 14px; min-height: 34px; }
QPushButton:hover { background: #F8FAFC; border-color: #CBD5E1; }
QPushButton:disabled { background: #F1F5F9; color: #A8B2C1; border-color: #E5E7EB; }
QPushButton#primary { background: #2563EB; color: white; border: 1px solid #2563EB; font-weight: 700; }
QPushButton#primary:hover { background: #1D4ED8; border-color: #1D4ED8; }
QPushButton#promote { background: #6D5DFB; color: white; border: 1px solid #6D5DFB; font-weight: 700; }
QPushButton#promote:hover { background: #5B4AE6; }
QPushButton#reset { background: #FFFFFF; color: #B45309; border: 1px solid #FED7AA; font-weight: 600; }
QPushButton#reset:hover { background: #FFF7ED; }
QPushButton#ghost { background: transparent; border: 1px solid transparent; color: #475569; }
QPushButton#ghost:hover { background: #F1F5F9; border-color: #E2E8F0; }
QComboBox, QLineEdit { background: #FFFFFF; border: 1px solid #DDE3EA; border-radius: 10px; padding: 7px 10px; }
QTableWidget { background: #FFFFFF; border: 0; gridline-color: #EEF2F7; selection-background-color: #EFF6FF; selection-color: #111827; }
QHeaderView::section { background: #F8FAFC; color: #64748B; border: 0; border-bottom: 1px solid #E5E7EB; padding: 9px 8px; font-weight: 600; }
QTableWidget::item { padding: 7px 8px; border-bottom: 1px solid #F1F5F9; }
QTextBrowser { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 14px; padding: 12px; color: #111827; }
QProgressBar { border: 1px solid #E5E7EB; border-radius: 7px; background: #F1F5F9; min-height: 10px; max-height: 10px; }
QProgressBar::chunk { background: #2563EB; border-radius: 7px; }
QMenu { background: #FFFFFF; border: 1px solid #E5E7EB; border-radius: 10px; padding: 6px; }
QMenu::item { padding: 8px 22px; border-radius: 8px; }
QMenu::item:selected { background: #F1F5F9; }
"""


class Worker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(object)

    def __init__(self, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        super().__init__()
        self.action = action
        self.with_progress = with_progress

    @Slot()
    def run(self) -> None:
        try:
            if self.with_progress:
                self.finished.emit(self.action(self.progress.emit))
            else:
                self.finished.emit(self.action())
        except Exception as exc:  # noqa: BLE001 - GUI must show clear runtime errors
            self.failed.emit(str(exc))


class ConfigEditor(QMessageBox):
    """Small bridge dialog: advanced editing is intentionally file based but safer than silent overwrite."""


class MainWindow(QMainWindow):
    def __init__(self, config_path: Path | None = None) -> None:
        super().__init__()
        self.config_path = file_flow.resolve_config_path(config_path)
        self.config: file_flow.FlowConfig | None = None
        self.last_result: file_flow.CommandResult | None = None
        self.last_log_path: Path | None = None
        self.last_backup_path: Path | None = None
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self.setWindowTitle(APP_TITLE)
        self.resize(1260, 880)
        self.setMinimumSize(980, 720)
        self.setStyleSheet(APP_STYLESHEET)
        self._build_ui()
        self.run_background("載入狀態", lambda: file_flow.get_status_result(self.config_path))

    def _build_ui(self) -> None:
        shell = QWidget()
        shell_layout = QHBoxLayout(shell)
        shell_layout.setContentsMargins(0, 0, 0, 0)
        shell_layout.setSpacing(0)

        self.sidebar = QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(210)
        side = QVBoxLayout(self.sidebar)
        side.setContentsMargins(18, 22, 18, 22)
        side.setSpacing(12)
        brand = QLabel("◔  FileFlow")
        brand.setObjectName("brand")
        side.addWidget(brand)
        side.addSpacing(18)
        for text, active in [
            ("總覽", True),
            ("檔案狀態", False),
            ("變更記錄", False),
            ("備份與還原", False),
            ("設定檔管理", False),
            ("設定", False),
        ]:
            label = QLabel(text)
            label.setObjectName("navItemActive" if active else "navItem")
            side.addWidget(label)
        side.addStretch(1)
        help_box = QFrame()
        help_box.setObjectName("card")
        help_layout = QVBoxLayout(help_box)
        help_layout.setContentsMargins(14, 14, 14, 14)
        help_title = QLabel("快速說明")
        help_title.setObjectName("sectionTitle")
        help_layout.addWidget(help_title)
        for line in ["Promote：把工作位置設為 Master", "Reset：用 Master 還原所有位置", "檢查：只檢查，不修改檔案"]:
            item = QLabel(line)
            item.setObjectName("muted")
            item.setWordWrap(True)
            help_layout.addWidget(item)
        side.addWidget(help_box)
        shell_layout.addWidget(self.sidebar)

        content = QWidget()
        page = QVBoxLayout(content)
        page.setContentsMargins(28, 20, 28, 20)
        page.setSpacing(16)
        shell_layout.addWidget(content, 1)

        top = QHBoxLayout()
        title = QLabel("總覽")
        title.setObjectName("sectionTitle")
        top.addWidget(title)
        top.addSpacing(18)
        top.addWidget(QLabel("專案設定檔"))
        self.profile_combo = QComboBox()
        self.profile_combo.setMinimumWidth(210)
        self.profile_combo.addItem(self.config_path.name, str(self.config_path))
        self.profile_combo.currentIndexChanged.connect(self.on_profile_selected)
        top.addWidget(self.profile_combo)
        top.addStretch(1)
        self.status_pill = QLabel("● 尚未檢查")
        self.status_pill.setObjectName("statusPill")
        top.addWidget(self.status_pill)
        self.btn_more = QPushButton("更多操作 ▾")
        self.btn_more.setObjectName("ghost")
        self.more_menu = QMenu(self)
        self.action_commit = self.more_menu.addAction("提交 Master 變更")
        self.action_undo = self.more_menu.addAction("還原上一次操作")
        self.more_menu.addSeparator()
        self.action_config_check = self.more_menu.addAction("檢查設定是否正確")
        self.action_edit_config = self.more_menu.addAction("編輯同步設定")
        self.more_menu.addSeparator()
        self.action_clean_backups = self.more_menu.addAction("清理舊備份")
        self.action_open_log = self.more_menu.addAction("開啟操作記錄")
        self.action_open_backup = self.more_menu.addAction("開啟備份資料夾")
        self.action_copy_summary = self.more_menu.addAction("複製操作摘要")
        self.btn_more.setMenu(self.more_menu)
        top.addWidget(self.btn_more)
        self.btn_settings = QPushButton("⚙")
        self.btn_settings.setObjectName("ghost")
        self.btn_settings.setToolTip("設定")
        self.btn_settings.clicked.connect(self.edit_config)
        top.addWidget(self.btn_settings)
        page.addLayout(top)

        hero = QFrame()
        hero.setObjectName("card")
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(24, 24, 24, 24)
        hero_layout.setSpacing(24)
        self.hero_icon = QLabel("✓")
        self.hero_icon.setAlignment(Qt.AlignCenter)
        self.hero_icon.setStyleSheet("background:#22C55E;color:white;border-radius:28px;font-size:30px;font-weight:700;min-width:56px;min-height:56px;max-width:56px;max-height:56px;")
        hero_layout.addWidget(self.hero_icon)
        hero_text = QVBoxLayout()
        self.hero_title = QLabel("正在檢查檔案狀態")
        self.hero_title.setObjectName("heroTitle")
        self.hero_subtitle = QLabel("FileFlow 正在讀取設定與掃描檔案。")
        self.hero_subtitle.setObjectName("heroSubtitle")
        self.hero_subtitle.setWordWrap(True)
        hero_text.addWidget(self.hero_title)
        hero_text.addWidget(self.hero_subtitle)
        hero_layout.addLayout(hero_text, 1)
        self.metric_files = self.metric_block("追蹤檔案", "—")
        self.metric_locations = self.metric_block("工作位置", "—")
        self.metric_different = self.metric_block("不同步", "—")
        self.metric_missing = self.metric_block("缺失檔案", "—")
        for block in [self.metric_files, self.metric_locations, self.metric_different, self.metric_missing]:
            hero_layout.addWidget(block["frame"])
        next_box = QFrame()
        next_layout = QVBoxLayout(next_box)
        next_layout.setContentsMargins(18, 0, 0, 0)
        next_layout.setSpacing(8)
        self.next_action_title = QLabel("建議下一步")
        self.next_action_title.setObjectName("sectionTitle")
        self.next_action_text = QLabel("先檢查是否同步")
        self.next_action_text.setObjectName("muted")
        self.next_action_text.setWordWrap(True)
        self.btn_recommended = QPushButton("檢查是否同步")
        self.btn_recommended.setObjectName("primary")
        self.btn_recommended.clicked.connect(lambda: self.run_background("檢查是否同步", lambda: file_flow.get_verify_result(self.config_path)))
        next_layout.addWidget(self.next_action_title)
        next_layout.addWidget(self.next_action_text)
        next_layout.addWidget(self.btn_recommended)
        hero_layout.addWidget(next_box)
        page.addWidget(hero)

        matrix = QFrame()
        matrix.setObjectName("card")
        matrix_layout = QVBoxLayout(matrix)
        matrix_layout.setContentsMargins(20, 18, 20, 18)
        header = QHBoxLayout()
        header_title = QLabel("檔案同步狀態概覽")
        header_title.setObjectName("sectionTitle")
        header.addWidget(header_title)
        header.addStretch(1)
        self.btn_status = QPushButton("重新檢查狀態")
        self.btn_status.setObjectName("ghost")
        self.btn_status.setToolTip("重新掃描目前所有檔案狀態。")
        self.btn_status.clicked.connect(lambda: self.run_background("重新檢查狀態", lambda: file_flow.get_status_result(self.config_path)))
        header.addWidget(self.btn_status)
        matrix_layout.addLayout(header)
        self.table = QTableWidget(0, 2)
        self.table.setAlternatingRowColors(False)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.setSelectionBehavior(QTableWidget.SelectItems)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.setMinimumHeight(240)
        self.table.setHorizontalHeaderLabels(["檔案", "Master"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.itemSelectionChanged.connect(self.show_selected_cell_detail)
        matrix_layout.addWidget(self.table, 1)
        page.addWidget(matrix, 1)

        actions = QFrame()
        actions.setObjectName("card")
        actions_layout = QVBoxLayout(actions)
        actions_layout.setContentsMargins(20, 18, 20, 18)
        actions_layout.setSpacing(14)
        selector = QHBoxLayout()
        selector_title = QLabel("常用操作")
        selector_title.setObjectName("sectionTitle")
        selector.addWidget(selector_title)
        selector.addStretch(1)
        selector.addWidget(QLabel("選定工作位置"))
        self.source_combo = QComboBox()
        self.source_combo.setMinimumWidth(150)
        self.source_combo.currentIndexChanged.connect(self.update_button_states)
        selector.addWidget(self.source_combo)
        actions_layout.addLayout(selector)

        cards = QGridLayout()
        cards.setHorizontalSpacing(12)
        cards.setVerticalSpacing(12)
        self.btn_promote = self.action_card("推進選定位置為 Master", "把工作位置設為正式版本", "promote")
        self.btn_reset = self.action_card("用 Master 覆蓋所有位置", "用正式版本同步全部位置", "reset")
        self.btn_verify = self.action_card("檢查是否同步", "只檢查，不修改檔案", "secondary")
        self.btn_diff = self.action_card("查看差異", "查看 Master 和選定位置的不同", "secondary")
        self.btn_promote.clicked.connect(lambda: self.run_promote(dry_run=False))
        self.btn_reset.clicked.connect(lambda: self.run_reset(dry_run=False))
        self.btn_verify.clicked.connect(lambda: self.run_background("檢查是否同步", lambda: file_flow.get_verify_result(self.config_path)))
        self.btn_diff.clicked.connect(self.run_diff)
        cards.addWidget(self.btn_promote, 0, 0)
        cards.addWidget(self.btn_reset, 0, 1)
        cards.addWidget(self.btn_verify, 0, 2)
        cards.addWidget(self.btn_diff, 0, 3)
        actions_layout.addLayout(cards)

        lower = QHBoxLayout()
        self.recent_card = QFrame()
        self.recent_card.setObjectName("card")
        recent_layout = QVBoxLayout(self.recent_card)
        recent_layout.setContentsMargins(0, 0, 0, 0)
        self.recent_title = QLabel("最近操作")
        self.recent_title.setObjectName("sectionTitle")
        self.recent_text = QLabel("尚未有操作結果。")
        self.recent_text.setObjectName("muted")
        self.recent_text.setWordWrap(True)
        recent_layout.addWidget(self.recent_title)
        recent_layout.addWidget(self.recent_text)
        lower.addWidget(self.recent_card, 1)
        log_box = QVBoxLayout()
        log_header = QHBoxLayout()
        self.log_title = QLabel("詳細結果")
        self.log_title.setObjectName("sectionTitle")
        log_header.addWidget(self.log_title)
        log_header.addStretch(1)
        self.btn_toggle_log = QPushButton("顯示 / 隱藏細節")
        self.btn_toggle_log.setObjectName("ghost")
        self.btn_toggle_log.clicked.connect(lambda: self.output.setVisible(not self.output.isVisible()))
        log_header.addWidget(self.btn_toggle_log)
        log_box.addLayout(log_header)
        self.detail_label = QLabel("點選檔案狀態可查看完整路徑、size、mtime 與 hash。")
        self.detail_label.setObjectName("muted")
        self.detail_label.setWordWrap(True)
        log_box.addWidget(self.detail_label)
        self.output = QTextBrowser()
        self.output.setVisible(False)
        self.output.setMinimumHeight(120)
        log_box.addWidget(self.output)
        lower.addLayout(log_box, 2)
        actions_layout.addLayout(lower)

        self.progress_label = QLabel("就緒")
        self.progress_label.setObjectName("caption")
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setVisible(False)
        actions_layout.addWidget(self.progress_label)
        actions_layout.addWidget(self.progress)
        page.addWidget(actions)

        footer = QLabel(f"Config: {self.compact_path(self.config_path)}")
        footer.setObjectName("caption")
        page.addWidget(footer)
        self.footer_label = footer
        self.setCentralWidget(shell)

        # compatibility aliases for previous UI names
        self.btn_preview_promote = QPushButton("預覽推進結果")
        self.btn_preview_reset = QPushButton("預覽覆蓋結果")
        self.btn_commit = QPushButton("提交 Master 變更")
        self.btn_undo = QPushButton("還原上一次操作")
        self.btn_config_check = QPushButton("檢查設定是否正確")
        self.btn_edit_config = QPushButton("編輯同步設定")
        self.btn_clean_backups = QPushButton("清理舊備份")
        self.btn_open_log = QPushButton("開啟操作記錄")
        self.btn_open_backup = QPushButton("開啟備份資料夾")
        self.btn_copy_summary = QPushButton("複製操作摘要")
        self.btn_preview_promote.clicked.connect(lambda: self.run_promote(dry_run=True))
        self.btn_preview_reset.clicked.connect(lambda: self.run_reset(dry_run=True))
        self.btn_commit.clicked.connect(self.run_commit)
        self.btn_undo.clicked.connect(self.run_undo)
        self.btn_config_check.clicked.connect(lambda: self.run_background("檢查設定是否正確", lambda: file_flow.config_check(self.config_path)))
        self.btn_edit_config.clicked.connect(self.edit_config)
        self.btn_clean_backups.clicked.connect(self.run_clean_backups)
        self.btn_open_log.clicked.connect(lambda: self.open_path(self.last_log_path))
        self.btn_open_backup.clicked.connect(lambda: self.open_path(self.last_backup_path))
        self.btn_copy_summary.clicked.connect(self.copy_summary)

        self.action_commit.triggered.connect(self.run_commit)
        self.action_undo.triggered.connect(self.run_undo)
        self.action_config_check.triggered.connect(lambda: self.run_background("檢查設定是否正確", lambda: file_flow.config_check(self.config_path)))
        self.action_edit_config.triggered.connect(self.edit_config)
        self.action_clean_backups.triggered.connect(self.run_clean_backups)
        self.action_open_log.triggered.connect(lambda: self.open_path(self.last_log_path))
        self.action_open_backup.triggered.connect(lambda: self.open_path(self.last_backup_path))
        self.action_copy_summary.triggered.connect(self.copy_summary)

    def metric_block(self, label: str, value: str) -> dict[str, QLabel | QFrame]:
        frame = QFrame()
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(14, 4, 14, 4)
        layout.setSpacing(2)
        value_label = QLabel(value)
        value_label.setAlignment(Qt.AlignCenter)
        value_label.setObjectName("metricValue")
        label_label = QLabel(label)
        label_label.setAlignment(Qt.AlignCenter)
        label_label.setObjectName("metricLabel")
        layout.addWidget(value_label)
        layout.addWidget(label_label)
        return {"frame": frame, "value": value_label, "label": label_label}

    def action_card(self, title: str, subtitle: str, style: str) -> QPushButton:
        btn = QPushButton(f"{title}\n{subtitle}")
        btn.setMinimumHeight(72)
        btn.setToolTip(subtitle)
        if style == "promote":
            btn.setObjectName("promote")
        elif style == "reset":
            btn.setObjectName("reset")
        else:
            btn.setObjectName("ghost")
        return btn

    def compact_path(self, path: Path | str | None, *, keep: int = 56) -> str:
        if not path:
            return "—"
        text = str(path)
        if len(text) <= keep:
            return text
        return "…" + text[-keep:]

    def set_busy(self, busy: bool) -> None:
        for button in [self.btn_status, self.btn_verify, self.btn_diff, self.btn_promote, self.btn_reset, self.btn_recommended, self.btn_more, self.btn_settings]:
            button.setEnabled(not busy)
        self.source_combo.setEnabled(not busy)
        self.profile_combo.setEnabled(not busy)
        self.progress.setVisible(busy)
        if busy:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
            self.progress_label.setText("就緒")

    def update_button_states(self) -> None:
        has_config = self.config is not None
        has_source = bool(self.selected_source())
        self.btn_promote.setEnabled(has_config and has_source)
        self.btn_diff.setEnabled(has_config and has_source)
        self.btn_reset.setEnabled(has_config)
        self.btn_verify.setEnabled(has_config)
        self.btn_status.setEnabled(True)
        self.action_open_log.setEnabled(bool(self.last_log_path and self.last_log_path.exists()))
        self.action_open_backup.setEnabled(bool(self.last_backup_path and self.last_backup_path.exists()))
        self.action_copy_summary.setEnabled(self.last_result is not None)

    def run_background(self, label: str, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        if self.thread is not None:
            QMessageBox.information(self, "正在執行", "目前已有操作執行中，請稍候。")
            return
        self.set_busy(True)
        self.progress_label.setText(label)
        self.thread = QThread()
        self.worker = Worker(action, with_progress=with_progress)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.failed.connect(self.on_worker_failed)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    @Slot(object)
    def on_worker_finished(self, result: Any) -> None:
        if isinstance(result, file_flow.CommandResult):
            self.apply_result(result)
        else:
            self.output.setHtml(f"<pre>{html.escape(str(result))}</pre>")

    @Slot(object)
    def on_progress(self, info: object) -> None:
        if not isinstance(info, dict):
            return
        copied = int(info.get("copied_bytes") or 0)
        total = int(info.get("total_bytes") or 0)
        index = int(info.get("current_item_index") or 1)
        count = int(info.get("total_item_count") or 1)
        percent = int(copied * 100 / total) if total else 0
        self.progress.setRange(0, 100)
        self.progress.setValue(percent)
        self.progress_label.setText(f"複製中 {index}/{count}: {info.get('current_file', '')} ({percent}%)")

    @Slot(str)
    def on_worker_failed(self, message: str) -> None:
        self.output.setVisible(True)
        self.output.setHtml(f"<h3>錯誤</h3><pre>{html.escape(message)}</pre>")
        self.recent_text.setText(f"錯誤：{message}")
        QMessageBox.critical(self, "錯誤", message)

    @Slot()
    def cleanup_thread(self) -> None:
        self.thread = None
        self.worker = None
        self.set_busy(False)
        self.update_button_states()

    def apply_result(self, result: file_flow.CommandResult) -> None:
        self.last_result = result
        self.config = result.config or self.config
        self.last_log_path = result.operation_log_path
        self.last_backup_path = result.backup_dir
        if self.config:
            self.update_config_summary(self.config)
        self.update_overview(result)
        self.update_matrix(result)
        self.output.setHtml(self.result_to_html(result))
        self.update_button_states()

    def update_config_summary(self, config: file_flow.FlowConfig) -> None:
        self.footer_label.setText(f"Config: {self.compact_path(config.config_path)}    Master: {self.compact_path(config.master_folder)}")
        self.metric_files["value"].setText(str(len(config.files)))  # type: ignore[index, union-attr]
        self.metric_locations["value"].setText(str(len(config.locations)))  # type: ignore[index, union-attr]
        old = [self.source_combo.itemText(i) for i in range(self.source_combo.count())]
        if old != list(config.locations):
            self.source_combo.clear()
            for name in config.locations:
                self.source_combo.addItem(name, name)

    def update_overview(self, result: file_flow.CommandResult) -> None:
        summary = result.metadata.get("summary", {}) if result.metadata else {}
        different = int(summary.get("different", 0) or 0)
        missing = int(summary.get("missing", 0) or 0)
        errors = int(summary.get("errors", len(result.errors)) or 0)
        self.metric_different["value"].setText(str(different))  # type: ignore[index, union-attr]
        self.metric_missing["value"].setText(str(missing))  # type: ignore[index, union-attr]
        if result.success and not different and not missing and not errors:
            self.hero_icon.setText("✓")
            self.hero_icon.setStyleSheet("background:#22C55E;color:white;border-radius:28px;font-size:30px;font-weight:700;min-width:56px;min-height:56px;max-width:56px;max-height:56px;")
            self.hero_title.setText("狀態良好")
            self.hero_subtitle.setText("所有檔案已同步。")
            self.status_pill.setText("● 所有檔案已同步")
            self.next_action_text.setText("Master 若有變更，可以提交版本紀錄。")
            self.btn_recommended.setText("提交 Master 變更")
            try:
                self.btn_recommended.clicked.disconnect()
            except RuntimeError:
                pass
            self.btn_recommended.clicked.connect(self.run_commit)
        elif errors or result.errors:
            self.hero_icon.setText("!")
            self.hero_icon.setStyleSheet("background:#EF4444;color:white;border-radius:28px;font-size:30px;font-weight:700;min-width:56px;min-height:56px;max-width:56px;max-height:56px;")
            self.hero_title.setText("需要處理錯誤")
            self.hero_subtitle.setText(result.message)
            self.status_pill.setText("● 有錯誤需要處理")
            self.next_action_text.setText("建議先檢查設定是否正確。")
            self.btn_recommended.setText("檢查設定是否正確")
            try:
                self.btn_recommended.clicked.disconnect()
            except RuntimeError:
                pass
            self.btn_recommended.clicked.connect(lambda: self.run_background("檢查設定是否正確", lambda: file_flow.config_check(self.config_path)))
        else:
            self.hero_icon.setText("!")
            self.hero_icon.setStyleSheet("background:#F59E0B;color:white;border-radius:28px;font-size:30px;font-weight:700;min-width:56px;min-height:56px;max-width:56px;max-height:56px;")
            self.hero_title.setText("有檔案需要確認")
            self.hero_subtitle.setText(result.message)
            self.status_pill.setText("● 有檔案不同步")
            self.next_action_text.setText("建議先查看 Master 與工作位置的差異。")
            self.btn_recommended.setText("查看差異")
            try:
                self.btn_recommended.clicked.disconnect()
            except RuntimeError:
                pass
            self.btn_recommended.clicked.connect(self.run_diff)
        self.recent_text.setText(
            f"{result.title}｜{result.message}\n"
            f"更新 {result.copied_count} 個，跳過 {result.skipped_count} 個，失敗 {result.failed_count} 個｜耗時 {result.elapsed_seconds:.2f}s"
        )

    def update_matrix(self, result: file_flow.CommandResult) -> None:
        records = list(result.records)
        if not records:
            self.table.setRowCount(0)
            return
        locations = list(records[0].locations)
        headers = ["檔案名稱", "Master", *locations, "Git"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            self.table.setItem(row, 0, self.make_item(record.entry.relative_file.as_posix(), None))
            master_text = "● 存在" if record.master.exists else STATUS_DOT.get(record.master.status, record.master.status)
            self.table.setItem(row, 1, self.make_item(master_text, record.master))
            for col, location in enumerate(locations, start=2):
                state = record.locations[location]
                self.table.setItem(row, col, self.make_item(STATUS_DOT.get(state.status, state.status), state))
            self.table.setItem(row, len(headers) - 1, self.make_item(self.git_label(record.git_status), None))
            self.table.setRowHeight(row, 38)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        if len(headers) > 4:
            self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)

    def git_label(self, text: str) -> str:
        if text == "clean":
            return "● 已追蹤"
        if "不可用" in text:
            return "— 無 Git"
        if text in {file_flow.STATUS_MODIFIED, file_flow.STATUS_UNTRACKED, file_flow.STATUS_DELETED}:
            return f"● {text}"
        return text

    def make_item(self, text: str, state: file_flow.FileState | None) -> QTableWidgetItem:
        item = QTableWidgetItem(text)
        item.setFlags(item.flags() ^ Qt.ItemIsEditable)
        if state:
            item.setForeground(QColor(STATUS_COLORS.get(state.status, "#111827")))
            item.setData(Qt.UserRole, file_flow.file_state_to_json(state))
        elif text.startswith("●"):
            item.setForeground(QColor("#22C55E"))
        elif text.startswith("—"):
            item.setForeground(QColor("#94A3B8"))
        return item

    def show_selected_cell_detail(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        data = items[0].data(Qt.UserRole)
        if not data:
            self.detail_label.setText(items[0].text())
            return
        self.detail_label.setText(
            f"路徑：{data.get('path')}\n"
            f"狀態：{data.get('status')}｜存在：{data.get('exists')}｜大小：{data.get('size')} bytes\n"
            f"修改時間 ns：{data.get('mtime_ns')}｜SHA-256：{data.get('sha256_short')}"
        )

    def result_to_html(self, result: file_flow.CommandResult) -> str:
        status_text = "成功" if result.success else "失敗"
        parts = [
            f"<h2>{html.escape(result.title)}</h2>",
            f"<p><b>結果：</b>{html.escape(status_text)}</p>",
            f"<p><b>說明：</b>{html.escape(result.message)}</p>",
            "<ul>",
            f"<li>更新：{result.copied_count}</li>",
            f"<li>跳過：{result.skipped_count}</li>",
            f"<li>失敗：{result.failed_count}</li>",
            f"<li>耗時：{result.elapsed_seconds:.3f}s</li>",
            "</ul>",
        ]
        if result.backup_dir:
            parts.append(f"<p><b>備份：</b>{html.escape(str(result.backup_dir))}</p>")
        if result.operation_log_path:
            parts.append(f"<p><b>操作記錄：</b>{html.escape(str(result.operation_log_path))}</p>")
        if result.suggestions:
            parts.append("<h3>建議下一步</h3><ul>" + "".join(f"<li>{html.escape(s)}</li>" for s in result.suggestions) + "</ul>")
        detail = result.output or result.diff_text or ""
        if detail:
            parts.append(f"<h3>詳細內容</h3><pre>{html.escape(detail)}</pre>")
        return "".join(parts)

    def selected_source(self) -> str | None:
        return self.source_combo.currentData() or self.source_combo.currentText() or None

    def run_diff(self) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇", "請先選擇工作位置，才能查看 Master 與該位置的差異。")
            return
        self.run_background("查看差異", lambda: file_flow.get_diff_preview_result(source, self.config_path))

    def run_promote(self, *, dry_run: bool) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.warning(self, "需要選擇", "請先選擇要推進為 Master 的工作位置。")
            return
        if dry_run:
            self.run_background("預覽推進結果", lambda: file_flow.perform_promote(source, self.config_path, dry_run=True))
            return
        if not self.confirm_text("確認要把此位置設為 Master？", f"{source} 的檔案會覆蓋 Master，然後同步到其他位置。\n\n請輸入 {source} 以確認。", source):
            return
        self.run_background("推進選定位置為 Master", lambda cb=None: file_flow.perform_promote(source, self.config_path, dry_run=False, progress_callback=cb), with_progress=True)

    def run_reset(self, *, dry_run: bool) -> None:
        if dry_run:
            self.run_background("預覽覆蓋結果", lambda: file_flow.perform_reset_all(self.config_path, dry_run=True))
            return
        if not self.confirm_text("確認要用 Master 覆蓋所有位置？", "所有工作位置都會回到 Master 的版本。\n\n請輸入 RESET 以確認。", "RESET"):
            return
        self.run_background("用 Master 覆蓋所有位置", lambda cb=None: file_flow.perform_reset_all(self.config_path, dry_run=False, progress_callback=cb), with_progress=True)

    def run_commit(self) -> None:
        text, ok = QInputDialog.getText(self, "提交 Master 變更", "請輸入這次 Master 變更的版本紀錄訊息：")
        if not ok or not text.strip():
            return
        self.run_background("提交 Master 變更", lambda: file_flow.perform_commit(text, self.config_path))

    def run_undo(self) -> None:
        if not self.confirm_text("確認要還原上一次操作？", "FileFlow 會從最近一次可還原備份復原。\n\n請輸入 UNDO 以確認。", "UNDO"):
            self.run_background("預覽還原結果", lambda: file_flow.perform_undo_last(self.config_path, dry_run=True))
            return
        self.run_background("還原上一次操作", lambda cb=None: file_flow.perform_undo_last(self.config_path, dry_run=False, yes=True, progress_callback=cb), with_progress=True)

    def run_clean_backups(self) -> None:
        if self.config is None:
            QMessageBox.information(self, "尚未載入設定", "請先重新檢查狀態。")
            return
        if not self.confirm_text("確認要清理舊備份？", "FileFlow 會依照保留策略刪除過期備份。\n\n請輸入 CLEAN 以確認。", "CLEAN"):
            self.run_background("預覽清理舊備份", lambda: file_flow.cleanup_backups(self.config, dry_run=True))
            return
        self.run_background("清理舊備份", lambda: file_flow.cleanup_backups(self.config, dry_run=False, yes=True))

    def confirm_text(self, title: str, message: str, expected: str) -> bool:
        text, ok = QInputDialog.getText(self, title, message)
        return bool(ok and text == expected)

    def open_path(self, path: Path | None) -> None:
        if not path or not path.exists():
            QMessageBox.warning(self, "無法開啟", "路徑不存在。")
            return
        target = path if path.is_dir() else path.parent
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))

    def copy_summary(self) -> None:
        if not self.last_result:
            QMessageBox.information(self, "沒有可複製內容", "目前還沒有操作摘要。")
            return
        QApplication.clipboard().setText(file_flow.format_human_result(self.last_result))

    def edit_config(self) -> None:
        if self.config is None:
            self.open_path(self.config_path)
            return
        QMessageBox.information(
            self,
            "編輯同步設定",
            "目前版本會開啟設定檔所在資料夾。修改後請執行『檢查設定是否正確』與『重新檢查狀態』。",
        )
        self.open_path(self.config.config_path)

    def on_profile_selected(self) -> None:
        data = self.profile_combo.currentData()
        if data:
            self.config_path = Path(data)


def main(argv: list[str] | None = None) -> int:
    if PYSIDE6_IMPORT_ERROR is not None:
        raise RuntimeError(
            "無法啟動 GUI：缺少 PySide6。請先執行 `python -m pip install PySide6`，或改用 CLI：`python file_flow.py status`。"
        ) from PYSIDE6_IMPORT_ERROR
    app = QApplication(sys.argv if argv is None else argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
