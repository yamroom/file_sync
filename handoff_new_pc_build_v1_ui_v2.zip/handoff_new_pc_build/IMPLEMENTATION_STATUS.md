# FileFlow v1 Functional Upgrade Status

This package keeps the original root wrappers and improves the functional FileFlow core, excluding PyInstaller / `.exe` build optimization.

## Completed

- Skip unchanged files before copy using size + SHA-256.
- Atomic copy via temporary file + SHA-256 verification + `os.replace`.
- Parallel file-state scanning and parallel copy using `ThreadPoolExecutor` with conservative `MAX_WORKERS`.
- Progress callback support for chunked copy.
- Preflight and post-verify checks for promote and reset-all.
- Dry-run preview for promote and reset-all.
- Operation logs under `.tool_logs/` in `.json` and `.log` formats.
- Backup support under `.tool_backups/` and undo-last restore from backups.
- Backup retention settings: `BACKUP_KEEP_LAST` and `BACKUP_KEEP_DAYS`.
- CLI `config-check`, `commit`, `undo-last`, `clean-backups`.
- `--json` output for commands through the common result serializer.
- TOML config support while keeping legacy `KEY=VALUE` txt config compatibility.
- Binary diff detection with size / hash summary.
- Short hash display in human-readable output.
- GUI dashboard layout, sync matrix, clearer buttons, dry-run actions, typed confirmations, log / backup shortcuts.
- Unit tests using Python standard-library `unittest`.

## Notes

- GUI config editing currently opens the config location and provides safer validation flow rather than a full structured editor form.
- Profile support is available through CLI `--config` and GUI config selector foundation; full create/copy profile workflow can be expanded later.
- No new heavy runtime dependency was added.

## Validation

Validated with:

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
```

Current test result: 10 tests passed.
