# FileFlow UI v2 Design Status

本版根據減法設計重新整理 GUI，目標是降低視覺噪音、讓使用者第一眼看到同步健康狀態，並把低頻與高風險操作收斂到更清楚的位置。

## 已完成

- 主畫面改為產品化 dashboard：左側導覽、頂部 project selector、狀態 hero、同步矩陣、常用操作、最近操作與收合式詳細結果。
- 按鈕重新命名為更容易理解的中文：
  - `Verify` → `檢查是否同步`
  - `Compare / Diff` → `查看差異`
  - `Promote` → `推進選定位置為 Master`
  - `Reset All` → `用 Master 覆蓋所有位置`
  - `Commit` → `提交 Master 變更`
  - `Undo` → `還原上一次操作`
  - `Config Check` → `檢查設定是否正確`
- 主畫面只保留高頻操作：推進、覆蓋、檢查、查看差異。
- 低頻操作移到「更多操作」：提交、還原、設定檢查、編輯設定、清理備份、開啟記錄、複製摘要。
- 詳細 log 預設收合，不再作為第一眼主內容。
- 同步矩陣改為低噪音狀態表格，使用狀態點與短文案。
- 保留原本核心功能 API 與 CLI 行為，不修改 `.exe` 打包流程。

## 尚未新增的新 dependency

本次 GUI v2 只使用既有 PySide6，不新增 heavyweight dependency。

## 測試重點

- Python compileall
- unittest 核心功能測試
- CLI smoke test
- PySide6 offscreen GUI 啟動與截圖測試
