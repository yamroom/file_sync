from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools import file_flow  # noqa: E402


class FileFlowTests(unittest.TestCase):
    def make_workspace(self):
        tmp = tempfile.TemporaryDirectory()
        root = Path(tmp.name)
        master = root / "master"
        a = root / "A"
        b = root / "B"
        master.mkdir()
        a.mkdir()
        b.mkdir()
        (master / "file.txt").write_text("master\n", encoding="utf-8")
        (master / "file copy.txt").write_text("copy\n", encoding="utf-8")
        (a / "file.txt").write_text("A\n", encoding="utf-8")
        (a / "file copy.txt").write_text("copy\n", encoding="utf-8")
        (b / "file.txt").write_text("old\n", encoding="utf-8")
        (b / "file copy.txt").write_text("copy\n", encoding="utf-8")
        config = root / "file_flow_paths.txt"
        config.write_text(
            "\n".join([
                f"MASTER_FOLDER={master}",
                "FILES=file.txt,file copy.txt",
                f"A={a}",
                f"B={b}",
                "MAX_WORKERS=2",
                "BACKUP_KEEP_LAST=10",
            ]) + "\n",
            encoding="utf-8",
        )
        return tmp, root, config, master, a, b

    def test_legacy_config_and_config_check(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            loaded = file_flow.load_config(config)
            self.assertEqual(loaded.master_folder, master.resolve())
            self.assertIn("A", loaded.locations)
            result = file_flow.config_check(config)
            self.assertTrue(result.success, result.output)

    def test_toml_config(self):
        tmp, root, _config, master, a, b = self.make_workspace()
        with tmp:
            toml = root / "flow.toml"
            toml.write_text(
                f'master_folder = "{master.as_posix()}"\n'
                'files = ["file.txt", "file copy.txt"]\n'
                '[locations]\n'
                f'A = "{a.as_posix()}"\n'
                f'B = "{b.as_posix()}"\n'
                '[performance]\nmax_workers = 2\n',
                encoding="utf-8",
            )
            loaded = file_flow.load_config(toml)
            self.assertEqual(loaded.format, "toml")
            self.assertEqual(len(loaded.files), 2)

    def test_verify_fail_different(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            result = file_flow.get_verify_result(config)
            self.assertFalse(result.success)
            self.assertTrue(any("不同" in p for p in result.problems))

    def test_promote_dry_run_does_not_modify(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            before = (master / "file.txt").read_text(encoding="utf-8")
            result = file_flow.perform_promote("A", config, dry_run=True)
            self.assertTrue(result.success)
            self.assertEqual(before, (master / "file.txt").read_text(encoding="utf-8"))
            self.assertTrue(result.planned_files)

    def test_promote_real_skip_unchanged_and_log(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            result = file_flow.perform_promote("A", config)
            self.assertTrue(result.success, result.output)
            self.assertEqual((master / "file.txt").read_text(encoding="utf-8"), "A\n")
            self.assertGreaterEqual(result.skipped_count, 1)
            self.assertTrue(result.operation_json_path and result.operation_json_path.exists())
            payload = json.loads(result.operation_json_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["operation"], "promote")

    def test_reset_dry_run_and_real(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            preview = file_flow.perform_reset_all(config, dry_run=True)
            self.assertTrue(preview.success)
            self.assertEqual((a / "file.txt").read_text(encoding="utf-8"), "A\n")
            result = file_flow.perform_reset_all(config)
            self.assertTrue(result.success, result.output)
            self.assertEqual((a / "file.txt").read_text(encoding="utf-8"), "master\n")
            self.assertEqual((b / "file.txt").read_text(encoding="utf-8"), "master\n")

    def test_atomic_copy_failure_keeps_original(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            dst = root / "dst.txt"
            dst.write_text("original", encoding="utf-8")
            missing = root / "missing.txt"
            with self.assertRaises(Exception):
                file_flow.atomic_copy_file(missing, dst)
            self.assertEqual(dst.read_text(encoding="utf-8"), "original")

    def test_undo_last_preview_and_execute(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            result = file_flow.perform_promote("A", config)
            self.assertTrue(result.success)
            self.assertEqual((master / "file.txt").read_text(encoding="utf-8"), "A\n")
            preview = file_flow.perform_undo_last(config, dry_run=True)
            self.assertTrue(preview.success)
            undo = file_flow.perform_undo_last(config, dry_run=False, yes=True)
            self.assertTrue(undo.success, undo.output)
            self.assertEqual((master / "file.txt").read_text(encoding="utf-8"), "master\n")

    def test_commit_chinese_message(self):
        if shutil.which("git") is None:
            self.skipTest("git is not installed")
        tmp = tempfile.TemporaryDirectory()
        with tmp:
            root = Path(tmp.name)
            master = root / "master"
            a = root / "A"
            b = root / "B"
            c = root / "C"
            for folder in (master, a, b, c):
                folder.mkdir()
                (folder / "file.txt").write_text("初始\n", encoding="utf-8")
                (folder / "file copy.txt").write_text("copy\n", encoding="utf-8")
            config = root / "file_flow_paths.toml"
            config.write_text(
                f'master_folder = "{master.as_posix()}"\n'
                'files = ["file.txt", "file copy.txt"]\n'
                '[locations]\n'
                f'A = "{a.as_posix()}"\n'
                f'B = "{b.as_posix()}"\n'
                f'C = "{c.as_posix()}"\n',
                encoding="utf-8",
            )
            subprocess.run(["git", "init"], cwd=root, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "Test User"], cwd=root, check=True)
            subprocess.run(["git", "add", "master"], cwd=root, check=True)
            subprocess.run(["git", "commit", "-m", "init"], cwd=root, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            for folder in (master, a, b, c):
                (folder / "file.txt").write_text("中文更新\n", encoding="utf-8")
            result = file_flow.perform_commit("中文版本記錄", config)
            self.assertTrue(result.success, result.output)
            self.assertIn("中文版本記錄", result.output)


    def test_json_output_valid(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            result = file_flow.get_status_result(config)
            payload = file_flow.command_result_to_json(result)
            encoded = json.dumps(payload, ensure_ascii=False)
            self.assertIn("operation", json.loads(encoded))

    def test_binary_diff_no_garbage(self):
        tmp, root, config, master, a, b = self.make_workspace()
        with tmp:
            (master / "file.txt").write_bytes(b"\x00\x01\x02")
            (a / "file.txt").write_bytes(b"\x00\x01\x03")
            result = file_flow.get_diff_preview_result("A", config)
            self.assertIn("binary file differs", result.diff_text)


if __name__ == "__main__":
    unittest.main()
