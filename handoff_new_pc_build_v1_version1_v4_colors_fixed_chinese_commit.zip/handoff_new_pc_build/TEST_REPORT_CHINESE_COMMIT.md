# FileFlow Chinese Commit Fix Test Report

## Scope

This patch fixes a GUI/runtime bug triggered when using a Chinese version message in `記錄版本`.

## Root cause

`perform_commit()` combined subprocess stdout/stderr with direct `+` concatenation. In some runtime environments, either stream may be `None`, causing:

```text
unsupported operand type(s) for +: 'NoneType' and 'str'
```

The GUI also now defensively converts dialog text to a safe string before sending it to the core commit function.

## Fixes

- Normalize commit message with `str(message or "").strip()`.
- Guard subprocess stream handling with `(stdout or "")` / `(stderr or "")`.
- Use UTF-8 decoding with replacement for Git subprocess output.
- Replace visible commit wording with `記錄版本` / `記錄 Master`.
- Add unit test for Chinese commit message.

## Validation

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --smoke-test
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot /mnt/data/fileflow_commit_fix/main_after_commit_fix.png
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot-after commit-dialog /mnt/data/fileflow_commit_fix/commit_dialog_after_fix.png
python3 build_file_flow_exe.py --dry-run
```

Result:

```text
Ran 11 tests in 0.350s
OK
```

## Limitations

Windows `.exe` runtime testing still needs to be performed on Windows. Current environment validation covers source runtime, GUI smoke test, GUI screenshot, Git Chinese commit via core function, and build dry-run.
