from __future__ import annotations

import argparse
import hashlib
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

DEFAULT_CONFIG_NAME = "file_flow_paths.txt"
BACKUP_DIR_NAME = ".tool_backups"
RESERVED_CONFIG_KEYS = {"MASTER_FOLDER", "FILES"}
DUBIOUS_OWNERSHIP_PATTERN = re.compile(r"repository at '([^']+)'", re.IGNORECASE)
YES_WORDS = {"y", "yes", "1", "是"}
NO_WORDS = {"n", "no", "0", "否"}
INDEX_STATUS_TEXT = {
    "M": "已 git add 修改",
    "A": "已 git add 新增",
    "D": "已 git add 刪除",
    "R": "已 git add 重新命名",
    "C": "已 git add 複製",
    "U": "暫存區有衝突",
}
WORKTREE_STATUS_TEXT = {
    "M": "工作區已修改",
    "D": "工作區已刪除",
    "U": "工作區有衝突",
}

EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_CONFIG = 3
EXIT_VERIFY = 4
EXIT_GIT = 5


class FlowError(Exception):
    def __init__(self, message: str, exit_code: int = EXIT_FAILURE) -> None:
        super().__init__(message)
        self.exit_code = exit_code


@dataclass(frozen=True)
class FlowConfig:
    config_dir: Path
    config_path: Path
    master_folder: Path
    files: list[Path]
    locations: dict[str, Path]


@dataclass(frozen=True)
class FileState:
    path: Path
    exists: bool
    sha256: str | None


@dataclass(frozen=True)
class FileEntry:
    name: str
    relative_file: Path
    master_path: Path
    location_paths: dict[str, Path]


@dataclass(frozen=True)
class FileRecord:
    entry: FileEntry
    master: FileState
    locations: dict[str, FileState]
    git_status: str


@dataclass(frozen=True)
class CommandResult:
    title: str
    success: bool
    exit_code: int
    message: str
    output: str
    config: FlowConfig | None = None
    problems: tuple[str, ...] = ()
    records: tuple[FileRecord, ...] = ()
    diff_text: str = ""
    backup_dir: Path | None = None
    metadata: dict[str, str] = field(default_factory=dict)


def runtime_base_dir(*, frozen: bool | None = None, executable_path: Path | None = None) -> Path:
    if frozen is None:
        frozen = bool(getattr(sys, "frozen", False))
    if frozen:
        executable = executable_path or Path(sys.executable)
        return executable.resolve().parent
    return Path(__file__).resolve().parents[1]


def default_config_path(*, frozen: bool | None = None, executable_path: Path | None = None) -> Path:
    return runtime_base_dir(frozen=frozen, executable_path=executable_path) / DEFAULT_CONFIG_NAME


def resolve_config_path(config_path: Path | str | None = None) -> Path:
    if config_path is None:
        return default_config_path()
    return Path(config_path).expanduser()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="管理正式資料夾與多個工作位置的同步流程。")
    parser.add_argument(
        "--config",
        default=str(default_config_path()),
        help=f"設定檔路徑，預設使用 {DEFAULT_CONFIG_NAME}",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("status", help="查看正式資料夾與所有工作位置的目前狀態。")

    promote_parser = subparsers.add_parser("promote", help="採用某個工作位置的內容，更新正式資料夾。")
    promote_parser.add_argument("source", help="要採用的工作位置名稱。")
    promote_parser.add_argument("--diff", action="store_true", help="在執行前先顯示差異。")

    subparsers.add_parser("reset-all", help="用正式資料夾覆蓋全部工作位置。")
    subparsers.add_parser("verify", help="檢查所有檔案是否一致，並確認正式檔案可讀取 Git 狀態。")
    subparsers.add_parser("flow", help="用互動方式帶你完成日常操作。")
    return parser


def load_config(config_path: Path) -> FlowConfig:
    config_path = config_path.expanduser().resolve(strict=False)
    if not config_path.exists():
        raise FlowError(f"找不到設定檔: {config_path}", EXIT_CONFIG)
    if not config_path.is_file():
        raise FlowError(f"設定檔不是一般檔案: {config_path}", EXIT_CONFIG)

    raw_values: dict[str, str] = {}
    for lineno, raw_line in enumerate(config_path.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise FlowError(f"第 {lineno} 行格式錯誤，應為 KEY=VALUE", EXIT_CONFIG)
        key, value = [part.strip() for part in line.split("=", 1)]
        if not key:
            raise FlowError(f"第 {lineno} 行缺少鍵名", EXIT_CONFIG)
        if key in raw_values:
            raise FlowError(f"設定檔重複定義: {key}", EXIT_CONFIG)
        if not value:
            raise FlowError(f"{key} 沒有值", EXIT_CONFIG)
        raw_values[key] = value

    missing = [key for key in ("MASTER_FOLDER", "FILES") if key not in raw_values]
    if missing:
        raise FlowError(f"設定檔缺少必要欄位: {', '.join(missing)}", EXIT_CONFIG)

    config_dir = config_path.parent.resolve(strict=False)
    return FlowConfig(
        config_dir=config_dir,
        config_path=config_path,
        master_folder=resolve_folder_path(config_dir, raw_values["MASTER_FOLDER"]),
        files=parse_file_list(config_dir, raw_values["FILES"]),
        locations=parse_locations(config_dir, raw_values),
    )


def parse_file_list(config_dir: Path, value: str) -> list[Path]:
    files: list[Path] = []
    seen: set[str] = set()
    for item in [part.strip() for part in value.split(",")]:
        if not item:
            raise FlowError("FILES 裡有空白項目，請刪掉多餘的逗號。", EXIT_CONFIG)
        candidate = Path(item)
        if candidate.is_absolute():
            raise FlowError(f"FILES 只能放相對檔名，不能是完整路徑: {item}", EXIT_CONFIG)
        normalized = candidate.as_posix()
        if normalized in seen:
            raise FlowError(f"FILES 重複列出相同檔名: {item}", EXIT_CONFIG)
        resolved = resolve_child_path(config_dir, candidate, "FILES")
        try:
            files.append(resolved.relative_to(config_dir))
        except ValueError as exc:
            raise FlowError(f"FILES 內的檔名不能跳出設定檔所在資料夾: {item}", EXIT_CONFIG) from exc
        seen.add(normalized)
    if not files:
        raise FlowError("FILES 不能是空的。", EXIT_CONFIG)
    return files


def parse_locations(config_dir: Path, raw_values: dict[str, str]) -> dict[str, Path]:
    locations: dict[str, Path] = {}
    for key, value in raw_values.items():
        if key in RESERVED_CONFIG_KEYS:
            continue
        if re.search(r"\s", key):
            raise FlowError(f"工作位置名稱不能包含空白: {key}", EXIT_CONFIG)
        locations[key] = resolve_folder_path(config_dir, value)
    if not locations:
        raise FlowError("至少要設定一個工作位置，例如 A=... 或 B=...", EXIT_CONFIG)
    return locations


def resolve_folder_path(config_dir: Path, raw_path: str) -> Path:
    candidate = Path(raw_path).expanduser()
    if candidate.is_absolute():
        return candidate.resolve(strict=False)
    return (config_dir / candidate).resolve(strict=False)


def resolve_child_path(base_folder: Path, relative_path: Path, label: str) -> Path:
    if relative_path.is_absolute():
        raise FlowError(f"{label} 不能使用完整路徑: {relative_path}", EXIT_CONFIG)
    base_folder = base_folder.resolve(strict=False)
    target = (base_folder / relative_path).resolve(strict=False)
    try:
        target.relative_to(base_folder)
    except ValueError as exc:
        raise FlowError(f"{label} 不能跳出資料夾範圍: {relative_path.as_posix()}", EXIT_CONFIG) from exc
    return target


def make_file_entries(config: FlowConfig) -> list[FileEntry]:
    entries: list[FileEntry] = []
    for relative_file in config.files:
        entries.append(
            FileEntry(
                name=relative_file.as_posix(),
                relative_file=relative_file,
                master_path=resolve_child_path(config.master_folder, relative_file, "FILES"),
                location_paths={
                    location_name: resolve_child_path(location_folder, relative_file, "FILES")
                    for location_name, location_folder in config.locations.items()
                },
            )
        )
    return entries


def display_path(base_dir: Path, path: Path) -> str:
    try:
        return path.relative_to(base_dir).as_posix()
    except ValueError:
        return str(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def get_file_state(path: Path) -> FileState:
    exists = path.exists()
    if exists and not path.is_file():
        raise FlowError(f"這不是一般檔案: {path}", EXIT_FAILURE)
    return FileState(path=path, exists=exists, sha256=sha256_file(path) if exists else None)


def ensure_file(path: Path, label: str, exit_code: int) -> None:
    if not path.exists():
        raise FlowError(f"{label} 不存在: {path}", exit_code)
    if not path.is_file():
        raise FlowError(f"{label} 不是一般檔案: {path}", exit_code)


def path_for_git(git_root: Path, path: Path) -> str:
    try:
        return path.relative_to(git_root).as_posix()
    except ValueError:
        return str(path)


def run_git(working_dir: Path, arguments: list[str]) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            ["git", *arguments],
            cwd=working_dir,
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise FlowError("找不到 git，請先安裝 Git。", EXIT_GIT) from exc


def describe_git_error(path: Path, message: str) -> str:
    if "detected dubious ownership" not in message.lower():
        return message
    match = DUBIOUS_OWNERSHIP_PATTERN.search(message)
    safe_directory = match.group(1) if match else str(path.parent)
    return (
        "Git 安全檢查擋下這個資料夾。"
        f' 請先執行: git config --global --add safe.directory "{safe_directory}"'
    )


def find_git_root_for_path(path: Path) -> Path:
    probe_dir = path if path.is_dir() else path.parent
    result = run_git(probe_dir, ["rev-parse", "--show-toplevel"])
    if result.returncode != 0:
        message = result.stderr.strip() or "無法取得 Git 最上層資料夾。"
        raise FlowError(describe_git_error(path, message), EXIT_GIT)
    return Path(result.stdout.strip()).resolve(strict=False)


def git_status_for_path(target_path: Path) -> str:
    raw_lines = git_status_lines_for_path(target_path)
    return format_git_status_lines(raw_lines)


def git_status_lines_for_path(target_path: Path) -> list[str]:
    git_root = find_git_root_for_path(target_path)
    try:
        relative_path = target_path.relative_to(git_root).as_posix()
    except ValueError as exc:
        raise FlowError(f"正式檔案不在 Git 資料夾內: {target_path}", EXIT_GIT) from exc
    result = run_git(git_root, ["status", "--short", "--", relative_path])
    if result.returncode != 0:
        message = result.stderr.strip() or "git status 執行失敗。"
        raise FlowError(describe_git_error(target_path, message), EXIT_GIT)
    return [line.rstrip() for line in result.stdout.splitlines() if line.strip()]


def format_git_status_lines(lines: list[str]) -> str:
    if not lines:
        return "沒有 Git 變更"
    return "；".join(describe_git_status_line(line) for line in lines)


def describe_git_status_line(line: str) -> str:
    if line.startswith("?? "):
        return f"新檔案，尚未加入 Git | {line[3:].strip()}"
    if line.startswith("!! "):
        return f"已被 .gitignore 忽略 | {line[3:].strip()}"

    index_status = line[0] if len(line) >= 1 else " "
    worktree_status = line[1] if len(line) >= 2 else " "
    path_text = line[3:].strip() if len(line) >= 4 else line.strip()

    if index_status == "M" and worktree_status == "M":
        description = "已 git add，但之後又被修改"
    elif index_status == "A" and worktree_status == "M":
        description = "新檔案已 git add，但之後又被修改"
    else:
        parts: list[str] = []
        staged_text = INDEX_STATUS_TEXT.get(index_status)
        worktree_text = WORKTREE_STATUS_TEXT.get(worktree_status)
        if staged_text:
            parts.append(staged_text)
        if worktree_text:
            parts.append(worktree_text)
        description = "，".join(parts) if parts else line[:2].strip() or "狀態未知"

    return f"{description} | {path_text}"


def git_diff_files(base_dir: Path, left_path: Path, right_path: Path) -> str:
    result = run_git(base_dir, ["diff", "--no-index", "--", str(left_path), str(right_path)])
    if result.returncode not in (0, 1):
        message = result.stderr.strip() or "git diff 執行失敗。"
        raise FlowError(describe_git_error(left_path, message), EXIT_GIT)
    return result.stdout.rstrip()


def describe_diff_line_content(line: str) -> str:
    return line if line else "（空白行）"


def summarize_unified_diff(diff_output: str, source_name: str) -> list[str]:
    if not diff_output.strip():
        return ["- 沒有差異"]

    added_lines: list[str] = []
    removed_lines: list[str] = []
    modified_lines: list[tuple[str, str]] = []
    pending_added: list[str] = []
    pending_removed: list[str] = []
    saw_missing_newline = False

    def flush_pending() -> None:
        pair_count = min(len(pending_removed), len(pending_added))
        for index in range(pair_count):
            modified_lines.append((pending_removed[index], pending_added[index]))
        removed_lines.extend(pending_removed[pair_count:])
        added_lines.extend(pending_added[pair_count:])
        pending_removed.clear()
        pending_added.clear()

    for raw_line in diff_output.splitlines():
        if raw_line.startswith(("diff --git ", "index ", "--- ", "+++ ")):
            continue
        if raw_line.startswith("@@ "):
            flush_pending()
            continue
        if raw_line == r"\ No newline at end of file":
            saw_missing_newline = True
            continue
        if raw_line.startswith("-") and not raw_line.startswith("--- "):
            pending_removed.append(raw_line[1:])
            continue
        if raw_line.startswith("+") and not raw_line.startswith("+++ "):
            pending_added.append(raw_line[1:])
            continue
        if raw_line.startswith(" "):
            flush_pending()

    flush_pending()

    summary_lines: list[str] = []
    if modified_lines and not added_lines and not removed_lines:
        summary_lines.append(f"- 有 {len(modified_lines)} 行內容不同。")
    elif removed_lines and not added_lines and not modified_lines:
        summary_lines.append(f"- {source_name} 比正式版本少 {len(removed_lines)} 行。")
    elif added_lines and not removed_lines and not modified_lines:
        summary_lines.append(f"- {source_name} 比正式版本多 {len(added_lines)} 行。")
    else:
        total_changes = len(modified_lines) + len(removed_lines) + len(added_lines)
        summary_lines.append(f"- 一共有 {total_changes} 處差異。")

    detail_lines: list[str] = []
    detail_budget = 5

    for before_text, after_text in modified_lines:
        if len(detail_lines) >= detail_budget:
            break
        detail_lines.append(
            f"- 把「{describe_diff_line_content(before_text)}」改成「{describe_diff_line_content(after_text)}」"
        )

    for removed_text in removed_lines:
        if len(detail_lines) >= detail_budget:
            break
        detail_lines.append(f"- 正式版本多這一行：{describe_diff_line_content(removed_text)}")

    for added_text in added_lines:
        if len(detail_lines) >= detail_budget:
            break
        detail_lines.append(f"- {source_name} 多這一行：{describe_diff_line_content(added_text)}")

    remaining_details = len(modified_lines) + len(removed_lines) + len(added_lines) - len(detail_lines)
    if remaining_details > 0:
        detail_lines.append(f"- 另外還有 {remaining_details} 處差異沒有展開。")

    if saw_missing_newline:
        detail_lines.append("- 補充：其中一個版本的檔案結尾沒有換行。")

    return summary_lines + detail_lines


def git_add_path(target_path: Path) -> Path:
    git_root = find_git_root_for_path(target_path)
    result = run_git(git_root, ["add", "--", path_for_git(git_root, target_path)])
    if result.returncode != 0:
        message = result.stderr.strip() or result.stdout.strip() or "git add 執行失敗。"
        raise FlowError(describe_git_error(target_path, message), EXIT_GIT)
    return git_root


def git_commit_message(git_root: Path, message: str) -> None:
    result = run_git(git_root, ["commit", "-m", message])
    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip() or "git commit 執行失敗。"
        raise FlowError(describe_git_error(git_root, detail), EXIT_GIT)


def build_status_records(config: FlowConfig, entries: list[FileEntry]) -> tuple[list[FileRecord], list[str]]:
    records: list[FileRecord] = []
    summary_problems: list[str] = []
    for entry in entries:
        master_state = get_file_state(entry.master_path)
        if master_state.exists:
            try:
                git_summary = git_status_for_path(master_state.path)
            except FlowError as exc:
                if exc.exit_code != EXIT_GIT:
                    raise
                git_summary = f"Git 檢查失敗 | {exc}"
        else:
            git_summary = "Git 檢查略過，因為正式檔案不存在"

        location_states: dict[str, FileState] = {}
        if not master_state.exists:
            summary_problems.append(f"{entry.name}: 正式版本不存在")

        for location_name, location_path in entry.location_paths.items():
            location_state = get_file_state(location_path)
            location_states[location_name] = location_state
            if not location_state.exists:
                summary_problems.append(f"{entry.name}: {location_name} 不存在")
            elif master_state.sha256 is not None and location_state.sha256 != master_state.sha256:
                summary_problems.append(f"{entry.name}: {location_name} 和正式版本不同")

        records.append(
            FileRecord(
                entry=entry,
                master=master_state,
                locations=location_states,
                git_status=git_summary,
            )
        )
    return records, list(dict.fromkeys(summary_problems))


def collect_sync_problems(entries: list[FileEntry]) -> list[str]:
    problems: list[str] = []
    for entry in entries:
        master_state = get_file_state(entry.master_path)
        if not master_state.exists:
            problems.append(f"{entry.name}: 正式版本不存在")
        for location_name, location_path in entry.location_paths.items():
            location_state = get_file_state(location_path)
            if not location_state.exists:
                problems.append(f"{entry.name}: {location_name} 不存在")
            elif master_state.sha256 is not None and location_state.sha256 != master_state.sha256:
                problems.append(f"{entry.name}: {location_name} 和正式版本不同")
    return list(dict.fromkeys(problems))


def ensure_all_in_sync_for_config(config: FlowConfig, entries: list[FileEntry], exit_code: int) -> tuple[tuple[str, ...], tuple[FileRecord, ...]]:
    records, problems = build_status_records(config, entries)
    if problems:
        raise FlowError("; ".join(problems), exit_code)
    return tuple(), tuple(records)


def validate_promote_source(entries: list[FileEntry], source_name: str) -> None:
    for entry in entries:
        ensure_file(entry.master_path, f"正式檔案 {entry.name}", EXIT_FAILURE)
        ensure_file(entry.location_paths[source_name], f"{source_name} 的檔案 {entry.name}", EXIT_FAILURE)
        find_git_root_for_path(entry.master_path)


def build_diff_text(config: FlowConfig, source_name: str, entries: list[FileEntry]) -> str:
    validate_promote_source(entries, source_name)
    sections: list[str] = []
    for entry in entries:
        diff_output = git_diff_files(config.config_dir, entry.master_path, entry.location_paths[source_name])
        section_lines = [f"差異: {entry.name}", *summarize_unified_diff(diff_output, source_name)]
        sections.append("\n".join(section_lines))
    return "\n\n".join(sections)


def backup_master_files(entries: list[FileEntry], backup_root: Path) -> Path:
    backup_dir = backup_root / datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    backup_dir.mkdir(parents=True, exist_ok=False)
    for entry in entries:
        ensure_file(entry.master_path, f"正式檔案 {entry.name}", EXIT_FAILURE)
        backup_path = resolve_child_path(backup_dir, entry.relative_file, "FILES")
        backup_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(entry.master_path, backup_path)
    return backup_dir


def copy_file(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def sync_all_from_master(entries: list[FileEntry]) -> None:
    for entry in entries:
        ensure_file(entry.master_path, f"正式檔案 {entry.name}", EXIT_FAILURE)
        for destination in entry.location_paths.values():
            copy_file(entry.master_path, destination)


def perform_promote(config: FlowConfig, source_name: str) -> Path:
    if source_name not in config.locations:
        raise FlowError(f"找不到工作位置 {source_name}，可用名稱: {', '.join(config.locations)}", EXIT_CONFIG)
    entries = make_file_entries(config)
    validate_promote_source(entries, source_name)
    backup_dir = backup_master_files(entries, config.config_dir / BACKUP_DIR_NAME)
    for entry in entries:
        copy_file(entry.location_paths[source_name], entry.master_path)
    sync_all_from_master(entries)
    ensure_all_in_sync_for_config(config, entries, EXIT_FAILURE)
    return backup_dir


def perform_commit(config: FlowConfig, message: str) -> bool:
    git_root = git_add_path(config.master_folder)
    if not git_status_lines_for_path(config.master_folder):
        return False
    git_commit_message(git_root, message)
    return True


def create_failure_result(title: str, exc: FlowError, config: FlowConfig | None = None) -> CommandResult:
    return CommandResult(
        title=title,
        success=False,
        exit_code=exc.exit_code,
        message=str(exc),
        output=f"ERROR: {exc}",
        config=config,
        problems=(str(exc),),
    )


def format_status_result(config: FlowConfig, records: list[FileRecord], summary_problems: list[str]) -> str:
    lines = [
        f"設定檔: {config.config_path}",
        f"正式資料夾: {config.master_folder}",
        f"工作位置: {', '.join(config.locations)}",
    ]

    for record in records:
        lines.append("")
        lines.append(f"檔案: {record.entry.name}")
        if record.master.exists:
            lines.append(
                "  正式版本: 存在"
                f" | {display_path(config.config_dir, record.master.path)}"
                f" | sha256={record.master.sha256}"
            )
        else:
            lines.append(f"  正式版本: 不存在 | {display_path(config.config_dir, record.master.path)}")

        for location_name, location_state in record.locations.items():
            if location_state.exists:
                line = (
                    f"  {location_name}: 存在"
                    f" | {display_path(config.config_dir, location_state.path)}"
                    f" | sha256={location_state.sha256}"
                )
            else:
                line = f"  {location_name}: 不存在 | {display_path(config.config_dir, location_state.path)}"

            if record.master.sha256 is None or location_state.sha256 is None:
                line += " | 無法比較"
            elif location_state.sha256 == record.master.sha256:
                line += " | 和正式版本相同"
            else:
                line += " | 和正式版本不同"
            lines.append(line)

        lines.append(f"  Git 狀態: {record.git_status}")

    lines.append("")
    if summary_problems:
        lines.append("摘要: " + "; ".join(summary_problems))
    else:
        lines.append("摘要: 全部檔案都存在，而且所有工作位置都和正式版本一致。")
    return "\n".join(lines)


def format_success_output(title: str, lines: list[str]) -> str:
    return "\n".join(line for line in lines if line is not None)


def combine_results(title: str, *results: CommandResult, message: str | None = None) -> CommandResult:
    first_failure = next((result for result in results if not result.success), None)
    if first_failure is not None:
        output = "\n\n".join(result.output for result in results if result.output)
        return CommandResult(
            title=title,
            success=False,
            exit_code=first_failure.exit_code,
            message=first_failure.message,
            output=output,
            config=first_failure.config or next((r.config for r in results if r.config is not None), None),
            problems=tuple(dict.fromkeys(problem for result in results for problem in result.problems)),
            records=tuple(record for result in results for record in result.records),
            diff_text="\n\n".join(result.diff_text for result in results if result.diff_text),
            backup_dir=next((result.backup_dir for result in results if result.backup_dir is not None), None),
            metadata={key: value for result in results for key, value in result.metadata.items()},
        )

    combined_output = "\n\n".join(result.output for result in results if result.output)
    return CommandResult(
        title=title,
        success=True,
        exit_code=EXIT_OK,
        message=message or (results[-1].message if results else ""),
        output=combined_output,
        config=next((result.config for result in reversed(results) if result.config is not None), None),
        problems=tuple(dict.fromkeys(problem for result in results for problem in result.problems)),
        records=tuple(record for result in results for record in result.records),
        diff_text="\n\n".join(result.diff_text for result in results if result.diff_text),
        backup_dir=next((result.backup_dir for result in results if result.backup_dir is not None), None),
        metadata={key: value for result in results for key, value in result.metadata.items()},
    )


def get_status_result(config_path: Path | str | None = None) -> CommandResult:
    title = "查看狀態"
    try:
        config = load_config(resolve_config_path(config_path))
        entries = make_file_entries(config)
        records, summary_problems = build_status_records(config, entries)
        output = format_status_result(config, records, summary_problems)
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message="已整理目前狀態。",
            output=output,
            config=config,
            problems=tuple(summary_problems),
            records=tuple(records),
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def get_verify_result(config_path: Path | str | None = None) -> CommandResult:
    title = "驗證"
    try:
        config = load_config(resolve_config_path(config_path))
        entries = make_file_entries(config)
        problems, records = ensure_all_in_sync_for_config(config, entries, EXIT_VERIFY)
        del problems
        for entry in entries:
            git_status_for_path(entry.master_path)
        message = "全部檔案都存在、內容一致，而且正式檔案可正常檢查 Git 狀態。"
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message=message,
            output=f"VERIFY OK: {message}",
            config=config,
            records=records,
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def get_promote_preview_result(source_name: str, config_path: Path | str | None = None) -> CommandResult:
    title = "差異預覽"
    try:
        config = load_config(resolve_config_path(config_path))
        entries = make_file_entries(config)
        diff_text = build_diff_text(config, source_name, entries)
        output_lines = [f"以下是 {source_name} 和正式版本的差異：", "", diff_text]
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message=f"已產生 {source_name} 的差異預覽。",
            output="\n".join(output_lines),
            config=config,
            diff_text=diff_text,
            metadata={"source_name": source_name},
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def get_promote_result(source_name: str, show_diff: bool = False, config_path: Path | str | None = None) -> CommandResult:
    title = "採用工作位置"
    try:
        config = load_config(resolve_config_path(config_path))
        entries = make_file_entries(config)
        diff_text = build_diff_text(config, source_name, entries) if show_diff else ""
        backup_dir = perform_promote(config, source_name)
        records, summary_problems = build_status_records(config, entries)
        del summary_problems
        lines: list[str] = []
        if diff_text:
            lines.extend([diff_text, ""])
        lines.extend(
            [
                f"已將 {source_name} 提升為正式版本。",
                f"備份位置: {display_path(config.config_dir, backup_dir)}",
                "全部檔案已同步回所有工作位置。",
            ]
        )
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message=f"已將 {source_name} 提升為正式版本。",
            output="\n".join(lines),
            config=config,
            records=tuple(records),
            diff_text=diff_text,
            backup_dir=backup_dir,
            metadata={"source_name": source_name},
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def get_reset_all_result(config_path: Path | str | None = None) -> CommandResult:
    title = "全部重置"
    try:
        config = load_config(resolve_config_path(config_path))
        entries = make_file_entries(config)
        for entry in entries:
            ensure_file(entry.master_path, f"正式檔案 {entry.name}", EXIT_FAILURE)
        sync_all_from_master(entries)
        _, records = ensure_all_in_sync_for_config(config, entries, EXIT_FAILURE)
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message="已用正式資料夾覆蓋全部工作位置。",
            output="已用正式資料夾覆蓋全部工作位置。",
            config=config,
            records=records,
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def get_commit_result(message: str, config_path: Path | str | None = None) -> CommandResult:
    title = "Commit 正式資料夾"
    try:
        config = load_config(resolve_config_path(config_path))
        committed = perform_commit(config, message)
        if committed:
            success_message = "已完成 commit。"
        else:
            success_message = "正式資料夾沒有變更，不需要 commit。"
        return CommandResult(
            title=title,
            success=True,
            exit_code=EXIT_OK,
            message=success_message,
            output=success_message,
            config=config,
            metadata={"commit_message": message},
        )
    except FlowError as exc:
        return create_failure_result(title, exc)


def print_command_result(result: CommandResult) -> int:
    target = sys.stdout if result.success else sys.stderr
    print(result.output, file=target)
    return result.exit_code


def prompt_menu_choice(prompt_text: str, options: list[tuple[str, str]]) -> str:
    while True:
        print(prompt_text)
        for index, (_, label) in enumerate(options, start=1):
            print(f"{index}. {label}")
        raw = input("請輸入選項: ").strip()
        if raw.isdigit():
            choice = int(raw)
            if 1 <= choice <= len(options):
                return options[choice - 1][0]
        lowered = raw.lower()
        for key, _ in options:
            if lowered == key.lower():
                return key
        print("輸入無效，請重新選擇。")
        print("")


def prompt_yes_no(prompt_text: str) -> bool:
    while True:
        raw = input(prompt_text).strip().lower()
        if raw in YES_WORDS:
            return True
        if raw in NO_WORDS:
            return False
        print("請輸入 y 或 n。")


def status_command(args: argparse.Namespace) -> int:
    return print_command_result(get_status_result(args.config))


def promote_command(args: argparse.Namespace) -> int:
    return print_command_result(get_promote_result(args.source, show_diff=args.diff, config_path=args.config))


def reset_all_command(args: argparse.Namespace) -> int:
    return print_command_result(get_reset_all_result(args.config))


def verify_command(args: argparse.Namespace) -> int:
    return print_command_result(get_verify_result(args.config))


def flow_command(args: argparse.Namespace) -> int:
    status_result = get_status_result(args.config)
    print("目前狀態摘要")
    print("")
    print(status_result.output)
    if not status_result.success:
        return status_result.exit_code

    config = status_result.config
    assert config is not None

    print("")
    action = prompt_menu_choice(
        "接下來要做什麼？",
        [
            ("promote", "從某個工作位置更新正式版本"),
            ("reset-all", "用正式版本覆蓋全部工作位置"),
            ("exit", "結束"),
        ],
    )
    if action == "exit":
        print("已結束，沒有變更任何檔案。")
        return EXIT_OK

    if action == "promote":
        options = [(name, f"{name} -> {display_path(config.config_dir, folder)}") for name, folder in config.locations.items()]
        source_name = prompt_menu_choice("請選擇要採用哪個工作位置：", options)
        print("")
        preview_result = get_promote_preview_result(source_name, args.config)
        print(preview_result.output)
        if not preview_result.success:
            return preview_result.exit_code
        print("")
        if not prompt_yes_no(f"確認要把 {source_name} 提升為正式版本嗎？ [y/n]: "):
            print("已取消，沒有變更任何檔案。")
            return EXIT_OK
        action_result = get_promote_result(source_name, show_diff=False, config_path=args.config)
        print("")
        print(action_result.output)
        if not action_result.success:
            return action_result.exit_code
    else:
        if not prompt_yes_no("確認要用正式版本覆蓋全部工作位置嗎？ [y/n]: "):
            print("已取消，沒有變更任何檔案。")
            return EXIT_OK
        action_result = get_reset_all_result(args.config)
        print(action_result.output)
        if not action_result.success:
            return action_result.exit_code

    verify_result = get_verify_result(args.config)
    print("")
    print(verify_result.output)
    if not verify_result.success:
        print("驗證失敗，這次不會進入 commit。")
        return verify_result.exit_code

    if not prompt_yes_no("要不要順手 commit 正式資料夾的變更？ [y/n]: "):
        print("這次不執行 commit。")
        return EXIT_OK

    message = input("請輸入 commit 訊息，留空代表取消: ").strip()
    if not message:
        print("已取消 commit。")
        return EXIT_OK

    commit_result = get_commit_result(message, args.config)
    print(commit_result.output)
    return commit_result.exit_code


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    commands = {
        "status": status_command,
        "promote": promote_command,
        "reset-all": reset_all_command,
        "verify": verify_command,
        "flow": flow_command,
    }
    return commands[args.command](args)


if __name__ == "__main__":
    raise SystemExit(main())
