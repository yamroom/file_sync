@echo off
setlocal
cd /d "%~dp0"

echo Installing requirements...
python -m pip install -r requirements.txt
if errorlevel 1 goto :fail

echo.
echo Building FileFlowApp.exe...
python build_file_flow_exe.py
if errorlevel 1 goto :fail

echo.
echo Build complete.
echo Output:
echo   dist\FileFlowApp.exe
echo   dist\file_flow_paths.txt
pause
exit /b 0

:fail
echo.
echo Build failed.
pause
exit /b 1
