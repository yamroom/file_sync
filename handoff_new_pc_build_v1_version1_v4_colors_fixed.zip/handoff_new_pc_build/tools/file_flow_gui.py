from __future__ import annotations

import argparse
import html
import os
import sys
from pathlib import Path
from typing import Any, Callable

try:
    from PySide6.QtCore import QObject, QThread, Qt, QTimer, QUrl, Signal, Slot
    from PySide6.QtGui import QAction, QColor, QDesktopServices
    from PySide6.QtWidgets import (
        QApplication,
        QComboBox,
        QDialog,
        QDialogButtonBox,
        QFrame,
        QGridLayout,
        QHBoxLayout,
        QHeaderView,
        QInputDialog,
        QLabel,
        QLineEdit,
        QMainWindow,
        QMenu,
        QMessageBox,
        QProgressBar,
        QPushButton,
        QStackedWidget,
        QTableWidget,
        QTableWidgetItem,
        QTabWidget,
        QTextBrowser,
        QToolButton,
        QVBoxLayout,
        QWidget,
    )
    PYSIDE6_IMPORT_ERROR: ModuleNotFoundError | None = None
except ModuleNotFoundError as exc:  # pragma: no cover - runtime dependent
    QObject = object  # type: ignore[assignment]
    QThread = object  # type: ignore[assignment]
    Qt = object  # type: ignore[assignment]
    QTimer = object  # type: ignore[assignment]
    QUrl = object  # type: ignore[assignment]

    def Signal(*_args, **_kwargs):  # type: ignore[override]
        return None

    def Slot(*_args, **_kwargs):  # type: ignore[override]
        def decorator(function):
            return function
        return decorator

    QApplication = object  # type: ignore[assignment]
    QAction = object  # type: ignore[assignment]
    QColor = object  # type: ignore[assignment]
    QComboBox = object  # type: ignore[assignment]
    QDesktopServices = object  # type: ignore[assignment]
    QDialog = object  # type: ignore[assignment]
    QDialogButtonBox = object  # type: ignore[assignment]
    QFrame = object  # type: ignore[assignment]
    QGridLayout = object  # type: ignore[assignment]
    QHBoxLayout = object  # type: ignore[assignment]
    QHeaderView = object  # type: ignore[assignment]
    QInputDialog = object  # type: ignore[assignment]
    QLabel = object  # type: ignore[assignment]
    QLineEdit = object  # type: ignore[assignment]
    QMainWindow = object  # type: ignore[assignment]
    QMenu = object  # type: ignore[assignment]
    QMessageBox = object  # type: ignore[assignment]
    QProgressBar = object  # type: ignore[assignment]
    QPushButton = object  # type: ignore[assignment]
    QStackedWidget = object  # type: ignore[assignment]
    QTableWidget = object  # type: ignore[assignment]
    QTableWidgetItem = object  # type: ignore[assignment]
    QTabWidget = object  # type: ignore[assignment]
    QTextBrowser = object  # type: ignore[assignment]
    QToolButton = object  # type: ignore[assignment]
    QVBoxLayout = object  # type: ignore[assignment]
    QWidget = object  # type: ignore[assignment]
    PYSIDE6_IMPORT_ERROR = exc

from . import file_flow

APP_TITLE = "FileFlow"

STATUS_COLORS = {
    # Match the stronger Version 4 pill colors while keeping the Version 1 layout.
    file_flow.STATUS_SAME: "#DDF5E8",
    file_flow.STATUS_OK: "#DDF5E8",
    file_flow.STATUS_COPIED: "#E2EEFF",
    file_flow.STATUS_UNTRACKED: "#E2EEFF",
    file_flow.STATUS_MODIFIED: "#FFE7A8",
    file_flow.STATUS_DELETED: "#FFD6CC",
    file_flow.STATUS_SKIPPED: "#EEF3F1",
    file_flow.STATUS_DIFFERENT: "#FFE7A8",
    file_flow.STATUS_MISSING: "#FFD6CC",
    file_flow.STATUS_PERMISSION_DENIED: "#FFD6CC",
    file_flow.STATUS_UNREADABLE: "#FFD6CC",
    file_flow.STATUS_ERROR: "#FFD6CC",
    file_flow.STATUS_UNKNOWN: "#EEF3F1",
}
STATUS_FOREGROUNDS = {
    file_flow.STATUS_SAME: "#21784C",
    file_flow.STATUS_OK: "#21784C",
    file_flow.STATUS_COPIED: "#245EAC",
    file_flow.STATUS_UNTRACKED: "#245EAC",
    file_flow.STATUS_MODIFIED: "#855E12",
    file_flow.STATUS_DELETED: "#A44732",
    file_flow.STATUS_SKIPPED: "#5C6B70",
    file_flow.STATUS_DIFFERENT: "#855E12",
    file_flow.STATUS_MISSING: "#A44732",
    file_flow.STATUS_PERMISSION_DENIED: "#A44732",
    file_flow.STATUS_UNREADABLE: "#A44732",
    file_flow.STATUS_ERROR: "#A44732",
    file_flow.STATUS_UNKNOWN: "#5C6B70",
}
STATUS_TEXT = {
    file_flow.STATUS_OK: "OK",
    file_flow.STATUS_SAME: "OK",
    file_flow.STATUS_DIFFERENT: "Diff",
    file_flow.STATUS_MISSING: "Miss",
    file_flow.STATUS_PERMISSION_DENIED: "Err",
    file_flow.STATUS_UNREADABLE: "Err",
    file_flow.STATUS_UNTRACKED: "New",
    file_flow.STATUS_MODIFIED: "Mod",
    file_flow.STATUS_DELETED: "Del",
    file_flow.STATUS_ERROR: "Err",
    file_flow.STATUS_UNKNOWN: "Unknown",
    file_flow.STATUS_SKIPPED: "Skip",
    file_flow.STATUS_COPIED: "Copy",
}

APP_STYLESHEET = """
QWidget {
    background: #F5F7F6;
    color: #1C2A2E;
    font-family: "Inter", "Segoe UI", "Noto Sans CJK TC", "Microsoft JhengHei", sans-serif;
    font-size: 12px;
}
QMainWindow { background: #F5F7F6; }
QLabel { background: transparent; }
QLabel#Title {
    color: #102327;
    font-size: 21px;
    font-weight: 850;
    letter-spacing: -0.3px;
}
QLabel#Subtitle, QLabel#MetaText, QLabel#SmallText {
    color: #6D7A7E;
    font-size: 11px;
}
QLabel#CardTitle {
    color: #22383D;
    font-size: 12px;
    font-weight: 800;
}
QLabel#StatusPill {
    border-radius: 11px;
    padding: 4px 10px;
    font-weight: 850;
    background: #EAF7EF;
    color: #17643A;
}
QLabel#TinyPill {
    border-radius: 9px;
    padding: 3px 8px;
    background: #F0F4F3;
    color: #435358;
    font-weight: 750;
}
QLabel#StatusCell {
    border-radius: 10px;
    padding: 3px 7px;
    font-weight: 850;
    min-width: 34px;
}
QLabel#SuggestionText {
    color: #284146;
    font-size: 11px;
    font-weight: 700;
}
QFrame#HeaderCard, QFrame#SummaryCard, QFrame#CenterCard, QFrame#ActionCard, QFrame#FooterCard {
    background: #FFFFFF;
    border: 1px solid #E1E8E6;
    border-radius: 17px;
}
QFrame#HeaderCard { background: #FFFFFF; }
QFrame#FooterCard { background: #FAFCFB; }
QPushButton, QToolButton {
    min-height: 28px;
    color: #223538;
    background: #EEF4F2;
    border: 1px solid #DCE6E3;
    border-radius: 12px;
    padding: 4px 11px;
    font-weight: 800;
}
QPushButton:hover, QToolButton:hover { background: #E5EEEB; }
QPushButton:pressed, QToolButton:pressed { background: #D7E4E0; }
QPushButton:disabled, QToolButton:disabled {
    color: #A6B1B4;
    background: #F2F5F4;
    border-color: #E7EDEB;
}
QPushButton#PrimaryButton {
    color: #FFFFFF;
    background: #0F6E76;
    border: 1px solid #0F6E76;
}
QPushButton#PrimaryButton:hover { background: #0C5E65; }
QPushButton#DangerButton {
    color: #8B3519;
    background: #FFF0EA;
    border: 1px solid #FFD3C1;
}
QPushButton#DangerButton:hover { background: #FFE5D8; }
QPushButton#InlineButton {
    min-height: 22px;
    border-radius: 10px;
    padding: 2px 9px;
    color: #0F5961;
    background: #EAF5F3;
}
QPushButton#SegmentButton {
    min-height: 30px;
    border-radius: 10px;
    padding: 4px 14px;
    background: #FFFFFF;
    border: 1px solid #E0E8E5;
    color: #5A696D;
    font-weight: 850;
}
QPushButton#SegmentButton[active="true"] {
    background: #E6F3F1;
    border-color: #CDE3DF;
    color: #0F5961;
}
QPushButton#SmallToolButton {
    min-height: 22px;
    border-radius: 9px;
    padding: 1px 8px;
    background: #FFFFFF;
    border: 1px solid #DCE6E3;
    color: #435358;
    font-weight: 850;
}
QToolButton#MoreButton {
    background: #FFFFFF;
    color: #223538;
}
QComboBox {
    min-height: 27px;
    background: #FFFFFF;
    color: #213236;
    border: 1px solid #DCE6E3;
    border-radius: 11px;
    padding: 4px 9px;
    font-weight: 700;
}
QComboBox::drop-down { border: 0; width: 20px; }
QMenu {
    background: #FFFFFF;
    border: 1px solid #DCE6E3;
    border-radius: 11px;
    padding: 6px;
}
QMenu::item { padding: 7px 18px; border-radius: 8px; color: #25383D; }
QMenu::item:selected { background: #EAF2F0; }
QTabWidget::pane {
    border: 0;
    background: #FFFFFF;
}
QTabBar::tab {
    color: #536266;
    background: #F0F4F3;
    border: 1px solid #E0E8E5;
    border-radius: 10px;
    padding: 5px 12px;
    margin-right: 5px;
    font-weight: 750;
}
QTabBar::tab:selected {
    color: #0F5961;
    background: #E6F3F1;
    border-color: #CDE3DF;
}
QTableWidget {
    background: #FFFFFF;
    border: 0;
    gridline-color: #EEF3F1;
    alternate-background-color: #FAFCFB;
    selection-background-color: #E7F1FF;
    selection-color: #102529;
}
QTableWidget::item { border-bottom: 1px solid #EEF3F1; padding: 4px; }
QHeaderView::section {
    background: #F2F6F5;
    color: #33494E;
    border: 0;
    border-bottom: 1px solid #E0E8E5;
    padding: 6px;
    font-weight: 850;
}
QTextBrowser {
    background: #FCFDFD;
    color: #24363A;
    border: 1px solid #E1E8E6;
    border-radius: 12px;
    padding: 8px;
    font-family: "Cascadia Mono", "Consolas", monospace;
    font-size: 10px;
}
QProgressBar {
    border: 0;
    border-radius: 5px;
    height: 6px;
    background: #EAF0EE;
}
QProgressBar::chunk { border-radius: 5px; background: #0F6E76; }
QDialog { background: #F6F8F7; }
QLineEdit {
    background: #FFFFFF;
    border: 1px solid #DCE6E3;
    border-radius: 9px;
    padding: 6px;
}
QScrollBar:vertical { background: transparent; width: 9px; margin: 2px; }
QScrollBar::handle:vertical { background: #C8D4D1; border-radius: 4px; min-height: 22px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { height: 0; background: transparent; }
"""


class Worker(QObject):
    finished = Signal(object)
    failed = Signal(str)
    progress = Signal(object)

    def __init__(self, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        super().__init__()
        self.action = action
        self.with_progress = with_progress

    @Slot()
    def run(self) -> None:
        try:
            if self.with_progress:
                self.finished.emit(self.action(self.progress.emit))
            else:
                self.finished.emit(self.action())
        except Exception as exc:  # noqa: BLE001 - GUI should report user-facing errors
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self, config_path: Path | None = None) -> None:
        super().__init__()
        self.config_path = file_flow.resolve_config_path(config_path)
        self.config: file_flow.FlowConfig | None = None
        self.last_result: file_flow.CommandResult | None = None
        self.last_log_path: Path | None = None
        self.last_json_path: Path | None = None
        self.last_backup_path: Path | None = None
        self.cell_details: dict[tuple[int, int], dict[str, Any]] = {}
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self._current_dialog: QDialog | QMessageBox | None = None
        self.details_font_size = 12
        self.setWindowTitle(APP_TITLE)
        self.setMinimumSize(512, 384)
        self._resize_to_quarter_screen()
        self.setStyleSheet(APP_STYLESHEET)
        self._build_ui()
        self.run_background("重新檢查", lambda: file_flow.get_status_result(self.config_path))

    def _resize_to_quarter_screen(self) -> None:
        app = QApplication.instance()
        screen = app.primaryScreen() if app else None
        if screen is None:
            self.resize(512, 384)
            return
        area = screen.availableGeometry()
        self.resize(max(512, int(area.width() * 0.5)), max(384, int(area.height() * 0.5)))

    def _build_ui(self) -> None:
        root = QWidget()
        main = QVBoxLayout(root)
        main.setContentsMargins(10, 10, 10, 10)
        main.setSpacing(6)

        header = QFrame()
        header.setObjectName("HeaderCard")
        header.setFixedHeight(58)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(14, 8, 12, 8)
        header_layout.setSpacing(8)

        title_box = QVBoxLayout()
        title_box.setSpacing(1)
        self.title_label = QLabel("FileFlow")
        self.title_label.setObjectName("Title")
        self.master_label = QLabel("Master: 載入中…")
        self.master_label.setObjectName("Subtitle")
        title_box.addWidget(self.title_label)
        title_box.addWidget(self.master_label)
        header_layout.addLayout(title_box, 1)

        self.source_combo = QComboBox()
        self.source_combo.setMinimumWidth(76)
        self.source_combo.currentIndexChanged.connect(self.update_button_states)
        header_layout.addWidget(self.source_combo)

        self.status_pill = QLabel("尚未檢查")
        self.status_pill.setObjectName("StatusPill")
        self.status_pill.setAlignment(Qt.AlignCenter)
        header_layout.addWidget(self.status_pill)

        self.btn_advanced = QToolButton()
        self.btn_advanced.setObjectName("MoreButton")
        self.btn_advanced.setText("更多 ▾")
        self.btn_advanced.setPopupMode(QToolButton.InstantPopup)
        self.advanced_menu = QMenu(self)
        self.act_verify = self.advanced_menu.addAction("檢查同步")
        self.act_commit = self.advanced_menu.addAction("記錄版本")
        self.act_undo = self.advanced_menu.addAction("復原上次")
        self.advanced_menu.addSeparator()
        self.act_config_check = self.advanced_menu.addAction("檢查設定")
        self.act_edit_config = self.advanced_menu.addAction("編輯設定")
        self.advanced_menu.addSeparator()
        self.act_clean_backups = self.advanced_menu.addAction("清理備份")
        self.act_open_log = self.advanced_menu.addAction("操作紀錄")
        self.act_open_backup = self.advanced_menu.addAction("開啟備份")
        self.act_copy_summary = self.advanced_menu.addAction("複製摘要")
        self.btn_advanced.setMenu(self.advanced_menu)
        header_layout.addWidget(self.btn_advanced)
        main.addWidget(header)

        summary = QFrame()
        summary.setObjectName("SummaryCard")
        summary.setFixedHeight(44)
        summary_layout = QHBoxLayout(summary)
        summary_layout.setContentsMargins(14, 6, 14, 6)
        summary_layout.setSpacing(8)
        self.summary_label = QLabel("0 files · 0 workspaces · Last scan: -")
        self.summary_label.setObjectName("Subtitle")
        summary_layout.addWidget(self.summary_label, 1)
        self.diff_pill = QLabel("Diff 0")
        self.diff_pill.setObjectName("TinyPill")
        self.missing_pill = QLabel("Miss 0")
        self.missing_pill.setObjectName("TinyPill")
        self.elapsed_pill = QLabel("0.00s")
        self.elapsed_pill.setObjectName("TinyPill")
        summary_layout.addWidget(self.diff_pill)
        summary_layout.addWidget(self.missing_pill)
        summary_layout.addWidget(self.elapsed_pill)
        main.addWidget(summary)

        center = QFrame()
        center.setObjectName("CenterCard")
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(12, 12, 12, 10)
        center_layout.setSpacing(8)

        switch_row = QWidget()
        switch_layout = QHBoxLayout(switch_row)
        switch_layout.setContentsMargins(0, 0, 0, 0)
        switch_layout.setSpacing(6)
        self.btn_matrix_tab = QPushButton("同步矩陣")
        self.btn_matrix_tab.setObjectName("SegmentButton")
        self.btn_details_tab = QPushButton("詳細記錄")
        self.btn_details_tab.setObjectName("SegmentButton")
        self.btn_matrix_tab.clicked.connect(lambda: self.switch_center_page(0))
        self.btn_details_tab.clicked.connect(lambda: self.switch_center_page(1))
        switch_layout.addWidget(self.btn_matrix_tab)
        switch_layout.addWidget(self.btn_details_tab)
        switch_layout.addStretch(1)
        center_layout.addWidget(switch_row)

        self.stack = QStackedWidget()
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(["File", "Master", "A", "B", "C", "Git"])
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectItems)
        self.table.setSelectionMode(QTableWidget.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.table.itemSelectionChanged.connect(self.show_selected_cell_detail)
        self.table.cellClicked.connect(self.show_cell_detail)
        self.stack.addWidget(self.table)

        detail_page = QWidget()
        detail_layout = QVBoxLayout(detail_page)
        detail_layout.setContentsMargins(0, 0, 0, 0)
        detail_layout.setSpacing(6)
        detail_tools = QHBoxLayout()
        detail_tools.setContentsMargins(0, 0, 0, 0)
        self.detail_font_label = QLabel("文字 12px")
        self.detail_font_label.setObjectName("SmallText")
        self.btn_details_smaller = QPushButton("A-")
        self.btn_details_smaller.setObjectName("SmallToolButton")
        self.btn_details_larger = QPushButton("A+")
        self.btn_details_larger.setObjectName("SmallToolButton")
        self.btn_details_smaller.clicked.connect(self.decrease_details_font)
        self.btn_details_larger.clicked.connect(self.increase_details_font)
        detail_tools.addStretch(1)
        detail_tools.addWidget(self.detail_font_label)
        detail_tools.addWidget(self.btn_details_smaller)
        detail_tools.addWidget(self.btn_details_larger)
        detail_layout.addLayout(detail_tools)
        self.detail_browser = QTextBrowser()
        self.detail_browser.setMinimumHeight(90)
        self.detail_browser.setOpenExternalLinks(False)
        self.detail_browser.setHtml(self.default_detail_html())
        detail_layout.addWidget(self.detail_browser, 1)
        self.stack.addWidget(detail_page)
        center_layout.addWidget(self.stack, 1)
        self.switch_center_page(0)

        self.detail_label = QLabel("選取表格項目可查看路徑、大小與 hash。")
        self.detail_label.setObjectName("SmallText")
        self.detail_label.setMinimumHeight(17)
        center_layout.addWidget(self.detail_label)
        main.addWidget(center, 1)

        actions = QFrame()
        actions.setObjectName("ActionCard")
        actions.setFixedHeight(46)
        action_layout = QHBoxLayout(actions)
        action_layout.setContentsMargins(12, 7, 12, 7)
        action_layout.setSpacing(7)
        self.btn_status = QPushButton("重新檢查")
        self.btn_diff = QPushButton("看差異")
        self.btn_promote = QPushButton("更新 Master")
        self.btn_promote.setObjectName("PrimaryButton")
        self.btn_reset = QPushButton("還原工作區")
        self.btn_reset.setObjectName("DangerButton")
        for btn in [self.btn_status, self.btn_diff, self.btn_promote, self.btn_reset]:
            action_layout.addWidget(btn)
        main.addWidget(actions)

        footer = QFrame()
        footer.setObjectName("FooterCard")
        footer.setFixedHeight(40)
        footer_layout = QHBoxLayout(footer)
        footer_layout.setContentsMargins(12, 6, 12, 6)
        footer_layout.setSpacing(8)
        self.next_action_label = QLabel("建議：先按「重新檢查」。")
        self.next_action_label.setObjectName("SuggestionText")
        footer_layout.addWidget(self.next_action_label, 1)
        self.btn_commit_hint = QPushButton("記錄版本")
        self.btn_commit_hint.setObjectName("InlineButton")
        self.btn_commit_hint.setVisible(False)
        footer_layout.addWidget(self.btn_commit_hint)
        self.progress_label = QLabel("等待操作")
        self.progress_label.setObjectName("SmallText")
        footer_layout.addWidget(self.progress_label)
        self.progress = QProgressBar()
        self.progress.setFixedWidth(78)
        self.progress.setValue(0)
        footer_layout.addWidget(self.progress)
        main.addWidget(footer)
        self.setCentralWidget(root)

        self.btn_status.clicked.connect(lambda: self.run_background("重新檢查", lambda: file_flow.get_status_result(self.config_path)))
        self.btn_diff.clicked.connect(self.run_diff)
        self.btn_promote.clicked.connect(self.run_promote)
        self.btn_reset.clicked.connect(self.run_reset)
        self.btn_commit_hint.clicked.connect(self.run_commit)
        self.act_verify.triggered.connect(lambda: self.run_background("檢查同步", lambda: file_flow.get_verify_result(self.config_path)))
        self.act_commit.triggered.connect(self.run_commit)
        self.act_undo.triggered.connect(self.run_undo)
        self.act_config_check.triggered.connect(self.run_config_check)
        self.act_edit_config.triggered.connect(self.edit_config)
        self.act_clean_backups.triggered.connect(self.run_clean_backups)
        self.act_open_log.triggered.connect(lambda: self.open_path(self.last_log_path))
        self.act_open_backup.triggered.connect(lambda: self.open_path(self.last_backup_path))
        self.act_copy_summary.triggered.connect(self.copy_summary)
        self.update_button_states()

    @staticmethod
    def _short_path(path: Path | str | None, keep: int = 3) -> str:
        if path is None:
            return "-"
        p = Path(str(path))
        parts = p.parts
        if len(parts) <= keep:
            return str(p)
        return ".../" + "/".join(parts[-keep:])

    def switch_center_page(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        if hasattr(self, "detail_label"):
            self.detail_label.setVisible(index == 0)
        for i, button in enumerate((self.btn_matrix_tab, self.btn_details_tab)):
            button.setProperty("active", "true" if i == index else "false")
            button.style().unpolish(button)
            button.style().polish(button)
            button.update()

    def default_detail_html(self) -> str:
        return (
            f"<div style='font-size:{self.details_font_size}px;color:#6D7A7E;'>"
            "尚無操作記錄。請先按「重新檢查」。"
            "</div>"
        )

    def apply_details_font_size(self) -> None:
        self.details_font_size = max(10, min(18, int(self.details_font_size)))
        self.detail_font_label.setText(f"文字 {self.details_font_size}px")
        if self.last_result is not None:
            self.detail_browser.setHtml(self.result_to_html(self.last_result))
        else:
            self.detail_browser.setHtml(self.default_detail_html())

    def increase_details_font(self) -> None:
        self.details_font_size = min(18, self.details_font_size + 1)
        self.apply_details_font_size()

    def decrease_details_font(self) -> None:
        self.details_font_size = max(10, self.details_font_size - 1)
        self.apply_details_font_size()

    def set_busy(self, busy: bool, label: str = "") -> None:
        controls = [self.btn_status, self.btn_diff, self.btn_promote, self.btn_reset, self.btn_advanced]
        for control in controls:
            control.setEnabled(not busy)
        self.progress_label.setText(label or ("正在處理…" if busy else "等待操作"))
        if busy:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(0)
        if not busy:
            self.update_button_states()

    def update_button_states(self) -> None:
        if self.thread is not None:
            return
        has_config = self.config is not None
        has_source = self.source_combo.currentIndex() >= 0
        self.btn_status.setEnabled(True)
        self.btn_diff.setEnabled(has_config and has_source)
        self.btn_promote.setEnabled(has_config and has_source)
        self.btn_reset.setEnabled(has_config)
        self.btn_advanced.setEnabled(True)
        self.act_verify.setEnabled(has_config)
        self.act_commit.setEnabled(has_config)
        self.act_undo.setEnabled(has_config)
        self.act_config_check.setEnabled(True)
        self.act_edit_config.setEnabled(has_config)
        self.act_clean_backups.setEnabled(has_config)
        self.act_open_log.setEnabled(self.last_log_path is not None and self.last_log_path.exists())
        self.act_open_backup.setEnabled(self.last_backup_path is not None and self.last_backup_path.exists())
        self.act_copy_summary.setEnabled(self.last_result is not None)

    def run_background(self, title: str, action: Callable[..., Any], *, with_progress: bool = False) -> None:
        if self.thread is not None:
            return
        self.set_busy(True, f"{title}…")
        self.next_action_label.setText(f"正在執行：{title}")
        self.thread = QThread()
        self.worker = Worker(action, with_progress=with_progress)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.on_worker_finished)
        self.worker.failed.connect(self.on_worker_failed)
        self.worker.progress.connect(self.on_progress)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    @Slot(object)
    def on_worker_finished(self, result: Any) -> None:
        if isinstance(result, file_flow.CommandResult):
            self.apply_result(result)
        else:
            self.detail_browser.setPlainText(str(result))
            self.switch_center_page(1)

    @Slot(object)
    def on_progress(self, info: object) -> None:
        if not isinstance(info, dict):
            return
        copied = int(info.get("copied_bytes") or 0)
        total = int(info.get("total_bytes") or 0)
        index = int(info.get("current_item_index") or 1)
        count = int(info.get("total_item_count") or 1)
        percent = int(copied * 100 / total) if total else 0
        self.progress.setRange(0, 100)
        self.progress.setValue(percent)
        self.progress_label.setText(f"{index}/{count} · {info.get('current_file', '')} · {percent}%")

    @Slot(str)
    def on_worker_failed(self, message: str) -> None:
        self.detail_browser.setHtml(f"<h3>錯誤</h3><pre>{html.escape(message)}</pre>")
        self.switch_center_page(1)
        self.next_action_label.setText("操作失敗，請查看詳細記錄。")
        QMessageBox.critical(self, "錯誤", message)

    @Slot()
    def cleanup_thread(self) -> None:
        self.thread = None
        self.worker = None
        self.set_busy(False)

    def apply_result(self, result: file_flow.CommandResult) -> None:
        self.last_result = result
        self.config = result.config or self.config
        self.last_log_path = result.operation_log_path
        self.last_json_path = result.operation_json_path
        self.last_backup_path = result.backup_dir
        if self.config:
            self.update_config_summary(self.config)
        self.update_overview(result)
        if result.records:
            self.update_matrix(result)
        self.detail_browser.setHtml(self.result_to_html(result))
        if result.operation in {"diff", "config-check", "commit", "undo-last", "reset-all", "promote"}:
            self.switch_center_page(1)
        elif result.operation == "status":
            self.switch_center_page(0)
        self.update_button_states()

    def update_config_summary(self, config: file_flow.FlowConfig) -> None:
        self.config_path = config.config_path
        short_master = self._short_path(config.master_folder, keep=3)
        short_config = self._short_path(config.config_path, keep=2)
        self.master_label.setText(f"Master: {short_master} · {short_config}")
        self.master_label.setToolTip(f"Master: {config.master_folder}\nConfig: {config.config_path}")
        old = [self.source_combo.itemText(i) for i in range(self.source_combo.count())]
        if old != list(config.locations):
            self.source_combo.blockSignals(True)
            self.source_combo.clear()
            for name in config.locations:
                self.source_combo.addItem(name, name)
            self.source_combo.blockSignals(False)

    def update_overview(self, result: file_flow.CommandResult) -> None:
        summary = result.metadata.get("summary", {}) if result.metadata else {}
        different = int(summary.get("different", 0) or 0)
        missing = int(summary.get("missing", 0) or 0)
        errors = int(summary.get("errors", len(result.errors)) or 0)

        if result.operation == "diff":
            lowered = (result.diff_text or result.output or "").lower()
            different = lowered.count(": different") + lowered.count("binary differs") + lowered.count("binary file differs")
            missing = lowered.count("missing")
            if different == 0 and "無差異" not in lowered and "same" not in lowered:
                different = 1 if result.diff_text else 0

        config = result.config or self.config
        files_count = len(config.files) if config else 0
        locations_count = len(config.locations) if config else 0
        timestamp = str(result.metadata.get("timestamp", "")) if result.metadata else ""
        scan_time = timestamp[11:16] if len(timestamp) >= 16 else "-"
        self.summary_label.setText(f"{files_count} files · {locations_count} workspaces · Last scan: {scan_time}")
        self.diff_pill.setText(f"Diff {different}")
        self.missing_pill.setText(f"Miss {missing}")
        self.elapsed_pill.setText(f"{result.elapsed_seconds:.2f}s")
        if result.operation == "diff" and different:
            status, color, text_color = "有差異", "#FFF4D7", "#7A5A00"
        elif result.operation == "diff" and not different and not missing:
            status, color, text_color = "已同步", "#EAF7EF", "#17643A"
        elif result.success and not different and not missing and not errors:
            status, color, text_color = "已同步", "#EAF7EF", "#17643A"
        elif errors or result.errors:
            status, color, text_color = ("設定錯誤" if result.operation == "config-check" else "有錯誤"), "#FFE8E1", "#9B3C1B"
        elif missing:
            status, color, text_color = "有缺檔", "#FFE8E1", "#9B3C1B"
        elif different:
            status, color, text_color = "有差異", "#FFF4D7", "#7A5A00"
        else:
            status, color, text_color = "需確認", "#F0F4F3", "#516064"
        self.status_pill.setText(status)
        self.status_pill.setStyleSheet(
            f"background: {color}; color: {text_color}; border-radius: 11px; padding: 4px 10px; font-weight: 850;"
        )
        suggestion = result.suggestions[0] if result.suggestions else "建議：目前已同步。"
        if result.operation == "diff":
            source = result.metadata.get("source", self.selected_source()) if result.metadata else self.selected_source()
            suggestion = f"已顯示 {source} 與 Master 的差異。" if different else f"{source} 與 Master 沒有差異。"
        self.next_action_label.setText(self._short_suggestion(suggestion))
        self.btn_commit_hint.setVisible(self._has_git_changes(result))

    def _short_suggestion(self, text: str) -> str:
        text = text.replace("若 Master 是正確版本，可以使用 reset-all 補齊缺失檔案。", "建議：先看差異，再決定更新或還原。")
        text = text.replace("若某個工作位置才是正確版本，請先確認後 promote。", "建議：確認正確工作區後再更新 Master。")
        text = self.ui_text(text)
        if not text.startswith("建議") and not text.startswith("已顯示") and not text.startswith("有未記錄"):
            text = "建議：" + text
        return text[:58] + ("…" if len(text) > 58 else "")

    def _has_git_changes(self, result: file_flow.CommandResult) -> bool:
        for record in result.records:
            text = (record.git_status or "").strip()
            if text and "Git repo 不可用" not in text and text.lower() != "clean":
                return True
        return False

    @staticmethod
    def git_status_for_ui(raw_status: str) -> tuple[str, str, str]:
        raw = (raw_status or "").strip()
        lowered = raw.lower()
        upper = raw.upper()
        if not raw or lowered == "clean" or "git repo 不可用" in lowered or "不在 git repo" in lowered:
            return "-", file_flow.STATUS_UNKNOWN, raw or "clean"
        if upper in {file_flow.STATUS_MODIFIED, "M", "MM"} or "MODIFIED" in upper or upper.startswith("M"):
            return "Mod", file_flow.STATUS_MODIFIED, raw
        if upper in {file_flow.STATUS_UNTRACKED, "??"} or "UNTRACKED" in upper:
            return "New", file_flow.STATUS_UNTRACKED, raw
        if upper in {file_flow.STATUS_DELETED, "D"} or "DELETED" in upper or upper.startswith("D"):
            return "Del", file_flow.STATUS_DELETED, raw
        if "RENAMED" in upper or upper.startswith("R"):
            return "Ren", file_flow.STATUS_MODIFIED, raw
        if "ADDED" in upper or upper.startswith("A"):
            return "Add", file_flow.STATUS_UNTRACKED, raw
        return "?", file_flow.STATUS_UNKNOWN, raw

    def update_matrix(self, result: file_flow.CommandResult) -> None:
        records = list(result.records)
        self.cell_details = {}
        self.table.clearContents()
        if not records:
            self.table.setRowCount(0)
            return
        locations = list(records[0].locations)
        headers = ["File", "Master", *locations, "Git"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setRowCount(len(records))
        for row, record in enumerate(records):
            file_item = self.make_item(record.entry.relative_file.as_posix(), None)
            file_item.setTextAlignment(Qt.AlignVCenter | Qt.AlignLeft)
            self.table.setItem(row, 0, file_item)

            self.set_status_cell(row, 1, record.master.status, record.master)
            for col, location in enumerate(locations, start=2):
                self.set_status_cell(row, col, record.locations[location].status, record.locations[location])

            git_text, git_status, git_tooltip = self.git_status_for_ui(record.git_status)
            self.set_status_cell(row, len(headers) - 1, git_text, None, status_override=git_status, tooltip=git_tooltip, fixed_width=44)
        for r in range(self.table.rowCount()):
            self.table.setRowHeight(r, 28)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        for c in range(1, self.table.columnCount()):
            header.setSectionResizeMode(c, QHeaderView.Fixed)
            self.table.setColumnWidth(c, 62 if c == self.table.columnCount() - 1 else 56)
        self.table.resizeRowsToContents()

    def set_status_cell(
        self,
        row: int,
        col: int,
        text: str,
        state: file_flow.FileState | None,
        *,
        status_override: str | None = None,
        tooltip: str | None = None,
        fixed_width: int | None = None,
    ) -> None:
        status = status_override or (state.status if state else text)
        visible_text = STATUS_TEXT.get(state.status, state.status) if state else STATUS_TEXT.get(text, text)
        item = self.make_item(text, state)
        self.table.setItem(row, col, item)
        pill = QLabel(visible_text)
        pill.setObjectName("StatusCell")
        pill.setAlignment(Qt.AlignCenter)
        if fixed_width is not None:
            pill.setFixedWidth(fixed_width)
        pill.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        pill.setStyleSheet(
            "QLabel#StatusCell {"
            f"background: {STATUS_COLORS.get(status, '#EEF3F1')};"
            f"color: {STATUS_FOREGROUNDS.get(status, '#5C6B70')};"
            "border-radius: 10px;"
            "padding: 3px 7px;"
            "font-weight: 850;"
            "}"
        )
        if tooltip:
            pill.setToolTip(tooltip)
            item.setToolTip(tooltip)
        elif state:
            pill.setToolTip(item.toolTip())
        self.table.setCellWidget(row, col, pill)
        if state:
            self.cell_details[(row, col)] = file_flow.file_state_to_json(state)

    def make_item(self, text: str, state: file_flow.FileState | None) -> QTableWidgetItem:
        visible_text = STATUS_TEXT.get(text, text)
        if state is not None:
            visible_text = STATUS_TEXT.get(state.status, state.status)
        item = QTableWidgetItem(visible_text)
        item.setTextAlignment(Qt.AlignCenter)
        item.setFlags(item.flags() ^ Qt.ItemIsEditable)
        status = state.status if state else text
        item.setBackground(QColor(STATUS_COLORS.get(status, "#FFFFFF")))
        if state:
            item.setData(Qt.UserRole, file_flow.file_state_to_json(state))
            tooltip = [
                f"status: {state.status}",
                f"path: {state.path}",
                f"exists: {state.exists}",
                f"size: {state.size}",
                f"mtime_ns: {state.mtime_ns}",
                f"sha256: {state.sha256 or '-'}",
            ]
            if state.error:
                tooltip.append(f"error: {state.error}")
            item.setToolTip("\n".join(tooltip))
        return item

    def show_cell_detail(self, row: int, column: int) -> None:
        data = self.cell_details.get((row, column))
        if not data:
            item = self.table.item(row, column)
            self.detail_label.setText(item.text() if item else "-")
            return
        self.set_detail_from_state_json(data)

    def show_selected_cell_detail(self) -> None:
        items = self.table.selectedItems()
        if not items:
            return
        data = items[0].data(Qt.UserRole)
        if not data:
            self.detail_label.setText(items[0].text())
            return
        self.set_detail_from_state_json(data)

    def set_detail_from_state_json(self, data: dict[str, Any]) -> None:
        full_hash = data.get("sha256") or ""
        path = self._short_path(data.get("path"), keep=3)
        size = data.get("size") if data.get("size") is not None else "-"
        self.detail_label.setText(f"{data.get('status')} · {path} · {size}B · {file_flow.short_hash(full_hash)}")
        self.detail_label.setToolTip(str(data.get("path") or ""))

    @staticmethod
    def ui_text(text: str) -> str:
        return (text or "").replace("Commit Master", "記錄 Master").replace("Git commit", "記錄版本").replace("commit", "記錄版本")

    def result_to_html(self, result: file_flow.CommandResult) -> str:
        title = html.escape(self.ui_text(result.title))
        status = "成功" if result.success else "失敗"
        base_size = self.details_font_size
        title_size = base_size + 1
        parts = [
            f"<div style='font-size:{title_size}px;font-weight:800;color:#102327;'>{title}</div>",
            f"<div style='font-size:{base_size}px;color:#536266;margin:4px 0 8px 0;'>狀態：{status} ｜ 耗時：{result.elapsed_seconds:.3f}s ｜ copied {result.copied_count} ｜ skipped {result.skipped_count} ｜ failed {result.failed_count}</div>",
            f"<div style='font-size:{base_size}px;'>{html.escape(self.ui_text(result.message))}</div>",
        ]
        if result.errors:
            parts.append("<br><b>Errors</b><ul>" + "".join(f"<li>{html.escape(self.ui_text(e))}</li>" for e in result.errors) + "</ul>")
        if result.warnings:
            parts.append("<br><b>Warnings</b><ul>" + "".join(f"<li>{html.escape(self.ui_text(w))}</li>" for w in result.warnings) + "</ul>")
        if result.suggestions:
            parts.append("<br><b>Suggestions</b><ul>" + "".join(f"<li>{html.escape(self.ui_text(s))}</li>" for s in result.suggestions) + "</ul>")
        detail_text = result.diff_text or result.output
        if detail_text:
            parts.append(f"<br><b>Details</b><pre style='white-space:pre-wrap;font-size:{base_size}px;'>" + html.escape(self.ui_text(detail_text)) + "</pre>")
        if result.operation_log_path:
            parts.append("<br><b>操作紀錄</b><br>" + html.escape(str(result.operation_log_path)))
        if result.operation_json_path:
            parts.append("<br><b>JSON</b><br>" + html.escape(str(result.operation_json_path)))
        return "".join(parts)

    def selected_source(self) -> str | None:
        return self.source_combo.currentData() or self.source_combo.currentText() or None

    def tracked_file_names(self) -> list[str]:
        try:
            config = self.config or file_flow.load_config(self.config_path)
            return [path.as_posix() for path in config.files]
        except Exception:  # noqa: BLE001 - confirmation dialog should still work
            return []

    def location_names(self) -> list[str]:
        try:
            config = self.config or file_flow.load_config(self.config_path)
            return list(config.locations)
        except Exception:  # noqa: BLE001
            return []

    def promote_message(self, source: str | None = None) -> str:
        source = source or self.selected_source() or "選定工作區"
        files = self.tracked_file_names()
        file_text = "\n".join(f"• {name}" for name in files[:6]) if files else "• 目前無法讀取檔案清單"
        if len(files) > 6:
            file_text += f"\n• ... 還有 {len(files) - 6} 個"
        return (
            f"你即將用 {source} 更新 Master。\n\n"
            "會發生：\n"
            "• 覆蓋 Master 中對應的追蹤檔案\n"
            "• 建立備份\n"
            "• 再同步到其他工作區\n\n"
            f"追蹤檔案：\n{file_text}\n\n"
            "是否繼續？"
        )

    def reset_message(self) -> str:
        locations = self.location_names()
        files = self.tracked_file_names()
        loc_text = ", ".join(locations) if locations else "目前無法讀取工作區清單"
        file_text = "\n".join(f"• {name}" for name in files[:6]) if files else "• 目前無法讀取檔案清單"
        if len(files) > 6:
            file_text += f"\n• ... 還有 {len(files) - 6} 個"
        return (
            "你即將用 Master 覆蓋所有工作區。\n\n"
            f"受影響工作區：{loc_text}\n\n"
            f"追蹤檔案：\n{file_text}\n\n"
            "此操作會修改工作區檔案。是否繼續？"
        )

    def run_diff(self) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.information(self, "看差異", "請先選擇工作區。")
            return
        self.run_background("看差異", lambda: file_flow.get_diff_preview_result(source, self.config_path))

    def run_promote(self) -> None:
        source = self.selected_source()
        if not source:
            QMessageBox.information(self, "更新 Master", "請先選擇工作區。")
            return
        if not self.confirm_ok("更新 Master", self.promote_message(source)):
            return
        self.run_background(
            "更新 Master",
            lambda cb=None: file_flow.perform_promote(source, self.config_path, dry_run=False, progress_callback=cb),
            with_progress=True,
        )

    def run_reset(self) -> None:
        if not self.confirm_ok("還原工作區", self.reset_message()):
            return
        self.run_background(
            "還原工作區",
            lambda cb=None: file_flow.perform_reset_all(self.config_path, dry_run=False, progress_callback=cb),
            with_progress=True,
        )

    def run_config_check(self) -> None:
        self.run_background("檢查設定", lambda: file_flow.config_check(self.config_path))

    def run_commit(self) -> None:
        dialog = QInputDialog(self)
        dialog.setWindowTitle("記錄版本")
        dialog.setLabelText("版本訊息：")
        dialog.setTextValue("記錄 FileFlow 同步檔案")
        dialog.setModal(True)
        if dialog.exec() != QDialog.Accepted:
            return
        text = dialog.textValue().strip()
        if not text:
            QMessageBox.information(self, "記錄版本", "版本訊息不可空白。")
            return
        self.run_background("記錄版本", lambda: file_flow.perform_commit(text, self.config_path))

    def run_undo(self) -> None:
        if not self.confirm_ok("復原上次", "即將還原上一次可還原操作，會從 backup 還原檔案。\n\n是否繼續？"):
            return
        self.run_background(
            "復原上次",
            lambda cb=None: file_flow.perform_undo_last(self.config_path, dry_run=False, yes=True, progress_callback=cb),
            with_progress=True,
        )

    def run_clean_backups(self) -> None:
        if self.config is None:
            return
        if not self.confirm_ok("清理備份", "將依照保留策略清理舊備份。\n\n是否繼續？"):
            return
        self.run_background("清理備份", lambda: file_flow.cleanup_backups(self.config, dry_run=False, yes=True))

    def confirm_ok(self, title: str, message: str) -> bool:
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        box.setIcon(QMessageBox.Warning)
        box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        box.button(QMessageBox.Ok).setText("OK")
        box.button(QMessageBox.Cancel).setText("Cancel")
        return box.exec() == QMessageBox.Ok

    def open_path(self, path: Path | None) -> None:
        if not path:
            QMessageBox.warning(self, "無法開啟", "尚無可開啟的路徑。")
            return
        if not path.exists():
            QMessageBox.warning(self, "無法開啟", f"路徑不存在：\n{path}")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def copy_summary(self) -> None:
        if not self.last_result:
            return
        QApplication.clipboard().setText(file_flow.format_human_result(self.last_result))
        self.next_action_label.setText("已複製摘要。")

    def edit_config(self) -> None:
        if self.config is None:
            return
        path = self.config.config_path
        if not path.exists():
            QApplication.clipboard().setText(str(path))
            QMessageBox.warning(self, "編輯設定", f"設定檔不存在，已複製路徑：\n{path}")
            return
        opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
        if not opened:
            QApplication.clipboard().setText(str(path))
            QMessageBox.information(self, "編輯設定", f"無法自動開啟設定檔，已複製路徑：\n{path}")

    # Non-blocking dialogs used only for offscreen screenshot tests.
    def preview_commit_dialog(self) -> None:
        dialog = QInputDialog(self)
        dialog.setWindowTitle("記錄版本")
        dialog.setLabelText("版本訊息：")
        dialog.setTextValue("記錄 FileFlow 同步檔案")
        dialog.setModal(False)
        dialog.show()
        self._current_dialog = dialog

    def preview_confirm_dialog(self, kind: str) -> None:
        title = "更新 Master" if kind == "promote" else "還原工作區"
        message = self.promote_message() if kind == "promote" else self.reset_message()
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setText(message)
        box.setIcon(QMessageBox.Warning)
        box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        box.button(QMessageBox.Ok).setText("OK")
        box.button(QMessageBox.Cancel).setText("Cancel")
        box.setModal(False)
        box.show()
        self._current_dialog = box

    def preview_undo_dialog(self) -> None:
        box = QMessageBox(self)
        box.setWindowTitle("復原上次")
        box.setText("即將還原上一次可還原操作，會從 backup 還原檔案。\n\n是否繼續？")
        box.setIcon(QMessageBox.Warning)
        box.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)
        box.button(QMessageBox.Ok).setText("OK")
        box.button(QMessageBox.Cancel).setText("Cancel")
        box.setModal(False)
        box.show()
        self._current_dialog = box


def ensure_qt_available() -> None:
    if PYSIDE6_IMPORT_ERROR is not None:
        raise RuntimeError(
            "無法啟動 GUI：缺少 PySide6。請先執行 `python -m pip install PySide6`，或改用 CLI：`python file_flow.py status`。"
        ) from PYSIDE6_IMPORT_ERROR


def main(argv: list[str] | None = None) -> int:
    ensure_qt_available()
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--smoke-test", action="store_true")
    parser.add_argument("--screenshot", type=Path, default=None)
    parser.add_argument("--screenshot-after", nargs="+", default=None, metavar=("ACTION", "PATH"), help="Capture after an action. Usage: --screenshot-after diff out.png, or --screenshot out.png --screenshot-after diff")
    parser.add_argument("--help", action="store_true")
    args, qt_args = parser.parse_known_args(argv if argv is not None else sys.argv[1:])
    allowed_after = {"status", "diff", "details", "details-large", "details-small", "config-check", "commit-dialog", "promote-dialog", "reset-dialog", "undo-dialog"}
    after_action: str | None = None
    after_path: Path | None = args.screenshot
    if args.screenshot_after:
        if len(args.screenshot_after) == 1:
            after_action = args.screenshot_after[0]
        elif len(args.screenshot_after) == 2:
            after_action = args.screenshot_after[0]
            after_path = Path(args.screenshot_after[1])
        else:
            print("--screenshot-after expects ACTION or ACTION PATH", file=sys.stderr)
            return 2
        if after_action not in allowed_after:
            print(f"Unsupported --screenshot-after action: {after_action}", file=sys.stderr)
            return 2
        if after_path is None:
            print("--screenshot-after requires an output path; use --screenshot-after diff out.png", file=sys.stderr)
            return 2
    if args.help:
        print("FileFlow GUI options: --config PATH --smoke-test --screenshot PATH --screenshot-after ACTION [PATH]")
        return 0

    app = QApplication([sys.argv[0], *qt_args])
    window = MainWindow(args.config)
    window.show()

    def capture(path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        target = QApplication.activeModalWidget() or window._current_dialog or window
        target.grab().save(str(path))
        app.quit()

    if after_action and after_path:
        def trigger() -> None:
            action = after_action
            if action == "status":
                result = file_flow.get_status_result(window.config_path)
                window.apply_result(result)
            elif action == "diff":
                source = window.selected_source()
                if source:
                    result = file_flow.get_diff_preview_result(source, window.config_path)
                    window.apply_result(result)
            elif action == "details":
                window.switch_center_page(1)
            elif action == "details-large":
                source = window.selected_source()
                if source:
                    result = file_flow.get_diff_preview_result(source, window.config_path)
                    window.apply_result(result)
                window.increase_details_font()
                window.increase_details_font()
                window.switch_center_page(1)
            elif action == "details-small":
                source = window.selected_source()
                if source:
                    result = file_flow.get_diff_preview_result(source, window.config_path)
                    window.apply_result(result)
                window.decrease_details_font()
                window.decrease_details_font()
                window.switch_center_page(1)
            elif action == "config-check":
                result = file_flow.config_check(window.config_path)
                window.apply_result(result)
            elif action == "commit-dialog":
                window.preview_commit_dialog()
            elif action == "promote-dialog":
                window.preview_confirm_dialog("promote")
            elif action == "reset-dialog":
                window.preview_confirm_dialog("reset")
            elif action == "undo-dialog":
                window.preview_undo_dialog()
        QTimer.singleShot(900, trigger)
        wait = 1800
        QTimer.singleShot(wait, lambda: capture(after_path))
        return app.exec()

    if args.screenshot:
        QTimer.singleShot(1500, lambda: capture(args.screenshot))
        return app.exec()

    if args.smoke_test:
        QTimer.singleShot(1000, app.quit)
        return app.exec()

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
