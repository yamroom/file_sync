# FileFlow UI Patch Test Report

Scope: Version 1 layout + Version 4 status colors local UI fixes.

## Fixes

- Git status in the matrix now maps long raw values to short UI labels: `-`, `Mod`, `Add`, `Del`, `New`, `Ren`, `?`.
- Git status full text is preserved in tooltip.
- The central `同步矩陣` / `詳細記錄` switch now uses a segmented-control style with internal padding instead of a native tab look.
- `詳細記錄` has `A-` and `A+` controls.
- Details font size is adjustable from 10px to 18px in the current GUI session.
- UI text now maps Commit wording to `記錄版本` / `記錄 Master` where displayed by the GUI.

## Tests Run

```bash
python3 -m compileall -q .
python3 -m unittest discover -s tests -v
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --smoke-test
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot /mnt/data/fileflow_v1_color_patch/main_fixed.png
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot-after diff /mnt/data/fileflow_v1_color_patch/details_default_font.png
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot-after details-large /mnt/data/fileflow_v1_color_patch/details_large_font.png
QT_QPA_PLATFORM=offscreen python3 file_flow_gui.py --config ui_demo/demo_paths.toml --screenshot-after details-small /mnt/data/fileflow_v1_color_patch/details_small_font.png
python3 build_file_flow_exe.py --dry-run
```

## Results

- compileall: PASS
- unittest: PASS, 10 tests
- GUI smoke test: PASS
- GUI screenshot: PASS
- GUI details screenshot: PASS
- build dry-run: PASS

## Known Limits

- Details font size is not persisted after restart.
- Windows `.exe` was not built or executed in this Linux environment.
- No core sync logic was intentionally changed.
